"""The site's API inside the browser (a Pyodide web worker), on one player's files. No server, no network.

The bundle is unpacked at /st with the project's layout, so calc, review, bucket and web/ read the paths they
always read. The player's own files (USER) come from the page (Supabase or the browser) and go back to it after
every change; what the review derives (reviews, plan, the generated bucket) is rebuilt by recompute().
"""
import json
import os
import runpy
import shutil
import sys
import traceback
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(os.environ.get("ST_ROOT", "/st"))  # /st in the browser; another folder to test it on a Mac
os.chdir(ROOT)
for p in (ROOT, ROOT / "web"):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

# The player's files: what they typed or imported, plus their own edits (bucket quantities, the dice roll log).
USER = ["data/roster", "data/bucket/bucket.json", "data/actions/rolls.json"]
# Rebuilt from USER by recompute()
DERIVED = ["data/reviews", "data/actions", "data/bucket"]
EMPTY = {
    "data/roster/inventory.json": {"items": [], "enchants": [], "consumables": [], "gems": None},
    "data/roster/blueprints.json": {"unlocked": [], "byType": {}},
    "data/roster/hero_cards.json": {"byBaseClass": {}, "champions": {}},
    "data/roster/index.json": {"heroes": [], "champions": []},
}
DIRS = ["data/roster/heroes", "data/roster/champions", "data/reviews/champions", "data/actions", "data/bucket"]

server = None
VERSION = ""  # set by st-worker.js: the bundle's version, for ?v= on the extension scripts


def _report(msg):
    """Progress to the page (the worker forwards it); a no-op outside the browser."""
    try:
        import js
        js.stReport(json.dumps(msg, ensure_ascii=False))
    except Exception:
        pass


def boot():
    """Import the site once: web/server.py's routes and every web/ext/*.py, then the browser-only routes."""
    global server
    if server is not None:
        return
    for d in DIRS:
        (ROOT / d).mkdir(parents=True, exist_ok=True)
    for rel, doc in EMPTY.items():
        if not (ROOT / rel).exists():
            (ROOT / rel).write_text(json.dumps(doc))
    import server as _server
    server = _server
    server.load_extensions()
    plain = server.ext_scripts
    server.ext_scripts = lambda: [s + (f"?v={VERSION}" if VERSION else "") for s in plain()]
    # no subprocess in the browser: the review's "run again" buttons run in this worker
    server.ROUTES[:0] = [("POST", "/api/review/run", _api_recompute),
                         ("POST", "/api/review/rerolls/run", _api_rerolls)]


def api(method, url, body_text):
    """One API call, as web/server.py would answer it → JSON text {"status", "payload"}."""
    boot()
    u = urlsplit(url)
    try:
        body = json.loads(body_text) if body_text else None
    except ValueError:
        return json.dumps({"status": 400, "payload": {"error": "the body is not JSON"}})
    req = server.Request(method, u.path, parse_qs(u.query), body)
    for m, prefix, fn in server.ROUTES:
        if m == method and (u.path == prefix or (prefix.endswith("/") and u.path.startswith(prefix))):
            try:
                status, payload = fn(req)
            except Exception:
                traceback.print_exc()
                status, payload = 500, {"error": traceback.format_exc(limit=4)}
            return json.dumps({"status": status, "payload": payload}, ensure_ascii=False)
    return json.dumps({"status": 404, "payload": {"error": f"unknown path {u.path}"}})


def catalog():
    """What the account form offers: classes with the item types of each slot, items, enchants, skills."""
    boot()
    from review import data as D
    hr = D.hr
    classes = []
    for cl in hr.classes().values():
        classes.append({"name": cl["name"], "type": cl.get("type"), "element": cl.get("element"),
                        "promoted": bool(cl.get("isPromoted")), "promotesTo": cl.get("promotesTo"),
                        "baseClass": cl.get("baseClass"), "titan": bool(cl.get("isTitan")),
                        "innate": (cl.get("innate") or {}).get("name"),
                        "slots": {str(n): hr.slot_types(cl, n) for n in range(1, 7)}})
    items = [{"name": it["name"], "tier": it["tier"], "type": it["type"]}
             for it in hr.items() if it["type"] not in ("Element", "Spirit") and it["tier"] >= 8]
    skills = [{"name": s["name"], "rarity": s.get("rarity"), "classes": s.get("classes") or [],
               "tiers": [t["name"] for t in s.get("tiers") or []]}
              for s in hr.skills().values() if not s.get("isInnate")]
    return json.dumps({
        "classes": classes, "items": items, "skills": skills,
        "elements": sorted(e["name"] for e in hr.element_enchants().values() if e["tier"] >= 8),
        "spirits": sorted(s["name"] for s in hr.spirits().values() if s["tier"] >= 8),
        "qualities": ["Epic", "Legendary", "Flawless", "Superior", "Normal"],
        "consumables": ["Titan Soul", "Basic Skill Die", "Super Skill Die", "Mega Skill Die", "Perfect Skill Die",
                        "Seed of Vitality", "Seed of Power", "Seed of Resistance", "Blossom of Vitality",
                        "Blossom of Power", "Blossom of Resistance", "Seed of Merit"],
    }, ensure_ascii=False)


# ---------------------------------------------------------------- the player's files

def _files(roots):
    out = {}
    for rel in roots:
        p = ROOT / rel
        if p.is_file():
            out[rel] = p.read_text()
        elif p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.is_file() and "/backup/" not in str(f):
                    out[str(f.relative_to(ROOT))] = f.read_text()
    return out


def user_files():
    """The player's files as {relative path: text}; bucket.json keeps only the player's own edits."""
    out = _files(USER)
    if "data/bucket/bucket.json" in out:
        doc = json.loads(out["data/bucket/bucket.json"])
        out["data/bucket/bucket.json"] = json.dumps({"version": doc.get("version", 1), "owner": doc.get("owner") or {}},
                                                    ensure_ascii=False)
    return json.dumps(out, ensure_ascii=False)


def derived_files():
    return json.dumps(_files(DERIVED), ensure_ascii=False)


def load(user_json, derived_json=None):
    """Replace every account file with these (a new login, an import, another device's save)."""
    for rel in ("data/roster", "data/reviews", "data/actions", "data/bucket"):
        shutil.rmtree(ROOT / rel, ignore_errors=True)
    for d in DIRS:
        (ROOT / d).mkdir(parents=True, exist_ok=True)
    for files in (json.loads(derived_json) if derived_json else {}, json.loads(user_json or "{}")):
        for rel, text in files.items():
            if not _safe(rel):
                continue
            p = ROOT / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text)
    for rel, doc in EMPTY.items():
        if not (ROOT / rel).exists():
            (ROOT / rel).write_text(json.dumps(doc))
    _normalize()
    _reindex()
    return json.dumps({"heroes": len(list((ROOT / "data/roster/heroes").glob("*.json")))})


def _safe(rel):
    parts = Path(rel).parts
    return bool(parts) and ".." not in parts and not rel.startswith("/") and \
        any(rel == u or rel.startswith(u + "/") for u in USER + DERIVED)


def put(rel, text):
    """Write (text) or delete (None) one player file, e.g. a hero from the form."""
    if not _safe(rel) or not any(rel == u or rel.startswith(u + "/") for u in USER):
        raise ValueError(f"not an account file: {rel}")
    p = ROOT / rel
    if text is None:
        if p.exists():
            p.unlink()
    else:
        json.loads(text)  # must be JSON
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    _normalize()
    _reindex()
    return "ok"


def _normalize():
    """Fields the review expects in inventory.json and blueprints.json (the phone reader always writes them; a
    file typed in the form or imported may leave some out)."""
    for rel, doc in EMPTY.items():
        p = ROOT / rel
        try:
            have = json.loads(p.read_text())
        except (FileNotFoundError, ValueError):
            have = {}
        if not isinstance(have, dict):
            have = {}
        merged = dict(doc, **{k: v for k, v in have.items() if v is not None or k not in doc})
        for k, v in doc.items():
            if isinstance(v, (list, dict)) and not isinstance(merged.get(k), type(v)):
                merged[k] = type(v)()
        if merged != have:
            p.write_text(json.dumps(merged, ensure_ascii=False))


def _reindex():
    """index.json lists every hero and champion file (execute's plan and the review read the order from it):
    strongest first by the power the game showed, as the game orders them."""
    def names(folder, key):
        found = []
        for f in (ROOT / "data/roster" / folder).glob("*.json"):
            try:
                doc = json.loads(f.read_text())
            except ValueError:
                continue
            found.append((-(((doc.get("stats") or {}).get("power")) or 0), doc.get(key) or f.stem))
        return [n for _, n in sorted(found)]
    path = ROOT / "data/roster/index.json"
    try:
        doc = json.loads(path.read_text())
    except (FileNotFoundError, ValueError):
        doc = {}
    doc["heroes"], doc["champions"] = names("heroes", "hero"), names("champions", "champion")
    path.write_text(json.dumps(doc, ensure_ascii=False))


# ---------------------------------------------------------------- recompute

def recompute(rerolls=True):
    """The owner's pipeline after a sync: review → rerolls → execute's plan → bucket list. One worker, so the
    review runs hero by hero (~3 s each on a Mac, slower in a browser) and reports each one."""
    boot()
    _normalize()
    _reindex()
    heroes = json.loads((ROOT / "data/roster/index.json").read_text())["heroes"]
    if not heroes:
        return json.dumps({"ok": False, "error": "add a hero first"})
    # the review measures every gain against the power the game shows (the owner's phone always reads it)
    no_power = [n for n in heroes if not ((_hero(n).get("stats") or {}).get("power"))]
    if no_power:
        return json.dumps({"ok": False, "error": "add the power (as the game shows it) for: " + ", ".join(no_power)},
                          ensure_ascii=False)
    import review.engine as E
    import review.plan as P
    import review.rerolls as R
    n = len(heroes)
    seen = {"review": set(), "rerolls": set()}  # the reroll planner plans a hero again after a recompute
    analyze, plan_hero = E.analyze, R.plan_hero

    def analyze_one(name, *a, **k):
        _report({"step": "review", "hero": name, "done": min(len(seen["review"]), n - 1), "total": n})
        seen["review"].add(name)
        return analyze(name, *a, **k)

    def plan_one(name, *a, **k):
        _report({"step": "rerolls", "hero": name, "done": min(len(seen["rerolls"]), n - 1), "total": n})
        seen["rerolls"].add(name)
        return plan_hero(name, *a, **k)

    E.analyze, R.plan_hero = analyze_one, plan_one
    try:
        P.run(workers=1)
        if rerolls:
            R.run(workers=1)
        _report({"step": "plan"})
        argv = sys.argv
        sys.argv = ["build_plan.py"]
        try:
            runpy.run_path(str(ROOT / "tools/execute/build_plan.py"), run_name="__main__")
        finally:
            sys.argv = argv
        _report({"step": "bucket"})
        import bucket.store
        bucket.store.regenerate(force=True)
    except BaseException as e:  # SystemExit from a script counts as a failure too
        traceback.print_exc()
        return json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}"}, ensure_ascii=False)
    finally:
        E.analyze, R.plan_hero = analyze, plan_hero
    _report({"step": "done", "total": n})
    return json.dumps({"ok": True, "heroes": n})


def _hero(name):
    for f in (ROOT / "data/roster/heroes").glob("*.json"):
        doc = json.loads(f.read_text())
        if (doc.get("hero") or f.stem) == name:
            return doc
    return {}


def _api_recompute(req):
    r = json.loads(recompute())
    return (200 if r["ok"] else 500), r


def _api_rerolls(req):
    import review.rerolls as R
    try:
        R.run(workers=1)
    except Exception:
        return 500, {"ok": False, "output": traceback.format_exc(limit=4)}
    return 200, {"ok": True, "output": ""}
