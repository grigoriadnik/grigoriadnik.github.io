"""Roster-wide: give each owned item and enchant to one hero only (by gain), then the plan per hero, the top moves,
and the craft / Market / dice lists. Writes data/reviews/<hero>.json and data/reviews/summary.json."""
import datetime
import heapq
import json
import multiprocessing

from . import data as D
from . import engine as E

PROMOTION_WEIGHT = 0.9   # a promotion ranks like a craft: big, but its cost is read in the game
MARKET_EXTRA = 0.01      # a Market/Antique item is listed when it beats the plan for that slot by 1% of the power


def _analyze(name):
    return E.analyze(name)


def analyze_all(names, workers=None):
    workers = workers or min(8, multiprocessing.cpu_count() or 1)
    if workers <= 1 or len(names) == 1:
        return [E.analyze(n) for n in names]
    with multiprocessing.get_context("spawn").Pool(workers) as pool:
        return pool.map(_analyze, names)


# ---------------------------------------------------------------- allocation

QUALITY_RANK = {"Common": 0, "Normal": 0, "Superior": 1, "Flawless": 2, "Epic": 3, "Legendary": 4}


class Stock:
    """Enchants in storage, by card. An item takes only enchants of its own quality or better (the game's picker:
    "Required quality: Epic", execute step S01). A card whose quality was not read (inventory.json before roster
    added `quality`) counts as fitting, and the option says so (`enchantQuality`)."""

    def __init__(self, cards):
        self.cards = [{"item": c["item"], "quality": c.get("quality"), "count": c.get("count") or 0} for c in cards]
        self.quality_read = any(c["quality"] in QUALITY_RANK for c in self.cards)

    def _fitting(self, name, quality):
        need = QUALITY_RANK.get(quality, 0)
        known = [c for c in self.cards if c["item"] == name and c["count"] > 0 and c["quality"] in QUALITY_RANK
                 and QUALITY_RANK[c["quality"]] >= need]
        unread = [c for c in self.cards if c["item"] == name and c["count"] > 0 and c["quality"] not in QUALITY_RANK]
        return sorted(known, key=lambda c: QUALITY_RANK[c["quality"]]) + unread  # the lowest card that fits first

    def has(self, name, quality):
        return bool(name) and bool(self._fitting(name, quality))

    def take(self, name, quality):
        card = self._fitting(name, quality)[0]
        card["count"] -= 1
        return card["quality"] if card["quality"] in QUALITY_RANK else "unread"

    def give_back(self, name, quality):
        card = next((c for c in self.cards if c["item"] == name and (c["quality"] or "unread") == quality), None)
        if card:
            card["count"] += 1
        else:
            self.cards.append({"item": name, "quality": None if quality == "unread" else quality, "count": 1})

    def left(self):
        out = {}
        for c in self.cards:
            if c["count"]:
                out.setdefault(c["item"], {})
                q = c["quality"] or "?"
                out[c["item"]][q] = out[c["item"]].get(q, 0) + c["count"]
        return {k: (sum(v.values()) if not self.quality_read else v) for k, v in sorted(out.items())}


def _substitute(hero, opt, stock):
    """The same option with enchants the stock still has for this item's quality: the next tier of the element, the
    next best spirit (the item's own enchants cost nothing). Re-measured with calc.diff."""
    it = D.item(opt["item"])
    q = opt["quality"]
    ch = dict(opt["change"])
    needs = dict(opt["needs"])
    own = opt.get("own") or {}
    if needs.get("element") and not stock.has(needs["element"], q):
        etype = D.element_info(needs["element"])["elementType"]
        nxt = next((n for n in D.element_ladder(etype) if stock.has(n, q) and E.fits(it, D.element_info(n))), None)
        el = own.get("element") or nxt
        ch["element"] = el
        needs["element"] = el if el and el != own.get("element") else None
    if needs.get("spirit") and not stock.has(needs["spirit"], q):
        order = [a[1] for a in opt.get("alts") or [] if a[1]] + E.spirit_ranking(hero, opt["change"]["slot"])
        nxt = next((sp for sp in dict.fromkeys(order) if sp == own.get("spirit") or
                    (stock.has(sp, q) and E.fits(it, D.spirit_info(sp)))), None)
        sp = nxt or own.get("spirit")
        ch["spirit"] = sp
        needs["spirit"] = sp if sp and sp != own.get("spirit") else None
    g = hero.gain([ch])
    new = dict(opt, change=ch, needs=needs, gain=g, element=ch["element"] or opt["element"] if opt["elementBuiltIn"] else ch["element"],
               spirit=ch["spirit"] or opt["spirit"] if opt["spiritBuiltIn"] else ch["spirit"],
               gainPct=round(100 * g["power"] / hero.power, 2) if hero.power else None,
               score=g["power"] * opt.get("weight", E.WEIGHT[opt["kind"]]), substituted=True)
    new["notes"] = E.notes_for({"sp": ch["spirit"]})
    return new


def _freed_item(r, s):
    """The item a slot gives up when the plan changes it: it goes back to storage with its enchants."""
    c = s["current"]
    return {"key": f"{r['id']}/{s['slot']}", "item": c["item"], "quality": c["quality"], "element": c["element"],
            "spirit": c["spirit"], "from": r["id"], "fromSlot": s["slot"]}


def _freed_option(hero, n, f, plan_gain):
    it = D.item(f["item"])
    ch = {"slot": n, "item": f["item"], "quality": f["quality"], "element": f["element"], "spirit": f["spirit"]}
    g = hero.gain([ch])
    bel, bsp = D.built_in(it)
    return {"kind": "freed", "rank": 1, "label": f"Από τον {f['from']} (το βγάζει το πλάνο του)",
            "detail": f"{f['from']} slot {f['fromSlot']}: μετά από εκείνη την αλλαγή", "item": f["item"],
            "tier": it["tier"], "type": it["type"], "quality": f["quality"], "element": f["element"],
            "elementBuiltIn": bool(bel and f["element"] == bel), "spirit": f["spirit"],
            "spiritBuiltIn": bool(bsp and f["spirit"] == bsp),
            "needs": {"item": None, "element": None, "spirit": None, "freed": f["key"]},
            "own": {"element": f["element"], "spirit": f["spirit"]}, "after": f"{f['from']} slot {f['fromSlot']}",
            "gain": g, "gainPct": round(100 * g["power"] / hero.power, 2) if hero.power else None, "gems": 0,
            "change": ch, "alts": [], "notes": E.notes_for({"sp": f["spirit"]}),
            "planGain": plan_gain, "planScore": plan_gain, "score": plan_gain, "weight": 1.0,
            "enchantStatus": "ready", "nowGain": plan_gain, "doNow": True, "enchantsMissing": {}}


def allocate(reviews):
    """Lazy greedy over every slot's best option, highest weighted gain first. Each option is measured on top of
    the moves the hero already got (calc.diff of the whole plan), so two changes that only work alone (e.g. both
    dropping the element under a skill threshold) are not both taken. An option whose item or enchant ran out is
    re-measured with what is left, or the slot's next option is tried. Then the items the plan takes off heroes are
    offered to the other slots (reuse_freed)."""
    items_left = {e["key"]: e["count"] for e in D.inventory_items()}
    stock = Stock(D.inventory()["enchants"])
    heroes, heap, used_items, used_ench = {}, [], {}, {}
    plans = {}   # hero -> {slot: change}
    short = {}   # enchant -> {(hero, slot): {"hero", "slot", "item", "lost"}}: moves the stock could not cover
    by_id = {r["id"]: r for r in reviews}
    tie = 0

    def push(score, hid, n, idx):
        nonlocal tie
        heapq.heappush(heap, (-score, tie, hid, n, idx))
        tie += 1
    for r in reviews:
        plans[r["id"]] = {}
        for s in r["slots"]:
            s["recommended"] = None
            if s["choices"]:
                push(s["choices"][0]["score"], r["id"], s["slot"], 0)
    blocked = {}  # hero -> [(slot, choice index)]: moves that would give the hero a second Artifact
    while heap or blocked:
        if not heap:  # what is still blocked: the hero keeps its Artifact, so those slots try their next option
            for bhid, rows in blocked.items():
                for bn, bidx in rows:
                    bs = by_id[bhid]["slots"][bn - 1]
                    bo = bs["choices"][bidx]
                    seen = bs.setdefault("artifactBlocked", [])
                    if not any(x["item"] == bo["item"] and x["quality"] == bo["quality"] for x in seen):
                        seen.append({"item": bo["item"], "quality": bo["quality"], "gain": bo["gain"]["power"],
                                     "with": D.artifact_slots(heroes[bhid].raw, list(plans[bhid].values()))})
                    if bidx + 1 < len(bs["choices"]):
                        push(bs["choices"][bidx + 1]["score"], bhid, bn, bidx + 1)
            blocked = {}
            continue
        neg, _, hid, n, idx = heapq.heappop(heap)
        r = by_id[hid]
        s = r["slots"][n - 1]
        opt = s["choices"][idx]
        hero = heroes.get(hid) or heroes.setdefault(hid, E.Hero(hid))

        def next_choice():
            if idx + 1 < len(s["choices"]):
                push(s["choices"][idx + 1]["score"], hid, n, idx + 1)
        inv = opt["needs"].get("item")
        if inv and items_left.get(inv, 0) < 1:
            s.setdefault("taken", []).append({"item": opt["item"], "quality": opt["quality"], "gain": opt["gain"]["power"],
                                              "to": used_items.get(inv, [])})
            next_choice()
            continue
        q = opt["quality"]
        # The item is chosen with its target enchants (the owner wants the best item, 2026-10-30). Enchants the
        # stock has (of the item's quality or better) are taken; the others go to enchantsShort, to craft or buy,
        # and `nowGain` says what the move gives before they arrive (their slots left empty: no stopgap enchant).
        missing = {k: v for k, v in opt["needs"].items() if k in ("element", "spirit") and v and not stock.has(v, q)}
        plan = list(plans[hid].values())
        if len(D.artifact_slots(hero.raw, plan + [opt["change"]])) > 1:
            blocked.setdefault(hid, []).append((n, idx))  # waits until the hero's other Artifact comes off
            continue
        before = hero.gain(plan)["power"] if plan else 0
        marginal = hero.gain(plan + [opt["change"]])["power"] - before
        if marginal < hero.min_gain():
            next_choice()
            continue
        score = marginal * opt.get("weight", E.WEIGHT[opt["kind"]])
        if score < -neg - max(50, 0.02 * -neg):   # worth less inside the plan than alone: re-queue at its real worth
            opt["planGain"] = marginal
            push(score, hid, n, idx)
            continue
        if inv:
            items_left[inv] -= 1
            used_items.setdefault(inv, []).append(f"{hid} slot {n}")
        opt["enchantQuality"] = {}
        for k in ("element", "spirit"):
            x = opt["needs"].get(k)
            if x and k not in missing:
                opt["enchantQuality"][k] = stock.take(x, q)
                used_ench.setdefault(x, []).append(f"{hid} slot {n}")
        opt["enchantsMissing"] = {k: f"{v} ({q}+)" if q != "Legendary" else f"{v} (Legendary)" for k, v in missing.items()}
        if missing:
            own = opt.get("own") or {}
            now = dict(opt["change"], **{k: own.get(k) for k in missing})
            opt["nowGain"] = hero.gain(plan + [now])["power"] - before
            opt["enchantStatus"] = "waits"
            for k, name in missing.items():
                row = short.setdefault(name, {}).setdefault((hid, n), {"hero": hid, "slot": n, "item": opt["item"],
                                                                       "quality": q, "lost": 0})
                row["lost"] = max(row["lost"], marginal - opt["nowGain"])
        else:
            opt["nowGain"] = marginal
            opt["enchantStatus"] = "ready"
        # Do it now: all its enchants are in stock, or the item alone (missing enchant slots empty) already adds
        # enough; the missing enchant goes on later without wasting anything.
        opt["doNow"] = opt["nowGain"] >= hero.min_gain()
        opt["planGain"] = marginal
        opt["planScore"] = score
        plans[hid][n] = opt["change"]
        s["recommended"] = opt
        for bn, bidx in blocked.pop(hid, []):  # an Artifact may have come off: check the waiting moves again
            push(by_id[hid]["slots"][bn - 1]["choices"][bidx]["score"], hid, bn, bidx)
    for r in reviews:
        heroes.setdefault(r["id"], E.Hero(r["id"]))
    freed_used = reuse_freed(reviews, heroes, plans, items_left, stock, used_items, used_ench)
    inv_names = {e["key"]: f"{e['item']} ({e['quality']})" for e in D.inventory_items()}
    shortage = []
    for name, rows in short.items():
        rows = sorted(rows.values(), key=lambda x: -x["lost"])
        by_q = {}
        for x in rows:
            by_q[x.get("quality") or "?"] = by_q.get(x.get("quality") or "?", 0) + 1
        shortage.append({"enchant": name, "count": len(rows), "lost": sum(x["lost"] for x in rows), "for": rows,
                         "minQuality": by_q})
    shortage.sort(key=lambda x: -x["lost"])
    return {"itemsUsed": {inv_names[k]: v for k, v in used_items.items() if v},
            "enchantsUsed": {k: {"count": len(v), "to": v} for k, v in sorted(used_ench.items()) if v},
            "enchantsLeft": stock.left(), "enchantQualityRead": stock.quality_read,
            "enchantsShort": shortage, "freedUsed": freed_used}, heroes


def reuse_freed(reviews, heroes, plans, items_left, stock, used_items, used_ench):
    """Items the plan takes off a hero (with their enchants) go back to storage: give each to the slot where it adds
    most on top of that hero's plan, if that beats the slot's own move. Greedy, re-measured after every pick; a
    slot that gives up its move frees its inventory item and enchants, and a slot that changes frees its item."""
    by_id = {r["id"]: r for r in reviews}
    pool = {}
    for r in reviews:
        for s in r["slots"]:
            if s["recommended"] and s["recommended"]["kind"] != "enchant" and s["current"]["item"]:
                f = _freed_item(r, s)
                pool[f["key"]] = f
    table = {}

    def measure(fkey, hid):
        f, hero = pool[fkey], heroes[hid]
        it = D.item(f["item"])
        if not it or it["tier"] > hero.max_tier:
            return
        plan = plans[hid]
        base = hero.gain(list(plan.values()))["power"] if plan else 0
        for n in range(1, 7):
            if (hid, n) == (f["from"], f["fromSlot"]) or not D.hr.item_fits(hero.cls, n, it):
                continue
            new = dict(plan)
            new[n] = {"slot": n, "item": f["item"], "quality": f["quality"], "element": f["element"], "spirit": f["spirit"]}
            if len(D.artifact_slots(hero.raw, list(new.values()))) > 1:
                table.pop((fkey, hid, n), None)
                continue
            d = hero.gain(list(new.values()))["power"] - base
            if d >= hero.min_gain():
                table[(fkey, hid, n)] = d
            else:
                table.pop((fkey, hid, n), None)
    for fkey in list(pool):
        for hid in heroes:
            measure(fkey, hid)
    used = []
    while table:
        (fkey, hid, n), d = max(table.items(), key=lambda kv: kv[1])
        f, hero, r = pool.pop(fkey), heroes[hid], by_id[hid]
        s = r["slots"][n - 1]
        prev = s["recommended"]
        if prev:  # the slot gives up its own move: its stored item and enchants go back
            inv = prev["needs"].get("item")
            if inv:
                items_left[inv] += 1
                used_items[inv].remove(f"{hid} slot {n}")
            for k, quality in (prev.get("enchantQuality") or {}).items():  # only the cards it really took
                x = prev["needs"].get(k)
                if x:
                    stock.give_back(x, quality)
                    used_ench[x].remove(f"{hid} slot {n}")
            if prev["kind"] == "freed":
                back = pool[prev["needs"]["freed"]] = next(x for x in used if x["key"] == prev["needs"]["freed"])
                used.remove(back)
            s.setdefault("replaced", []).append({"item": prev["item"], "quality": prev["quality"], "kind": prev["kind"]})
        elif s["current"]["item"]:
            nf = _freed_item(r, s)
            pool[nf["key"]] = nf
        rest = [c for k, c in plans[hid].items() if k != n]
        with_it = hero.gain(rest + [{"slot": n, "item": f["item"], "quality": f["quality"], "element": f["element"],
                                     "spirit": f["spirit"]}])["power"]
        opt = _freed_option(hero, n, f, with_it - (hero.gain(rest)["power"] if rest else 0))
        opt["overPrevious"] = d
        s["recommended"] = opt
        plans[hid][n] = opt["change"]
        src = by_id[f["from"]]["slots"][f["fromSlot"] - 1]
        src["freedTo"] = f"{hid} slot {n}"
        used.append(dict(f, to=hid, toSlot=n, gain=opt["planGain"], overPrevious=d))
        for k in [k for k in table if k[0] == fkey or k[1] == hid]:
            del table[k]
        for key in list(pool):
            measure(key, hid)
        for key in [k for k in pool if k not in {x[0] for x in table}]:
            for h2 in heroes:
                if h2 != hid:
                    measure(key, h2)
    return [{"item": u["item"], "quality": u["quality"], "element": u["element"], "spirit": u["spirit"],
             "from": f"{u['from']} slot {u['fromSlot']}", "to": f"{u['to']} slot {u['toSlot']}", "gain": u["gain"],
             "overPrevious": u["overPrevious"]}
            for u in used]


def allocate_seeds(reviews):
    """Seeds in storage go to the heroes that gain most per seed, up to the cap of 40 (no blossoms)."""
    left = {name: D.consumable(name) for name in E.SEED_ITEM.values()}
    wants = [(r, stat, w) for r in reviews for stat, w in (r.get("seeds") or {}).items()]
    wants.sort(key=lambda x: -x[2]["gain"] / x[2]["need"])
    for r, stat, w in wants:
        w["given"] = min(w["need"], left[w["item"]])
        left[w["item"]] -= w["given"]
        if w["given"] < w["need"]:
            w["gain"] = round(w["gain"] * w["given"] / w["need"])  # partial: roughly in proportion
    return left


# ---------------------------------------------------------------- per hero after allocation

def finish(r, hero):
    changes = [s["recommended"]["change"] for s in r["slots"] if s["recommended"]]
    free = [s["recommended"]["change"] for s in r["slots"] if s["recommended"] and s["recommended"]["kind"] in ("enchant", "inventory", "freed")]
    now = []
    for s in r["slots"]:
        o = s["recommended"]
        if o and o.get("doNow", True):
            own = o.get("own") or {}
            now.append(dict(o["change"], **{k: own.get(k) for k in (o.get("enchantsMissing") or {})}))
    plan = D.diff(hero.raw, changes) if changes else None
    free_res = D.diff(hero.raw, free) if free else None
    now_res = D.diff(hero.raw, now) if now else None
    r["plan"] = {"changes": changes, "power": plan["stats"]["power"] if plan else hero.power,
                 "nowChanges": now, "nowPower": now_res["stats"]["power"] if now_res else hero.power,
                 "gain": D.delta(plan) if plan else {k: 0 for k in D.STAT_KEYS},
                 "freePower": free_res["stats"]["power"] if free_res else hero.power}
    r["score"]["afterPlan"] = r["plan"]["power"]
    r["score"]["afterPlanPct"] = round(100 * r["plan"]["power"] / r["score"]["ceiling"], 1) if r["score"]["ceiling"] else None
    for s in r["slots"]:
        rec = s["recommended"]
        s["verdict"] = "change" if rec else "keep"
        if rec and rec["change"].get("spirit") == "Tomb-Bound Spirit":
            fb = next((a for a in rec.get("alts") or [] if a[1] != "Tomb-Bound Spirit"), None)
            if fb:
                ch = dict(rec["change"], element=fb[0] or rec["change"]["element"], spirit=fb[1])
                g = hero.gain([ch])["power"]
                rec["withoutTombBound"] = {"spirit": fb[1], "gain": g}
                rec["notes"] = rec.get("notes", []) + [f"Χωρίς Tomb-Bound (με {fb[1]}): +{D.gr(g)} power"]
        s["legendary"] = E.legendary(hero, s["slot"], rec)
        base = rec["gain"]["power"] if rec else 0
        s["marketBetter"] = None
        for m in s["buy"]:
            if rec and m["item"] == rec["item"] and m["quality"] == rec["quality"]:
                continue
            if m["gain"]["power"] - base >= max(hero.min_gain(), MARKET_EXTRA * hero.power):
                s["marketBetter"] = dict(m, extraPower=m["gain"]["power"] - base)
            break
        s["alternatives"] = alternatives(s, rec)
        s["choices"] = s["choices"][:6]
    r.pop("legendary", None)
    r["gaps"] = gaps(r, hero)
    return r


ALT_CLOSE = 0.75  # an alternative item is listed when it gives at least 75% of the recommended item's gain


def alternatives(s, rec):
    """1–2 other items for the slot, close in gain, that are not too rare: the owner buys whichever he finds."""
    if not rec or rec["kind"] in ("enchant", "freed"):
        return []
    best = rec["gain"]["power"]
    out = []
    for o in s.get("pool") or []:
        if o["item"] == rec["item"] or o["kind"] == "enchant" or o["gain"] < ALT_CLOSE * best:
            continue
        out.append(dict(o, closePct=round(100 * o["gain"] / best) if best else None))
        if len(out) == 2:
            break
    return out


def _enchant_text(o):
    el = o["element"] + (" (built in)" if o.get("elementBuiltIn") else "") if o.get("element") else "χωρίς element"
    sp = o["spirit"] + (" (built in)" if o.get("spiritBuiltIn") else "") if o.get("spirit") else "χωρίς spirit"
    return f"{el} · {sp}"


def move_text(r, s, o):
    cur = s["current"]
    if o["kind"] == "enchant":
        what = []
        if o["needs"].get("element"):
            what.append(f"element → {o['needs']['element']}")
        if o["needs"].get("spirit"):
            what.append(f"spirit → {o['needs']['spirit']}")
        return f"{cur['item']}: {', '.join(what)}"
    head = {"inventory": "φόρεσε από την αποθήκη", "craft": "craft", "market": "αγόρασε από Market",
            "special": "αν το έχεις", "freed": f"πάρε αυτό που βγάζει ο {o.get('after', '?')}"}[o["kind"]]
    return f"{head}: {o['item']} (T{o['tier']}, {o['quality']}) αντί για {cur['item']} ({cur['quality']}) · {_enchant_text(o)}"


def gaps(r, hero):
    out = []
    p = r.get("promotion")
    if p:
        out.append({"kind": "promotion", "gain": p["gain"],
                    "text": f"Όχι promoted: promotion σε {p['to']} = +{D.gr(p['gain'])} power (+{p['gainPct']}%), "
                            f"ξεκλειδώνει T4 skills/innate ({p['innate']['to']})"
                            + (" και 1 skill slot ακόμα (το νέο skill δεν μετράει στο κέρδος)." if p.get("extraSkillSlot") else ".")})
    er = r["elementReview"]
    if er["status"] == "short" or (p and p["elementNeed"] and er["used"] < p["elementNeed"]):
        out.append({"kind": "element", "gain": None, "text": er["text"]})
    for sk in r["skills"]:
        if sk["reroll"]:
            out.append({"kind": "skill", "gain": None,
                        "text": f"Skill {sk['name']} ({sk['rating'] or 'χωρίς rating'}): υποψήφιο για reroll — "
                                f"{round(100 * sk.get('pBetter', 0))}% να βγει καλύτερο, {round(100 * sk.get('pWorse', 0))}% χειρότερο."})
    given = [(stat, w) for stat, w in (r.get("seeds") or {}).items() if w.get("given")]
    if given:
        out.append({"kind": "seeds", "gain": sum(w["gain"] for _, w in given),
                    "text": "Seeds: " + ", ".join(f"{w['given']} {w['item']} (έχει {w['have']}{'' if w['sure'] else '?'}) +{D.gr(w['gain'])}"
                                                  for _, w in given) + " power."})
    low = [s for s in r["slots"] if s["current"]["quality"] in ("Normal", "Superior", "Flawless")]
    if low:
        out.append({"kind": "quality", "gain": None,
                    "text": f"{len(low)} items κάτω από Epic: " + ", ".join(f"slot {s['slot']} {s['current']['item']} ({s['current']['quality']})" for s in low)})
    for s in sorted(r["slots"], key=lambda s: -((s["recommended"] or {}).get("planGain") or 0)):
        o = s["recommended"]
        if o and o["planGain"] >= 0.03 * hero.power:
            out.append({"kind": "slot", "slot": s["slot"], "gain": o["planGain"],
                        "text": f"Slot {s['slot']}: {move_text(r, s, o)} = +{D.gr(o['planGain'])} power "
                                f"(+{round(100 * o['planGain'] / hero.power, 1)}%)"})
    return out


# ---------------------------------------------------------------- roster lists

def hero_power(r):
    return r["score"]["current"] or 1


def summary(reviews, alloc):
    moves = []
    for r in reviews:
        p = r.get("promotion")
        if p and p["gain"] > 0:
            moves.append({"hero": r["id"], "class": r["class"], "slot": None, "kind": "promotion",
                          "text": f"Promotion σε {p['to']}", "gain": p["gain"], "gainPct": p["gainPct"],
                          "score": p["gain"] * PROMOTION_WEIGHT, "gems": None, "cost": p["cost"]})
        for stat, w in (r.get("seeds") or {}).items():
            if w.get("given"):
                moves.append({"hero": r["id"], "class": r["class"], "slot": None, "kind": "seeds", "item": w["item"],
                              "text": f"{w['given']} {w['item']} (έχει {w['have']}{'' if w['sure'] else ', αβέβαιο'})",
                              "gain": w["gain"], "gainPct": round(100 * w["gain"] / hero_power(r), 2),
                              "score": w["gain"] * (1.0 if w["sure"] else 0.5), "gems": 0,
                              "notes": [] if w["sure"] else ["Πόσα seeds έχει δεν φαίνεται στο παιχνίδι· το calc δεν "
                                                             "μπόρεσε να το βγάλει από τα stats εδώ"]})
        for s in r["slots"]:
            o = s["recommended"]
            if o:
                moves.append({"hero": r["id"], "class": r["class"], "slot": s["slot"], "kind": o["kind"],
                              "label": o["label"], "text": move_text(r, s, o), "item": o["item"],
                              "quality": o["quality"], "element": o["element"], "spirit": o["spirit"],
                              "gain": o["planGain"], "gainAlone": o["gain"]["power"],
                              "gainPct": round(100 * o["planGain"] / hero_power(r), 2), "score": o["planScore"],
                              "gems": o["gems"], "notes": o.get("notes", []), "after": o.get("after"),
                              "enchantQuality": o.get("enchantQuality"), "enchantStatus": o.get("enchantStatus"),
                              "enchantsMissing": o.get("enchantsMissing"), "nowGain": o.get("nowGain"),
                              "doNow": o.get("doNow", True), "availability": o.get("availability")})
    moves.sort(key=lambda m: -m["score"])
    craft = [m for m in moves if m["kind"] == "craft"]
    for m in craft:
        _, info = D.blueprints()
        bp = info.get(m["item"]) or {}
        m["amountCrafted"] = bp.get("amountCrafted")
        m["qualityTarget"] = "Epic"
    craft.sort(key=lambda m: -m["gain"])
    market = []   # the Market buys the plan recommends: the owner's shopping list, with 1–2 alternatives each
    rare = []     # items too rare to plan on that would beat the plan: only if the owner happens to find one
    for r in reviews:
        for s in r["slots"]:
            o = s["recommended"]
            if o and o["kind"] == "market":
                market.append({"hero": r["id"], "slot": s["slot"], "kind": "market", "label": o["label"],
                               "detail": o["detail"], "availability": o.get("availability"), "item": o["item"],
                               "tier": o["tier"], "quality": o["quality"], "element": o["element"], "spirit": o["spirit"],
                               "gain": o.get("planGain", o["gain"]["power"]), "gainPct": o["gainPct"],
                               "instead": s["current"]["item"], "cost": o.get("cost"), "notes": o.get("notes", []),
                               "alternatives": [{k: a[k] for k in ("item", "tier", "quality", "kind", "label", "detail",
                                                                    "availability", "gain", "closePct")}
                                                for a in s.get("alternatives") or []]})
            m = s.get("marketBetter")
            if m and m["kind"] == "special":
                rare.append({"hero": r["id"], "slot": s["slot"], "kind": m["kind"], "label": m["label"],
                             "detail": m["detail"], "item": m["item"], "tier": m["tier"], "quality": m["quality"],
                             "element": m["element"], "spirit": m["spirit"], "gain": m["gain"]["power"],
                             "extraPower": m["extraPower"], "gainPct": m["gainPct"],
                             "instead": (s["recommended"] or {}).get("item") or s["current"]["item"],
                             "notes": m.get("notes", [])})
    market.sort(key=lambda m: -m["gain"])
    rare.sort(key=lambda m: -m["extraPower"])
    dice_stock = {d: D.consumable(d) for d in ("Basic Skill Die", "Super Skill Die", "Mega Skill Die", "Perfect Skill Die")}
    dice = []
    for r in reviews:
        for sk in r["skills"]:
            if sk["reroll"]:
                dice.append({"hero": r["id"], "class": r["class"], "power": r["power"]["shown"], "skill": sk["name"],
                             "tierName": sk["tierName"], "rating": sk["rating"], "rarity": sk["rarity"],
                             "skillSlot": sk["skillSlot"], "pBetter": sk.get("pBetter"), "pWorse": sk.get("pWorse"),
                             "better": sk.get("better", [])[:6],
                             "die": "Perfect Skill Die" if dice_stock["Perfect Skill Die"] else "Mega Skill Die"})
    dice.sort(key=lambda d: (-E.RATING_RANK.get(d["rating"], 6), -(d["power"] or 0)))
    heroes = [{"id": r["id"], "class": r["class"], "level": r["level"], "promoted": r["promoted"],
               "powerShown": r["power"]["shown"], "power": r["score"]["current"], "ceiling": r["score"]["ceiling"],
               "pct": r["score"]["pct"], "afterPlan": r["score"]["afterPlan"], "afterPlanPct": r["score"]["afterPlanPct"],
               "confidence": r["confidence"]["level"], "confidencePct": r["confidence"]["diffPct"],
               "promotionGain": (r.get("promotion") or {}).get("gain"),
               "changes": sum(1 for s in r["slots"] if s["recommended"])} for r in reviews]
    return {
        "generatedAt": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "roster": D.roster_captured(),
        "heroes": heroes,
        "topMoves": moves[:10],
        "allMoves": moves,
        "craft": craft,
        "enchantsShort": alloc["enchantsShort"],
        "rare": rare,
        "market": market,
        "dice": dice,
        "diceStock": dice_stock,
        "gems": D.inventory().get("gems"),
        "gemsNeeded": 0,
        "allocation": alloc,
        "notes": [
            "Κέρδη = calc.diff (power του παιχνιδιού όπως το υπολογίζει το calc). Το calc ακόμα ρυθμίζεται: κοίτα το "
            "confidence κάθε ήρωα.",
            "Κάθε item και enchant της αποθήκης δίνεται σε έναν ήρωα, σε όποιον κερδίζει περισσότερο.",
            "Κανένα βήμα του πλάνου δεν θέλει gems. Market: συνήθως gold. Promotion: το κόστος δεν το έχουμε.",
            "Ανά slot προτείνεται το καλύτερο item από όποια πηγή (αποθήκη, craft, Market)· μόνο όταν δύο απέχουν "
            "λίγα % μπαίνει αυτό που έχεις ή φτιάχνεις. Τα πολύ σπάνια (πρόσφατα pack/event) δεν προτείνονται· κάθε "
            "αγορά έχει 1–2 εναλλακτικά κοντά σε κέρδος.",
            "Κάθε item προτείνεται με τα enchants-στόχο. Όσα δεν έχεις σε αυτή την ποιότητα είναι στα «Enchants που "
            "δεν φτάνουν»· «τώρα» = τι δίνει η κίνηση πριν έρθουν (χωρίς προσωρινό enchant που θα πεταχτεί).",
            "Reroll και Legendary είναι τύχη: μπορεί να βγουν χειρότερα. Τα συζητάμε ένα-ένα πριν.",
            "Tomb-Bound: +20% στο άθροισμα των bonus του item, όπως το έδειξε το παιχνίδι (βήμα S01) και το μετράει πλέον "
            "το calc. Με affinity (+50%) δεν έχει ελεγχθεί.",
        ] + ([
            "Ένα item παίρνει μόνο enchants της ποιότητάς του ή καλύτερης (Epic item → Epic ή Legendary enchant). "
            f"Από τις {sum(1 for c in D.inventory()['enchants'])} κάρτες enchants μόνο "
            f"{sum(1 for c in D.inventory()['enchants'] if c.get('quality') in ('Epic', 'Legendary'))} είναι Epic+, κι αυτό "
            "κόβει πολλές κινήσεις: δες «Enchants που δεν φτάνουν»."
        ] if alloc.get("enchantQualityRead") else [
            "Ένα item παίρνει μόνο enchants της ποιότητάς του ή καλύτερης. Η ποιότητα των enchants της αποθήκης δεν έχει "
            "διαβαστεί ακόμα, οπότε το μοίρασμα δεν τη λαμβάνει υπόψη: δες το «Required quality» στο picker."
        ]),
    }


def new_items():
    """Item names in data/items.json that the last review did not know (new game items)."""
    seen_path = D.REVIEWS / "items_seen.json"
    names = sorted(i["name"] for i in D.hr.items())
    old = json.loads(seen_path.read_text()) if seen_path.exists() else None
    seen_path.write_text(json.dumps(names, ensure_ascii=False, indent=0) + "\n")
    return [] if old is None else sorted(set(names) - set(old))


def run(names=None, workers=None, champions=None):
    """champions: also review the champions (review/champions.py); by default only on a run of every hero."""
    champions = names is None if champions is None else champions
    names_all = names is None
    names = names or list(D.heroes())
    reviews = analyze_all(names, workers)
    alloc, heroes = allocate(reviews)
    alloc["seedsLeft"] = allocate_seeds(reviews)
    for r in reviews:
        finish(r, heroes.get(r["id"]) or E.Hero(r["id"]))
    D.REVIEWS.mkdir(parents=True, exist_ok=True)
    s = summary(reviews, alloc)
    s["newItems"] = new_items()
    from . import rerolls as RR
    for r in reviews:
        r["generatedAt"] = s["generatedAt"]
        r["classSkills"] = RR.class_skills_for(r["id"])
        (D.REVIEWS / f"{r['id']}.json").write_text(json.dumps(r, ensure_ascii=False, indent=1) + "\n")
    if champions:  # after the heroes: the champions take the enchants and seeds the heroes' plan leaves
        from . import champions as CH
        CH.run(s)
    (D.REVIEWS / "summary.json").write_text(json.dumps(s, ensure_ascii=False, indent=1) + "\n")
    if names_all:  # the reroll planner reads the same roster; it writes rerolls.json and adds its plan to the files
        RR.run(workers=workers)
    return reviews, s
