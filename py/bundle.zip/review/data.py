"""What the review reads: the roster (data/roster/), the game data (data/*.json through the hero-review helpers)
and calc. Read-only; nothing here writes."""
import collections
import copy
import datetime
import importlib.util
import json
import sys
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
ROSTER = DATA / "roster"
REVIEWS = DATA / "reviews"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from calc import compute, diff  # noqa: E402  (the only source of numbers: calc/README.md)


def _hero_review_common():
    path = ROOT / ".claude" / "skills" / "hero-review" / "scripts" / "common.py"
    spec = importlib.util.spec_from_file_location("review_hr_common", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


hr = _hero_review_common()

STAT_KEYS = ("attack", "defense", "hp", "evasion", "critChance", "critDamage", "element", "threat", "power")
QUALITY_ORDER = ["Normal", "Superior", "Flawless", "Epic", "Legendary"]

# Spirits worth trying on a hero: every combat spirit of T9+ whose effect the power number sees.
# Left out: shop/XP spirits (no combat), conditional ones (Dinosaur, Shark, Mundra's: power ignores them),
# Spirit Spirit (a chance to survive, not a stat).
SPIRITS = ["Leviathan Spirit", "Behemoth Spirit", "Tomb-Bound Spirit", "Titan Spirit", "Chimera Spirit",
           "Kraken Spirit", "Ouroboros Spirit", "Griffin Spirit", "Bahamut Spirit", "Tarrasque Spirit",
           "Hydra Spirit", "Carbuncle Spirit", "Phoenix Spirit", "Mammoth Spirit", "Lion Spirit", "Bear Spirit"]


# ---------------------------------------------------------------- roster

def _order(h):
    return (h.get("order") or 999, h["hero"])


@lru_cache(None)
def heroes():
    """Hero name -> roster record, in the game's order (strongest first)."""
    recs = [json.loads(p.read_text()) for p in sorted((ROSTER / "heroes").glob("*.json"))]
    return collections.OrderedDict((h["hero"], h) for h in sorted(recs, key=_order))


def hero(name):
    for k, h in heroes().items():
        if k.lower() == name.strip().lower():
            return copy.deepcopy(h)
    raise KeyError(f"no hero '{name}' in data/roster/heroes/")


@lru_cache(None)
def inventory():
    return json.loads((ROSTER / "inventory.json").read_text())


@lru_cache(None)
def inventory_items():
    """Epic/Legendary gear in storage. A count the phone could not read is 1 (at least one is there)."""
    out = []
    for n, it in enumerate(inventory()["items"]):
        out.append({**it, "key": f"inv{n}", "count": it.get("count") or 1, "countRead": it.get("count") is not None})
    return out


@lru_cache(None)
def enchant_stock():
    """Element and spirit enchants in storage, summed by name (inventory.json has one entry per card)."""
    stock = collections.Counter()
    for e in inventory()["enchants"]:
        stock[e["item"]] += e.get("count") or 0
    return dict(stock)


def consumable(name):
    return next((c["count"] for c in inventory()["consumables"] if c["name"] == name), 0)


@lru_cache(None)
def blueprints():
    """(unlocked names, {name: blueprint record}) — only T13+ of the types the heroes use were read."""
    bp = json.loads((ROSTER / "blueprints.json").read_text())
    info = {b["item"]: b for rows in bp["byType"].values() for b in rows}
    return frozenset(bp["unlocked"]), info


def roster_captured():
    inv = inventory()
    bp = json.loads((ROSTER / "blueprints.json").read_text())
    return {"heroes": max((h.get("capturedAt") or "") for h in heroes().values()),
            "inventory": inv.get("capturedAt"), "blueprints": bp.get("capturedAt")}


# ---------------------------------------------------------------- game data

@lru_cache(None)
def item(name):
    return hr.items_by_name().get(name.lower())


@lru_cache(None)
def type_names():
    return {t["key"]: t["name"] for t in hr._load("lookups.json")["itemTypes"]}


def item_types(it):
    return {it["type"]} | {type_names().get(t) for t in it.get("subTypes") or []} - {None}


@lru_cache(None)
def element_ladder(etype):
    """The element enchants of one element, best first, from T9 up (lower ones are not worth an enchant)."""
    rows = [e for e in hr.element_enchants().values() if e["elementType"] == etype and e["tier"] >= 9]
    return [e["name"] for e in sorted(rows, key=lambda e: -e["tier"])]


@lru_cache(None)
def element_info(name):
    return hr.element_enchants().get(name.lower()) if name else None


@lru_cache(None)
def spirit_info(name):
    return hr.spirits().get(name.lower()) if name else None


@lru_cache(None)
def spirit_by_uid():
    return {s["uid"]: s for s in hr.spirits().values()}


def built_in(it):
    """(element enchant name, spirit name) the item has built in, or None."""
    inn = it.get("innate") or {}
    el = next((e["name"] for e in hr.element_enchants().values() if e["key"] == inn.get("element")), None)
    sp = spirit_by_uid().get(inn.get("spirit"))
    return el, (sp["name"] if sp else None)


def affinity_spirit(it):
    uid = (it.get("affinity") or {}).get("spirit")
    sp = spirit_by_uid().get(uid) if uid else None
    return sp["name"] if sp else None


# ---------------------------------------------------------------- where an item comes from

@lru_cache(None)
def official_by_name():
    """The official blueprint data calc fetched (calc/data/official_items.json): 'excl' (pack / chest / special,
    or none for a regular research blueprint) and 'releaseAt'."""
    path = ROOT / "calc" / "data" / "official_items.json"
    return {it["name"]: it for it in json.loads(path.read_text())["items"].values()} if path.exists() else {}


TODAY = datetime.date.today()
# How easy an item the owner cannot craft is to find on the Market, and how much that weighs when two options are
# close (the owner, 2026-10-30: the best item from any source, but not one too rare to find).
AVAILABILITY = {
    "common": (0.97, "βγαίνει συχνά στο Market (κανονικό blueprint)"),
    "chest": (0.96, "βγαίνει αρκετά συχνά στο Market (blueprint από chest)"),
    "older-pack": (0.93, "βγαίνει πιο αραιά στο Market (παλιό pack/event item, και στο Antique Store)"),
    "new": (0.90, "νέο item: ακόμα λίγο στο Market"),
    "rare": (0.0, "πολύ σπάνιο: μόνο από πρόσφατο pack/event"),
}


def availability(name):
    """common | chest | older-pack | new | rare, from the blueprint's origin and age. A pack/event item reaches
    other players' shops only through the Antique Store or research, and only after a while: under 90 days old, or
    with neither route, it is 'rare' and never recommended."""
    off = official_by_name().get(name) or {}
    src = hr.item_sources().get(name) or {}
    excl = off.get("excl")
    unlock = src.get("unlock") or ""
    rel = off.get("releaseAt")
    age = (TODAY - datetime.date.fromisoformat(rel)).days if rel else None
    if excl is None and not (unlock and "Chest" not in unlock and unlock != "Blacksmith"):
        return "common" if off or src else "new"
    if excl == "chest" or "Chest" in unlock:
        return "new" if age is not None and age < 30 else "chest"
    route = src.get("antiqueTokens") or src.get("researchScrolls")
    if not route or (age is not None and age < 90):
        return "rare"
    return "new" if age is not None and age < 180 else "older-pack"


def item_source(name):
    """How the owner can get an item they do not hold: craft (blueprint unlocked), Market (with how often it shows
    up there), or 'special' = too rare to plan on. Returns {kind, rank, label, detail, availability, weight}."""
    unlocked, info = blueprints()
    src = hr.item_sources().get(name) or {}
    bp = info.get(name) or {}
    how = bp.get("how") or ""
    if name in unlocked:
        crafted = bp.get("amountCrafted")
        return {"kind": "craft", "rank": 2, "label": "Craft (έχεις το blueprint)", "availability": "craft",
                "detail": f"το έχεις φτιάξει {crafted} φορές" if crafted else "blueprint ξεκλείδωτο"}
    av = availability(name)
    weight, text = AVAILABILITY[av]
    unlock = src.get("unlock") or ""
    origin = []
    if unlock and unlock != "Blacksmith":
        origin.append(unlock)
    if src.get("antiqueTokens"):
        origin.append(f"Antique Store {src['antiqueTokens']} tokens")
    if not origin and bp and not bp.get("unlocked") and how:
        origin.append("blueprint κλειδωμένο: " + how.split("!")[0].split(".")[0])
    detail = text + (f" · {', '.join(origin)}" if origin else "")
    if av == "rare":
        return {"kind": "special", "rank": 4, "label": "Σπάνιο — μόνο αν το βρεις", "detail": detail,
                "availability": av, "weight": weight}
    return {"kind": "market", "rank": 3, "label": "Market (από άλλους παίκτες)", "detail": detail,
            "availability": av, "weight": weight}


# ---------------------------------------------------------------- calc

def base_skill_names(h):
    """Skills by their T1 names, so calc.compute takes their tiers from the element (with the shown tier names it
    keeps the game's tier). Needed where review calls compute on a changed hero (promotion, seeds); calc.diff takes
    tiers from the element by itself."""
    tiers = h.get("skillTiers")
    if tiers:
        return [t["skill"] for t in tiers if not t.get("innate")]
    return list(h.get("skills") or [])


def for_compute(h):
    out = copy.deepcopy(h)
    out["skills"] = base_skill_names(h)
    return out


@lru_cache(None)
def artifacts():
    """Artifact item names: the items whose own skill is an artifact skill ('a_…') in calc/data/official_items.json
    (the official blueprint data). The game lets a hero wear one Artifact at a time (execute, 2026-10-30: Rock
    Stompers is not offered to a hero wearing Kiku-Ichimonji; every hero wearing an Artifact wears exactly one)."""
    path = ROOT / "calc" / "data" / "official_items.json"
    names = set()
    if path.exists():
        names = {it["name"] for it in json.loads(path.read_text())["items"].values()
                 if (it.get("skill") or "").startswith("a_")}
    names |= {k for k, v in hr.item_sources().items() if v.get("unlock") == "Major Artifact Chest"}
    return frozenset(names)


def is_artifact(name):
    return bool(name) and name in artifacts()


def artifact_slots(h, changes):
    """Slots that would hold an Artifact after the changes; more than one is not allowed."""
    items = {s.get("slot"): s.get("item") for s in h.get("slots") or h.get("items") or []}  # heroes / champions
    for c in changes:
        items[c["slot"]] = None if c.get("empty") else c.get("item", items.get(c["slot"]))
    return sorted(n for n, it in items.items() if is_artifact(it))


def gr(n):
    """A number the Greek way: 84.238 (thousands with dots)."""
    return f"{n:,}".replace(",", ".")


def delta(res):
    return {k: res["delta"][k] for k in STAT_KEYS}
