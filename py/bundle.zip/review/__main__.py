"""CLI.

    .venv/bin/python -m review                 # review every hero, write data/reviews/, print the roster table
    .venv/bin/python -m review "Hero 6"      # print one hero's saved review (run the first form after a sync)
    .venv/bin/python -m review "Argon"         # one champion's saved review (full name or first name)
    .venv/bin/python -m review --summary       # print the saved top moves and the craft / Market / dice lists
"""
import argparse
import json
import sys
import time

from . import data as D


def fmt(n):
    return "—" if n is None else f"{n:,}".replace(",", ".")


def print_hero(r):
    print(f"## {r['hero']} — {r['class']} ({r['element']}), level {r['level']}, "
          f"{'promoted' if r['promoted'] else 'όχι promoted → ' + (r['promotesTo'] or '?')}")
    sc = r["score"]
    print(f"power {fmt(r['power']['shown'])} (calc {fmt(sc['current'])}) · {sc['pct']}% του καλύτερου δυνατού "
          f"({fmt(sc['ceiling'])}) · μετά το πλάνο {fmt(sc['afterPlan'])} ({sc['afterPlanPct']}%)")
    print(f"σιγουριά: {r['confidence']['level']} — {r['confidence']['text']}")
    print("\nΜεγάλα κενά:")
    for g in r["gaps"] or [{"text": "κανένα μεγάλο"}]:
        print(f"- {g['text']}")
    print("\nSlots:")
    for s in r["slots"]:
        c = s["current"]
        print(f"- slot {s['slot']} ({'/'.join(s['types'])}): {c['item']} T{c['tier']} {c['quality']} · {c['element']} · {c['spirit']}")
        o = s["recommended"]
        if o:
            print(f"    → [{o['label']}] {o['item']} T{o['tier']} {o['quality']} · {o['element']} · {o['spirit']} "
                  f"= +{fmt(o['gain']['power'])} power (+{o['gainPct']}%)")
        else:
            print("    → κράτα το")
        if s.get("marketBetter"):
            m = s["marketBetter"]
            print(f"    · καλύτερο από {m['label']}: {m['item']} T{m['tier']} · {m['element']} · {m['spirit']} = +{fmt(m['gain']['power'])}")
        if s.get("legendary") and s["legendary"]["worth"]:
            print(f"    · Legendary {s['legendary']['item']}: +{fmt(s['legendary']['extraPower'])} ({s['legendary']['extraPct']}%) — τύχη, συζήτηση πρώτα")
    print("\nSkills: " + ", ".join(f"{k['tierName']} [{k['rating']}]" + (" ↻" if k["reroll"] else "") for k in r["skills"]))


def print_summary(s):
    print("Top κινήσεις:")
    for n, m in enumerate(s["topMoves"], 1):
        wait = "" if m.get("enchantStatus") in (None, "ready") else \
            f" · περιμένει {', '.join((m.get('enchantsMissing') or {}).values())}, τώρα {fmt(m.get('nowGain'))}"
        print(f"{n:>2}. {m['hero']} {('slot ' + str(m['slot'])) if m['slot'] else ''}: {m['text']} = +{fmt(m['gain'])} ({m['gainPct']}%) [{m['kind']}]{wait}")
    print("\nCraft:")
    for m in s["craft"]:
        print(f"- {m['item']} ({m['qualityTarget']}) για {m['hero']} slot {m['slot']}: +{fmt(m['gain'])}")
    if s.get("enchantsShort"):
        print("\nEnchants που δεν φτάνουν (craft ή αγορά):")
        for e in s["enchantsShort"]:
            q = ", ".join(f"{k}{'' if k == 'Legendary' else '+'} ×{v}" for k, v in e.get("minQuality", {}).items())
            print(f"- {e['enchant']} ×{e['count']} ({q}): +{fmt(e['lost'])} power περιμένουν ({', '.join(x['hero'] + ' slot ' + str(x['slot']) for x in e['for'])})")
    print("\nΑγορές από Market (με εναλλακτικά):")
    for m in s["market"]:
        alts = "; ".join(f"{a['item']} T{a['tier']} +{fmt(a['gain'])} ({a['closePct']}%)" for a in m.get("alternatives") or [])
        print(f"- {m['item']} T{m['tier']} για {m['hero']} slot {m['slot']}: +{fmt(m['gain'])} — {m['detail']}"
              + (f"\n    εναλλακτικά: {alts}" if alts else ""))
    if s.get("rare"):
        print("\nΣπάνια (μόνο αν τα βρεις):")
        for m in s["rare"][:10]:
            print(f"- {m['item']} T{m['tier']} για {m['hero']} slot {m['slot']}: +{fmt(m['extraPower'])} πάνω από το πλάνο")
    print("\nReroll (τύχη):")
    for d in s["dice"]:
        print(f"- {d['hero']}: {d['skill']} [{d['rating']}] — {round(100 * (d['pBetter'] or 0))}% καλύτερο / "
              f"{round(100 * (d['pWorse'] or 0))}% χειρότερο · {d['die']}")


def print_champion(r):
    print(f"## {r['champion']} — {r['title']} ({r['classType']}, {r['element']}), level {r['level']}, {r['rank']}, "
          f"Titan Soul {'ναι' if r['titanSoul'] else 'όχι'}")
    sc = r["score"]
    print(f"power {fmt(r['power']['shown'])} (calc {fmt(sc['current'])}) · {sc['pct']}% του καλύτερου δυνατού "
          f"({fmt(sc['ceiling'])}) · μετά το πλάνο {fmt(sc['afterPlan'])} ({sc['afterPlanPct']}%)")
    print(f"σιγουριά: {r['confidence']['level']} — {r['confidence']['text']}")
    L = r.get("leader") or {}
    if L:
        print(f"leader: {L.get('name')} T{L.get('tier')} — {L.get('text')}")
        best = (L.get("value") or {}).get("best") or []
        if best:
            print("  ανεβάζει περισσότερο: " + ", ".join(f"{b['hero']} +{fmt(b['gain'])} ({b['gainPct']}%)" for b in best[:3]))
    print("\nΜεγάλα κενά:")
    for g in r["gaps"] or [{"text": "κανένα μεγάλο"}]:
        print(f"- {g['text']}")
    print("\nSlots:")
    for s in r["slots"]:
        c = s["current"]
        print(f"- slot {s['slot']} ({'/'.join(s['types'])}): {c['item']} T{c['tier']} {c['quality']} · {c['element']} · {c['spirit']}")
        o = s["recommended"]
        print(f"    → [{o['label']}] {o['item']} T{o['tier']} {o['quality']} · {o['element']} · {o['spirit']} "
              f"= +{fmt(o['planGain'])} power" if o else "    → κράτα το")
        if s.get("marketBetter"):
            m = s["marketBetter"]
            print(f"    · καλύτερο από {m['label']}: {m['item']} T{m['tier']} · {m['element']} · {m['spirit']} = +{fmt(m['gain']['power'])}")
        if s.get("legendary") and s["legendary"]["worth"]:
            print(f"    · Legendary {s['legendary']['item']}: +{fmt(s['legendary']['extraPower'])} ({s['legendary']['extraPct']}%) — τύχη, συζήτηση πρώτα")
    for p in r.get("powerUps") or []:
        print(f"- {p['text']}")


def print_champion_summary(s):
    if not s.get("champions"):
        return
    print("\nChampions:")
    for c in s["champions"]:
        print(f"{c['id']:<24} power {fmt(c['powerShown']):>7}  {c['pct']:>5}% → {c['afterPlanPct']:>5}%  αλλαγές {c['changes']}"
              f"  leader {c['leader']} → {', '.join(c['leaderBest'])}")
    print("\nTop κινήσεις champions:")
    for n, m in enumerate(s["championMoves"][:10], 1):
        print(f"{n:>2}. {m['champion']} {('slot ' + str(m['slot'])) if m['slot'] else ''}: {m['text']} = +{fmt(m['gain'])} ({m['gainPct']}%) [{m['kind']}]")


def find_saved(name):
    """data/reviews/<hero>.json, else data/reviews/champions/<champion>.json (full or first name)."""
    path = D.REVIEWS / f"{name}.json"
    if path.exists():
        return json.loads(path.read_text())
    for f in sorted((D.REVIEWS / "champions").glob("*.json")):
        if name.lower() in (f.stem.lower(), f.stem.split()[0].lower()):
            return json.loads(f.read_text())
    raise SystemExit(f"Δεν υπάρχει review για «{name}» — τρέξε .venv/bin/python -m review")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m review")
    ap.add_argument("hero", nargs="?")
    ap.add_argument("--summary", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--workers", type=int)
    a = ap.parse_args(argv)
    if a.hero:
        r = find_saved(a.hero)
        print(json.dumps(r, ensure_ascii=False, indent=1) if a.json else "", end="")
        if not a.json:
            print_champion(r) if r.get("kind") == "champion" else print_hero(r)
        return 0
    if a.summary:
        s = json.loads((D.REVIEWS / "summary.json").read_text())
        print_summary(s)
        print_champion_summary(s)
        return 0
    from .plan import run
    t = time.time()
    reviews, s = run(workers=a.workers)
    print(f"{len(reviews)} ήρωες σε {time.time() - t:.0f}s → {D.REVIEWS}")
    for h in s["heroes"]:
        print(f"{h['id']:<10} {h['class']:<13} power {fmt(h['powerShown']):>8}  {h['pct']:>5}% → {h['afterPlanPct']:>5}%"
              f"  αλλαγές {h['changes']}  σιγουριά {h['confidence']}"
              + (f"  promotion +{fmt(h['promotionGain'])}" if h["promotionGain"] else ""))
    if s["newItems"]:
        print(f"νέα items από το προηγούμενο review: {', '.join(s['newItems'])}")
    print()
    print_summary(s)
    print_champion_summary(s)
    return 0


if __name__ == "__main__":
    sys.exit(main())
