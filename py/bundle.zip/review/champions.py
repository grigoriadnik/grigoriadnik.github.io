"""The 11 champions (item 11 of PLAN.md): per champion the best Familiar and Aurasong with element and spirit and
where they come from (owned, craft, Market, then Antique / pack / event), what the next Power Ups give, seeds, a Titan
Soul, and which heroes its leader skill lifts most. Numbers from calc (calc.compute / calc.diff on the champion);
the candidates, enchant choice and sources are the heroes' (engine.py). Champions take the enchants and seeds the
heroes' plan leaves (summary.json → allocation), so the heroes' reviews do not change.

Writes data/reviews/champions/<champion>.json and adds `champions`, `championMoves`, `championCraft`,
`championMarket`, `championAllocation` to data/reviews/summary.json (run() after plan.run).
"""
import collections
import heapq
import json

from . import data as D
from . import engine as E
from . import plan as P
from .data import hr

CHAMPIONS = D.ROSTER / "champions"
OUT = D.REVIEWS / "champions"
SLOT_TYPES = {"slot1": ["Familiar"], "slot2": ["Aurasong"]}
POWER_UPS = (1, 5, 10)


def champions():
    """Champion name -> roster record, in the game's order."""
    recs = [json.loads(p.read_text()) for p in sorted(CHAMPIONS.glob("*.json"))]
    return collections.OrderedDict((c["champion"], c) for c in sorted(recs, key=lambda c: (c.get("order") or 999,
                                                                                          c["champion"])))


class Champion:
    """engine.Hero's interface for a champion: 2 slots (Familiar, Aurasong), the champion's element, Titan Spirit
    only with a Titan Soul (a champion's promotion). The Titan Soul calc infers is fixed once, for speed."""

    def __init__(self, name):
        from calc.champion import champion_data
        raw = champions()[name]
        first = D.compute(raw)
        self.raw = dict(raw, titanSoul=first["titanSoul"])
        self.name = raw["champion"]
        self.h = self.raw
        self.data = champion_data(name)
        self.cls = {"name": self.data["name"], "type": self.data["classType"], "element": self.data["element"],
                    "isPromoted": first["titanSoul"], "equipmentSlots": SLOT_TYPES, "innate": None,
                    "skillUnlockLevels": []}
        self.promoted = first["titanSoul"]
        self.max_tier = hr.max_item_tier(raw.get("level") or 40)
        self.shown = first
        self.base = D.compute(self.raw)
        self.power = self.base["stats"]["power"] or 0
        self.slots = {s["slot"]: s for s in raw.get("items") or []}
        self._cache = {}

    def gain(self, changes):
        key = json.dumps(changes, sort_keys=True)
        if key not in self._cache:
            self._cache[key] = D.delta(D.diff(self.raw, changes))
        return self._cache[key]

    def min_gain(self):
        return max(150, E.MIN_GAIN * self.power)


# ---------------------------------------------------------------- one champion

def power_ups(ch):
    """What the next 1, 5 and 10 Power Ups add, and their champion coins (official sheet: 50 + 10 x X)."""
    r = ch.base
    if r["rank"] < max(int(x) for x in ch.data["ranks"]):
        return []
    coins = ch.data.get("powerUpCoins") or {}
    out = []
    for n in POWER_UPS:
        d = ch.gain([{"powerUps": n}])
        cost = sum(coins.get("base", 0) + coins.get("perPowerUp", 0) * (r["rankPlus"] + k) for k in range(n)) \
            if coins else None
        out.append({"count": n, "gain": d, "coins": cost, "coinsEach": coins.get("text"),
                    "text": f"{n} Power Up{'s' if n > 1 else ''}: +{D.gr(d['power'])} power"
                            + (f" ({D.gr(cost)} {ch.data['name']} coins)" if cost else "")})
    return out


def titan_soul(ch):
    if ch.promoted:
        return None
    d = ch.gain([{"titanSoul": True}])
    return {"gain": d, "stock": D.consumable("Titan Soul"),
            "text": f"Titan Soul: +{D.gr(d['power'])} power τώρα (rank ×1,5 και 2 Power Ups παραπάνω· ανοίγει "
                    f"και τα levels 41–50)",
            "how": "1 Titan Soul — το συζητάμε πριν (το ίδιο item ίσως θέλεις για άλλον)"}


def seeds_review(ch):
    used = ch.base.get("seedsUsed") or {}
    inferred = set(ch.base.get("seedsInferred") or [])
    out = {}
    for stat, name in E.SEED_ITEM.items():
        have = used.get(stat) or 0
        if have >= E.SEED_CAP:
            continue
        d = ch.gain([{"seeds": {stat: E.SEED_CAP}}])
        if d["power"] > 0:
            out[stat] = {"item": name, "have": have, "need": E.SEED_CAP - have, "sure": stat in inferred,
                         "gain": d["power"], "delta": d[stat]}
    return out


def leader_value(ch):
    """The leader skill's stat effects on each of the owner's heroes (calc.compute with options party): the heroes
    it lifts most, in hero power. A quest effect: the Info power of a hero does not show it."""
    from calc.champion import party_effects
    fx = party_effects(ch.raw)
    if not fx:
        return {"effects": [], "best": []}
    rows = []
    for name, h in D.heroes().items():
        base = D.compute(h)["stats"]["power"] or 0
        with_l = D.compute(h, {"party": fx})["stats"]["power"] or 0
        rows.append({"hero": name, "class": h.get("class"), "gain": with_l - base,
                     "gainPct": round(100 * (with_l - base) / base, 1) if base else None})
    rows.sort(key=lambda x: -x["gain"])
    return {"effects": [e["text"] for _, e in fx], "best": rows[:5],
            "note": "Μόνο τα stat effects του leader skill (ATK/DEF/HP %, crit, EVA, crit damage, heal)· στο power "
                    "του ήρωα· στο παιχνίδι μετράνε μέσα στο quest"}


def confidence(ch):
    chk = ch.shown.get("check") or {}
    from calc.validate import tolerance
    off = [k for k, v in chk.items() if k != "power" and abs(v.get("diff") or 0) > tolerance(k, v.get("shown"), True)]
    p = chk.get("power") or {}
    pct = round(100 * (p["computed"] - p["shown"]) / p["shown"], 2) if p.get("shown") else None
    level = "high" if not off and pct is not None and abs(pct) <= 0.2 else ("medium" if pct is not None and abs(pct) <= 5 else "low")
    names = {"attack": "ATK", "defense": "DEF", "hp": "HP", "evasion": "EVA", "critChance": "crit chance",
             "critDamage": "crit damage", "element": "element", "threat": "threat"}
    text = ("Σίγουρα νούμερα: το calc βγάζει τα stats του παιχνιδιού. " if level == "high" else
            f"Το calc διαφέρει στο {', '.join(names.get(k, k) for k in off)} (μάλλον λάθος ανάγνωση). " if off else "")
    text += (f"Power = τύπος ηρώων × {ch.base['extra']['powerFactor']} (ο συντελεστής μετρήθηκε στο power που δείχνει "
             "το παιχνίδι· το leader skill μετράει με τρόπο που δεν βρέθηκε): τα κέρδη είναι του τύπου × αυτόν.")
    return {"level": level, "powerShown": p.get("shown"), "powerComputed": p.get("computed"), "diffPct": pct,
            "statsOff": off, "itemsOff": [], "text": text, "warnings": ch.shown.get("warnings", [])}


EPIC_UP = ("Epic", "Legendary")


def _epic_only(slot):
    """Only Epic and Legendary (the owner's rule): no new enchant spent on a Normal/Superior/Flawless item."""
    keep = lambda o: o["kind"] != "enchant" or o["quality"] in EPIC_UP
    for key in ("choices", "options", "buy"):
        slot[key] = [o for o in slot[key] if keep(o)]
    return slot


def analyze(name):
    ch = Champion(name)
    slots = [_epic_only(E.review_slot(ch, n)) for n in (1, 2)]
    per_slot = {s["slot"]: [(c, None) for c in s.pop("_cands")] for s in slots}
    ideal = E.build(ch, per_slot)
    owned_slots = {n: [c for c in cs if c[0]["kind"] in ("enchant", "inventory", "craft")] for n, cs in per_slot.items()}
    owned = E.build(ch, owned_slots)
    ceiling = max(ideal["power"], ch.power)
    b = ch.base
    return {
        "kind": "champion", "id": ch.name, "champion": ch.name, "hero": ch.name, "class": ch.data["name"],
        "title": ch.raw.get("class"), "classType": ch.data["classType"], "element": ch.data["element"],
        "level": ch.raw.get("level"), "rank": ch.raw.get("rank"), "rankNumber": b["rank"], "rankPlus": b["rankPlus"],
        "titanSoul": ch.promoted, "promoted": ch.promoted, "promotesTo": None, "maxTier": ch.max_tier,
        "order": ch.raw.get("order"), "capturedAt": ch.raw.get("capturedAt"),
        "power": {"shown": (ch.raw.get("stats") or {}).get("power"), "computed": ch.power},
        "confidence": confidence(ch),
        "score": {"current": ch.power, "ceiling": ceiling, "pct": round(100 * ch.power / ceiling, 1) if ceiling else None,
                  "stc": None, "owned": owned["power"],
                  "ownedPct": round(100 * owned["power"] / ceiling, 1) if ceiling else None},
        "leader": dict(b["leader"] or {}, value=leader_value(ch)),
        "powerUps": power_ups(ch),
        "titanSoulOption": titan_soul(ch),
        "seeds": seeds_review(ch),
        "skills": [],
        "slots": slots,
        "ideal": ideal, "ownedBuild": owned, "stc": None,
        "legendary": {s["slot"]: E.legendary(ch, s["slot"], s["choices"][0] if s["choices"] else None) for s in slots},
    }


# ---------------------------------------------------------------- the 11 together

def _stock_left(summary):
    """The enchant cards the heroes' plan leaves (summary.allocation.enchantsLeft), as plan.Stock."""
    left = (summary.get("allocation") or {}).get("enchantsLeft") or {}
    cards = []
    for name, v in left.items():
        if isinstance(v, dict):
            cards += [{"item": name, "quality": None if q == "?" else q, "count": n} for q, n in v.items()]
        else:
            cards.append({"item": name, "quality": None, "count": v})
    return P.Stock(cards)


def allocate(reviews, champs, stock):
    """plan.allocate for the champions on what the heroes left: highest weighted gain first, each move re-measured on
    top of the champion's other moves; a move whose stored item or enchant ran out takes what is left or the slot's
    next option. Items a champion gives up go to another champion when that beats its own move (plan.reuse_freed)."""
    items_left = {e["key"]: e["count"] for e in D.inventory_items()}
    used_items, used_ench, plans, short, heap, tie = {}, {}, {r["id"]: {} for r in reviews}, {}, [], 0
    by_id = {r["id"]: r for r in reviews}

    def push(score, cid, n, idx):
        nonlocal tie
        heapq.heappush(heap, (-score, tie, cid, n, idx))
        tie += 1
    for r in reviews:
        for s in r["slots"]:
            s["recommended"] = None
            if s["choices"]:
                push(s["choices"][0]["score"], r["id"], s["slot"], 0)
    while heap:
        neg, _, cid, n, idx = heapq.heappop(heap)
        s = by_id[cid]["slots"][n - 1]
        opt, ch = s["choices"][idx], champs[cid]

        def next_choice():
            if idx + 1 < len(s["choices"]):
                push(s["choices"][idx + 1]["score"], cid, n, idx + 1)
        inv = opt["needs"].get("item")
        if inv and items_left.get(inv, 0) < 1:
            s.setdefault("taken", []).append({"item": opt["item"], "quality": opt["quality"], "gain": opt["gain"]["power"],
                                              "to": used_items.get(inv, [])})
            next_choice()
            continue
        q = opt["quality"]
        if any(x and not stock.has(x, q) for x in (opt["needs"].get("element"), opt["needs"].get("spirit"))):
            sub = P._substitute(ch, opt, stock)
            sub["wanted"] = {k: v for k, v in opt["needs"].items() if k != "item" and v and not stock.has(v, q)}
            ok = sub["gain"]["power"] >= ch.min_gain()
            for name in sub["wanted"].values():
                rec = short.setdefault(name, {}).setdefault((cid, n), {"hero": cid, "slot": n, "item": opt["item"],
                                                                        "quality": q, "lost": 0})
                rec["lost"] = max(rec["lost"], opt["gain"]["power"] - (sub["gain"]["power"] if ok else 0))
            if ok:
                s["choices"][idx] = sub
                push(sub["score"], cid, n, idx)
            else:
                s.setdefault("taken", []).append({"item": opt["item"], "quality": q, "gain": opt["gain"]["power"],
                                                  "to": [], "noEnchant": list(sub["wanted"].values())})
                next_choice()
            continue
        plan = list(plans[cid].values())
        before = ch.gain(plan)["power"] if plan else 0
        marginal = ch.gain(plan + [opt["change"]])["power"] - before
        if marginal < ch.min_gain():
            next_choice()
            continue
        score = marginal * E.WEIGHT[opt["kind"]]
        if score < -neg - max(50, 0.02 * -neg):
            opt["planGain"] = marginal
            push(score, cid, n, idx)
            continue
        if inv:
            items_left[inv] -= 1
            used_items.setdefault(inv, []).append(f"{cid} slot {n}")
        opt["enchantQuality"] = {}
        for k in ("element", "spirit"):
            x = opt["needs"].get(k)
            if x:
                opt["enchantQuality"][k] = stock.take(x, q)
                used_ench.setdefault(x, []).append(f"{cid} slot {n}")
        opt["planGain"], opt["planScore"] = marginal, score
        plans[cid][n] = opt["change"]
        s["recommended"] = opt
    # An item a champion gives up goes to another one only if it is Epic or Legendary: reuse_freed offers the slots'
    # current items, so the lower ones are hidden from it for the call.
    hidden = []
    for r in reviews:
        for s in r["slots"]:
            if s["current"]["item"] and s["current"]["quality"] not in EPIC_UP:
                hidden.append((s, s["current"]["item"]))
                s["current"]["item"] = None
    try:
        freed = P.reuse_freed(reviews, champs, plans, items_left, stock, used_items, used_ench)
    finally:
        for s, item in hidden:
            s["current"]["item"] = item
    inv_names = {e["key"]: f"{e['item']} ({e['quality']})" for e in D.inventory_items()}
    shortage = sorted(({"enchant": k, "count": len(v), "lost": sum(x["lost"] for x in v.values()),
                        "for": sorted(v.values(), key=lambda x: -x["lost"])} for k, v in short.items()),
                      key=lambda x: -x["lost"])
    return {"itemsUsed": {inv_names[k]: v for k, v in used_items.items() if v},
            "enchantsUsed": {k: {"count": len(v), "to": v} for k, v in sorted(used_ench.items()) if v},
            "enchantsLeft": stock.left(), "enchantsShort": shortage, "freedUsed": freed}


def allocate_seeds(reviews, left):
    wants = [(r, stat, w) for r in reviews for stat, w in (r.get("seeds") or {}).items()]
    wants.sort(key=lambda x: -x[2]["gain"] / x[2]["need"])
    for r, stat, w in wants:
        w["given"] = min(w["need"], left.get(w["item"], 0))
        left[w["item"]] = left.get(w["item"], 0) - w["given"]
        if w["given"] < w["need"]:
            w["gain"] = round(w["gain"] * w["given"] / w["need"])
    return left


def finish(r, ch):
    changes = [s["recommended"]["change"] for s in r["slots"] if s["recommended"]]
    free = [s["recommended"]["change"] for s in r["slots"] if s["recommended"]
            and s["recommended"]["kind"] in ("enchant", "inventory", "freed")]
    plan = D.diff(ch.raw, changes) if changes else None
    free_res = D.diff(ch.raw, free) if free else None
    r["plan"] = {"changes": changes, "power": plan["stats"]["power"] if plan else ch.power,
                 "gain": D.delta(plan) if plan else {k: 0 for k in D.STAT_KEYS},
                 "freePower": free_res["stats"]["power"] if free_res else ch.power}
    r["score"]["afterPlan"] = r["plan"]["power"]
    r["score"]["afterPlanPct"] = round(100 * r["plan"]["power"] / r["score"]["ceiling"], 1) if r["score"]["ceiling"] else None
    for s in r["slots"]:
        rec = s["recommended"]
        s["verdict"] = "change" if rec else "keep"
        s["legendary"] = E.legendary(ch, s["slot"], rec)
        base = rec["gain"]["power"] if rec else 0
        s["marketBetter"] = None
        for m in s["buy"]:
            if rec and m["item"] == rec["item"] and m["quality"] == rec["quality"]:
                continue
            if m["gain"]["power"] - base >= max(ch.min_gain(), P.MARKET_EXTRA * ch.power):
                s["marketBetter"] = dict(m, extraPower=m["gain"]["power"] - base)
            break
        s["choices"] = s["choices"][:6]
    r.pop("legendary", None)
    r["gaps"] = gaps(r, ch)
    return r


def gaps(r, ch):
    out = []
    low = [s for s in r["slots"] if s["current"]["quality"] in ("Normal", "Superior", "Flawless")]
    if low:
        out.append({"kind": "quality", "gain": None,
                    "text": f"{len(low)} item{'s' if len(low) > 1 else ''} κάτω από Epic: " + ", ".join(
                        f"slot {s['slot']} {s['current']['item']} ({s['current']['quality']})" for s in low)})
    none = [s for s in r["slots"] if s["current"]["item"] and not (s["current"]["element"] and s["current"]["spirit"])]
    if none:
        out.append({"kind": "element", "gain": None,
                    "text": "Χωρίς enchant: " + ", ".join(
                        f"slot {s['slot']} {s['current']['item']} ({'χωρίς element' if not s['current']['element'] else ''}"
                        f"{' και ' if not s['current']['element'] and not s['current']['spirit'] else ''}"
                        f"{'χωρίς spirit' if not s['current']['spirit'] else ''})" for s in none)})
    for s in sorted(r["slots"], key=lambda s: -((s["recommended"] or {}).get("planGain") or 0)):
        o = s["recommended"]
        if o and o["planGain"] >= 0.03 * ch.power:
            out.append({"kind": "slot", "slot": s["slot"], "gain": o["planGain"],
                        "text": f"Slot {s['slot']}: {P.move_text(r, s, o)} = +{D.gr(o['planGain'])} power "
                                f"(+{round(100 * o['planGain'] / ch.power, 1)}%)"})
    given = [(stat, w) for stat, w in (r.get("seeds") or {}).items() if w.get("given")]
    if given:
        out.append({"kind": "seeds", "gain": sum(w["gain"] for _, w in given),
                    "text": "Seeds: " + ", ".join(f"{w['given']} {w['item']} (έχει {w['have']}{'' if w['sure'] else '?'}) "
                                                  f"+{D.gr(w['gain'])}" for _, w in given) + " power."})
    t = r.get("titanSoulOption")
    if t:
        out.append({"kind": "titan", "gain": t["gain"]["power"], "text": t["text"] + " — " + t["how"]})
    if r.get("powerUps"):
        p = r["powerUps"][0]
        out.append({"kind": "powerUp", "gain": p["gain"]["power"], "text": "Επόμενο " + p["text"]})
    return out


def moves(reviews):
    out = []
    for r in reviews:
        for s in r["slots"]:
            o = s["recommended"]
            if o:
                out.append({"champion": r["id"], "hero": r["id"], "slot": s["slot"], "kind": o["kind"],
                            "label": o["label"], "text": P.move_text(r, s, o), "item": o["item"],
                            "quality": o["quality"], "element": o["element"], "spirit": o["spirit"],
                            "gain": o["planGain"], "gainAlone": o["gain"]["power"],
                            "gainPct": round(100 * o["planGain"] / (r["score"]["current"] or 1), 2),
                            "score": o["planScore"], "gems": o["gems"], "notes": o.get("notes", []),
                            "after": o.get("after"), "enchantQuality": o.get("enchantQuality")})
        for stat, w in (r.get("seeds") or {}).items():
            if w.get("given"):
                out.append({"champion": r["id"], "hero": r["id"], "slot": None, "kind": "seeds", "item": w["item"],
                            "text": f"{w['given']} {w['item']} (έχει {w['have']}{'' if w['sure'] else ', αβέβαιο'})",
                            "gain": w["gain"], "gainPct": round(100 * w["gain"] / (r["score"]["current"] or 1), 2),
                            "score": w["gain"] * (1.0 if w["sure"] else 0.5), "gems": 0})
        t = r.get("titanSoulOption")
        if t and t["gain"]["power"] > 0:
            out.append({"champion": r["id"], "hero": r["id"], "slot": None, "kind": "titanSoul", "item": "Titan Soul",
                        "text": "Titan Soul (έχεις " + str(t["stock"]) + ")", "gain": t["gain"]["power"],
                        "gainPct": round(100 * t["gain"]["power"] / (r["score"]["current"] or 1), 2),
                        "score": t["gain"]["power"] * 0.5, "gems": 0, "notes": [t["how"]]})
    out.sort(key=lambda m: -m["score"])
    return out


def run(summary, names=None):
    """Review every champion on what the heroes' plan left; write data/reviews/champions/ and add the champion lists
    to `summary` (the caller writes summary.json)."""
    names = names or list(champions())
    reviews = [analyze(n) for n in names]
    champs = {r["id"]: Champion(r["id"]) for r in reviews}
    alloc = allocate(reviews, champs, _stock_left(summary))
    seeds_left = dict((summary.get("allocation") or {}).get("seedsLeft") or {})
    alloc["seedsLeft"] = allocate_seeds(reviews, seeds_left)
    for r in reviews:
        finish(r, champs[r["id"]])
    OUT.mkdir(parents=True, exist_ok=True)
    mv = moves(reviews)
    for r in reviews:
        r["generatedAt"] = summary.get("generatedAt")
        (OUT / f"{r['id']}.json").write_text(json.dumps(r, ensure_ascii=False, indent=1) + "\n")
    summary["champions"] = [{
        "id": r["id"], "class": r["class"], "title": r["title"], "level": r["level"], "rank": r["rank"],
        "titanSoul": r["titanSoul"], "powerShown": r["power"]["shown"], "power": r["score"]["current"],
        "ceiling": r["score"]["ceiling"], "pct": r["score"]["pct"], "afterPlan": r["score"]["afterPlan"],
        "afterPlanPct": r["score"]["afterPlanPct"], "confidence": r["confidence"]["level"],
        "changes": sum(1 for s in r["slots"] if s["recommended"]),
        "leader": (r.get("leader") or {}).get("name"),
        "leaderBest": [b["hero"] for b in ((r.get("leader") or {}).get("value") or {}).get("best", [])[:3]],
        "nextPowerUp": (r["powerUps"][0]["gain"]["power"] if r.get("powerUps") else None),
    } for r in reviews]
    summary["championMoves"] = mv
    summary["championCraft"] = [m for m in mv if m["kind"] == "craft"]
    market = []
    for r in reviews:
        for s in r["slots"]:
            m = s.get("marketBetter")
            if m:
                market.append({"champion": r["id"], "hero": r["id"], "slot": s["slot"], "kind": m["kind"],
                               "label": m["label"], "detail": m["detail"], "item": m["item"], "tier": m["tier"],
                               "quality": m["quality"], "element": m["element"], "spirit": m["spirit"],
                               "gain": m["gain"]["power"], "extraPower": m["extraPower"],
                               "instead": (s["recommended"] or {}).get("item") or s["current"]["item"]})
    summary["championMarket"] = sorted(market, key=lambda m: (m["kind"] != "market", -m["extraPower"]))
    summary["championAllocation"] = alloc
    summary.setdefault("notes", []).append(
        "Champions: παίρνουν ό,τι enchants και seeds αφήνει το πλάνο των ηρώων. Power champion = τύπος ηρώων × "
        "συντελεστής που μετρήθηκε στο power του παιχνιδιού (το leader skill μετράει με τρόπο που δεν βρέθηκε).")
    return reviews, summary
