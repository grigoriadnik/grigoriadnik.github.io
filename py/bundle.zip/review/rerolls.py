"""Skill reroll planner: which skill to reroll on which hero, with which die, and when to stop.

    .venv/bin/python -m review.rerolls                 # every hero → data/reviews/rerolls.json (+ into the reviews)
    .venv/bin/python -m review.rerolls "Hero 18"     # print one hero's plan (after a run)

Mechanics and the owner's policy: review/reroll_rules.json. Every value is the hero's power from calc.compute /
calc.diff with the outcome skill in that slot (tier from the current element, T4 only when promoted); a skill that
asks for another item type (Bow Master, Marksman…) is also measured with the best owned or craftable item of that
type. Rolls already made are read from data/actions/rolls.json (execute fills it), so a rerun after each roll
gives the next step. README.md § Rerolls.
"""
import copy
import datetime
import json
import math
import multiprocessing
import re
import sys
from functools import lru_cache
from pathlib import Path

from . import data as D
from . import engine as E
from .data import hr

RULES_PATH = Path(__file__).with_name("reroll_rules.json")
OUT = D.REVIEWS / "rerolls.json"
ROLLS = D.DATA / "actions" / "rolls.json"
DICE = ["Basic Skill Die", "Super Skill Die", "Mega Skill Die", "Perfect Skill Die"]
ROLLS_TEMPLATE = {
    "_about": "Skill rerolls made in the game, one entry per roll, appended by execute. review/rerolls.py applies the "
              "entries newer than a hero's roster reading (skill) and than inventory.json (dice), then plans the next "
              "roll: `.venv/bin/python -m review.rerolls`. Format: review/README.md § Rerolls.",
    "example": {"at": "2026-10-30T18:00:00+02:00", "hero": "Hero 18", "skillSlot": 3, "die": "Mega Skill Die",
                "from": "Eagle Eyes", "to": "Death Dealer", "rarity": "Epic", "gemsSpent": 0, "note": ""},
    "rolls": [],
}


@lru_cache(None)
def rules():
    return json.loads(RULES_PATH.read_text())


# ---------------------------------------------------------------- the roll log

def roll_log():
    if not ROLLS.exists():
        return []
    return [r for r in json.loads(ROLLS.read_text()).get("rolls") or [] if r.get("hero") and r.get("to")]


def ensure_roll_log():
    if not ROLLS.exists():
        ROLLS.parent.mkdir(parents=True, exist_ok=True)
        ROLLS.write_text(json.dumps(ROLLS_TEMPLATE, ensure_ascii=False, indent=1) + "\n")


def _ts(s):
    if not s:
        return None
    s = s.replace("Z", "+00:00")
    if re.search(r"[+-]\d{4}$", s):
        s = s[:-2] + ":" + s[-2:]
    try:
        return datetime.datetime.fromisoformat(s)
    except ValueError:
        return None


def _after(entry, since):
    a, b = _ts(entry.get("at")), _ts(since)
    return a is None or b is None or a > b


def dice_stock(log):
    """Dice in storage (inventory.json) minus the dice the log spent after that reading."""
    inv = D.inventory()
    stock = {d: D.consumable(d) for d in DICE}
    for r in log:
        if r.get("die") in stock and _after(r, inv.get("capturedAt")):
            stock[r["die"]] -= 1
    return stock


# ---------------------------------------------------------------- skills

@lru_cache(None)
def _by_any_name():
    out = {}
    for s in hr.skills().values():
        if s.get("isInnate"):
            continue
        for t in s["tiers"]:
            out.setdefault(t["name"].lower(), s)
    for s in hr.skills().values():
        if not s.get("isInnate"):
            out[s["name"].lower()] = s
    return out


def skill(name):
    return _by_any_name().get((name or "").strip().lower())


def siblings(name):
    fam = {k: v for k, v in rules()["families"].items() if not k.startswith("_")}
    for names in fam.values():
        if name in names:
            return set(names)
    return {name}


def current_skills(raw):
    """[(skill slot 1-4, T1 name)] in the game's order (skillTiers.slot 1 is the innate)."""
    tiers = [t for t in raw.get("skillTiers") or [] if not t.get("innate")]
    if tiers:
        return [(t["slot"] - 1, t["skill"]) for t in sorted(tiers, key=lambda t: t["slot"])]
    return [(i + 1, (skill(n) or {"name": n})["name"]) for i, n in enumerate(raw.get("skills") or [])]


def apply_rolls(raw, log):
    """The roster hero with the rolls logged after its reading applied (skill slot -> new skill)."""
    raw = copy.deepcopy(raw)
    done = []
    for r in log:
        if r["hero"] != raw["hero"] or not _after(r, raw.get("capturedAt")):
            continue
        new = skill(r["to"])
        if not new:
            continue
        for t in raw.get("skillTiers") or []:
            if not t.get("innate") and t["slot"] - 1 == int(r["skillSlot"]):
                t.update(skill=new["name"], name=new["name"], rarity=new["rarity"])
        done.append(r)
    if done:
        raw["skills"] = [t["skill"] for t in raw.get("skillTiers") or [] if not t.get("innate")]
    return raw, done


def outcome_odds(cls_name, held, slot, rolled=None):
    """{skill name: probability} a reroll of skill slot `slot` (now `rolled`) can give, for a hero holding `held`
    (T1 names). What is out of the pool follows reroll_rules.json → rules (excludeSiblings, excludeRolled)."""
    R = rules()["rules"]
    blocked = set()
    for h in held:
        if h == rolled and not R.get("excludeRolled", True):
            continue
        blocked |= siblings(h) if R.get("excludeSiblings", True) else {h}
    pool = [s for s in hr.skills().values() if not s.get("isInnate") and cls_name in (s.get("classes") or [])
            and s["name"] not in blocked]
    odds = rules()["odds"][str(slot)]
    by_rarity = {}
    for s in pool:
        by_rarity.setdefault(s["rarity"], []).append(s["name"])
    total = sum(odds[r] for r in by_rarity if r in odds)
    return {n: odds[r] / total / len(names) for r, names in by_rarity.items() if r in odds for n in names}


RATING_ORDER = ["S+", "S", "A", "B", "C", "D"]


def class_skills(cls, held):
    """Every non-innate skill the class can roll, best rating first (unrated last), for the site's «Όλα τα skills
    της class». held = [(skill slot 1-4, T1 name)]. `held` = the slot holding it; `blockedBy` = the held skill
    whose family (reroll_rules.json → families: rarity siblings, a second X Master, a second Warlord/Marksman/
    Adept) keeps it out of a reroll of the other slots; `onlyFromThatSlot` when rerolling that skill's own slot
    can still give it (rules.excludeRolled false)."""
    R = rules()["rules"]
    page = hr.rating_page(cls)
    holder = {}
    for k, n in held:
        for s in (siblings(n) if R.get("excludeSiblings", True) else {n}):
            holder.setdefault(s, (k, n))
    slot_of = {n: k for k, n in held}
    rank = {r: i for i, r in enumerate(RATING_ORDER)}
    rows = []
    for s in hr.skills().values():
        if s.get("isInnate") or cls["name"] not in (s.get("classes") or []):
            continue
        row = {"name": s["name"], "rarity": s["rarity"], "rating": page.get(s["name"]),
               "icon": "/" + s["icon"] if s.get("icon") else None, "held": slot_of.get(s["name"])}
        if row["held"] is None and s["name"] in holder:
            k, n = holder[s["name"]]
            row["blockedBy"] = {"skill": n, "skillSlot": k, "onlyFromThatSlot": not R.get("excludeRolled", True)}
        rows.append(row)
    rows.sort(key=lambda r: (rank.get(r["rating"], len(rank)), r["name"]))
    return rows


def class_skills_for(name, log=None):
    """class_skills() for a roster hero, with the rolls logged after its reading applied."""
    raw, _ = apply_rolls(D.hero(name), roll_log() if log is None else log)
    return class_skills(hr.fuzzy(raw["class"], hr.classes(), "class"), current_skills(raw))


def embed_class_skills(names=None):
    """Refresh only `classSkills` in data/reviews/<hero>.json (no calc): `python -m review.rerolls --class-skills`."""
    log = roll_log()
    for name in names or list(D.heroes()):
        f = D.REVIEWS / f"{name}.json"
        if f.exists():
            r = json.loads(f.read_text())
            r["classSkills"] = class_skills_for(name, log)
            f.write_text(json.dumps(r, ensure_ascii=False, indent=1) + "\n")


def type_bonus(name):
    """Item types a skill's own bonus needs ('+50% Attack with Bow', 'Equipped Shield's DEF is added to ATK')."""
    s = skill(name)
    types = set()
    known = set(D.type_names().values())
    for t in (s or {}).get("tiers") or []:
        for m in re.finditer(r"with ([A-Z][\w ,]+?)(?:\.|$)", t.get("description") or ""):
            for part in re.split(r",\s*|\s+and\s+", m.group(1)):
                part = part.strip()
                if part in known:
                    types.add(part)
                elif part.rstrip("s") in known:
                    types.add(part.rstrip("s"))
        m = re.search(r"Equipped (\w[\w ]*)'s DEF", t.get("description") or "")
        if m:
            types.add(m.group(1))
    return types


# ---------------------------------------------------------------- one hero

class ModHero(E.Hero):
    """engine.Hero for a hero with other skills: calc.diff on this raw (skills by T1 name, seeds fixed)."""

    def __init__(self, base, raw):
        self.raw, self.name, self.h = raw, base.name, D.for_compute(raw)
        self.cls, self.promoted, self.max_tier, self.slots = base.cls, base.promoted, base.max_tier, base.slots
        self.shown = self.base = None
        self.power = base.power
        self._cache = {}


def _hero(name, log):
    hero = E.Hero(name)
    raw, done = apply_rolls(hero.raw, log)
    if done:
        # seeds from the reading the shown stats belong to: inferred again with the new skills they come out wrong
        raw["seeds"] = dict(hero.base["seedsUsed"])
        hero.raw, hero.h = raw, D.for_compute(raw)
        hero.base = D.compute(hero.h)
        hero.power = hero.base["stats"]["power"] or 0
    return hero, done


def _with_skills(hero, names):
    raw = copy.deepcopy(hero.raw)
    raw["skills"] = list(names)
    raw.pop("skillTiers", None)
    raw["seeds"] = dict(hero.base["seedsUsed"])
    return raw


def synergy_items(name):
    """Items whose own skill feeds on what this skill gives: Thinkin' Cap turns 50% of the hero's XP% into ATK%
    (calc, Central Thinking), so Super Genius / Fast Learner are worth it only with the Cap."""
    s = skill(name)
    text = " ".join(t.get("description") or "" for t in (s or {}).get("tiers") or [])
    return {"Thinkin' Cap"} if re.search(r"\d+% XP", text) else set()


def regear(hero, raw_mod, types, ranked, names=frozenset()):
    """The best owned or craftable item of `types`, or one of the items `names` from any source (synergy_items),
    for a slot that does not hold one now, measured on the hero with the new skill (engine.evaluate: best element
    and spirit). None when no slot or item fits."""
    mod = ModHero(hero, raw_mod)
    best = None

    def wanted(it):
        return bool(D.item_types(it) & types) or it["name"] in names

    for n in range(1, 7):
        cur = D.item((hero.slots.get(n) or {}).get("item") or "")
        if cur and wanted(cur):
            continue
        cands = []
        for e in D.inventory_items():
            it = D.item(e["item"])
            if it and wanted(it) and it["tier"] <= hero.max_tier and hr.item_fits(hero.cls, n, it):
                cands.append({"kind": "inventory", "it": it, "quality": e["quality"], "own_el": e.get("element"),
                              "own_sp": e.get("spirit")})
        for it in E.pool(hero, n):
            if not wanted(it):
                continue
            kind = D.item_source(it["name"])["kind"]
            if kind == "craft" or it["name"] in names:
                cands.append({"kind": kind, "it": it, "quality": "Epic"})
        if not cands:
            continue
        if n not in ranked:
            ranked[n] = E.spirit_ranking(hero, n)
        for c in cands:
            if len(D.artifact_slots(raw_mod, [{"slot": n, "item": c["it"]["name"]}])) > 1:
                continue
            ev = E.evaluate(mod, n, c, ranked[n])
            if best is None or ev["gain"]["power"] > best["gain"]:
                best = {"slot": n, "item": c["it"]["name"], "tier": c["it"]["tier"], "type": c["it"]["type"],
                        "quality": c["quality"], "kind": c["kind"], "element": ev["el"], "spirit": ev["sp"],
                        "gain": ev["gain"]["power"],
                        "change": E.change(n, c["it"], c["quality"], ev["el"], ev["sp"])}
    return best


def plan_hero(name, log=None):
    """Every skill slot of one hero: the value of each possible outcome, the acceptance line, odds, expected rolls."""
    log = roll_log() if log is None else log
    R, P = rules(), rules()["policy"]
    hero, done = _hero(name, log)
    held = [n for _, n in current_skills(hero.raw)]
    slots = current_skills(hero.raw)
    base_power = D.compute(_with_skills(hero, held))["stats"]["power"] or 0
    page = hr.rating_page(hero.cls)
    gear_cache, ranked = {}, {}
    G = ("slot", "item", "tier", "type", "quality", "kind", "element", "spirit")

    def power_with(raw_mod, changes):
        return (D.diff(raw_mod, changes) if changes else D.compute(raw_mod))["stats"]["power"] or 0

    # a held skill whose item type no slot holds (Crossbow Master, no crossbow): the owner keeps it and changes the
    # item, so the hero is valued with that item, for keeping the skill and under every roll of another slot
    raw_held, kept = _with_skills(hero, held), {}
    for h in held:
        types, names = type_bonus(h), synergy_items(h)
        g = regear(hero, raw_held, types, ranked, names) if types or names else None
        if g and g["gain"] >= P["buildChangePct"] / 100 * base_power:
            kept[h] = g
    first = {}
    for h, g in sorted(kept.items(), key=lambda x: -x[1]["gain"]):
        first.setdefault(g["slot"], h)
    kept = {h: g for h, g in kept.items() if first[g["slot"]] == h}
    keep_power = power_with(raw_held, [g["change"] for g in kept.values()])
    out_slots = []
    for k, cur in slots:
        extra = [g for h, g in kept.items() if h != cur]
        odds = outcome_odds(hero.cls["name"], held, k, cur)
        outcomes = []
        for o, p in odds.items():
            names = [o if x == cur else x for x in held]
            raw_mod = _with_skills(hero, names)
            r = D.compute(raw_mod)
            power = power_with(raw_mod, [g["change"] for g in extra]) if extra else r["stats"]["power"] or 0
            tier = next((s["tier"] for s in r["skills"] if s["name"] == o), None)
            row = {"skill": o, "rarity": skill(o)["rarity"], "rating": page.get(o), "p": round(p, 4), "tier": tier,
                   "power": power, "gain": power - keep_power}
            types, names = type_bonus(o), synergy_items(o)
            if types or names:
                if o not in gear_cache:
                    gear_cache[o] = regear(hero, raw_mod, types, ranked, names)
                g = gear_cache[o]
                if g and g["slot"] not in {e["slot"] for e in extra}:
                    p2 = power_with(raw_mod, [e["change"] for e in extra] + [g["change"]])
                    if p2 - power >= P["buildChangePct"] / 100 * base_power:
                        row["buildChange"] = dict({k2: g[k2] for k2 in G}, powerWithout=power, powerWith=p2)
                        row["power"], row["gain"] = p2, p2 - keep_power
            outcomes.append(row)
        outcomes.sort(key=lambda x: -x["power"])
        sp = _slot_plan(k, cur, skill(cur), keep_power, outcomes, page, P)
        if cur in kept:
            sp["keptWith"] = dict({k2: kept[cur][k2] for k2 in G}, powerWithout=base_power, powerWith=keep_power)
        out_slots.append(sp)
    weak = [s for s in out_slots if s["percentile"] is not None]
    strength = sum(s["percentile"] for s in weak) / len(weak) if weak else 1.0
    planned = [s for s in out_slots if s["decision"] == "roll"]
    build_chance = 1 - math.prod(1 - s.get("buildChanceAccepted", 0) for s in planned) if planned else 0.0
    return {
        "hero": hero.name, "class": hero.cls["name"], "promoted": hero.promoted, "power": base_power,
        "powerShown": hero.raw["stats"].get("power"), "powerWithKept": keep_power,
        "keptSkills": {h: dict({k2: g[k2] for k2 in G}) for h, g in kept.items()}, "skills": held, "strength": round(strength, 3),
        "weak": strength < P["weakSetPercentile"], "buildChance": round(build_chance, 3),
        "rerollBeforeItems": bool(planned) and strength < P["weakSetPercentile"] and build_chance >= P["rerollFirstBuildChance"],
        "rollsApplied": done, "slots": out_slots,
    }


def _slot_plan(k, cur, cur_rec, base_power, outcomes, page, P):
    """Acceptance line = the lowest value among the best outcomes that together hold `1 - acceptQuantile` of the odds
    (the top third by default). Roll only if the current skill is under it by at least minGainPct of the power."""
    cum, line = 0.0, None
    for o in outcomes:
        cum += o["p"]
        line = o["power"]
        if cum >= 1 - P["acceptQuantile"] - 1e-9:
            break
    accept = [o for o in outcomes if line is not None and o["power"] >= line]
    p_accept = sum(o["p"] for o in accept)
    below = sum(o["p"] for o in outcomes if o["power"] <= base_power)
    row = {"skillSlot": k, "current": cur, "rarity": (cur_rec or {}).get("rarity"), "rating": page.get(cur),
           "currentPower": base_power, "percentile": round(below, 3) if outcomes else None,
           "outcomes": outcomes, "poolSize": len(outcomes),
           "perRoll": {"pBetter": round(sum(o["p"] for o in outcomes if o["gain"] > 0), 3),
                       "pWorse": round(sum(o["p"] for o in outcomes if o["gain"] < 0), 3),
                       "expectedGain": round(sum(o["p"] * o["gain"] for o in outcomes))}}
    if not outcomes or line is None:
        row.update(decision="keep", reason="καμία άλλη επιλογή για αυτή την class")
        return row
    row["acceptLine"] = {"power": line, "gain": line - base_power, "skills": [o["skill"] for o in accept],
                         "pAccept": round(p_accept, 3)}
    if line - base_power < P["minGainPct"] / 100 * base_power:
        row.update(decision="keep", reason="ήδη στο πάνω τρίτο των πιθανών (ή το κέρδος είναι μικρό)")
        return row
    final = sum(o["p"] * o["power"] for o in accept) / p_accept
    rolls = 1 / p_accept
    budget = math.ceil(math.log(1 - P["budgetQuantile"]) / math.log(1 - p_accept)) if p_accept < 1 else 1
    bc = [o for o in accept if o.get("buildChange")]
    budget = max(1, budget)
    p_miss = (1 - p_accept) ** budget
    p_worse_miss = sum(o["p"] for o in outcomes if o["power"] < min(line, base_power)) / max(1e-9, 1 - p_accept)
    discuss = []
    if row["rating"] in ("S+", "S"):
        discuss.append(f"το {cur} έχει rating {row['rating']}: μετράει σε quests με τρόπους που το power δεν βλέπει")
    if any(o.get("buildChange") for o in outcomes):
        discuss.append("μπορεί να βγει skill που αλλάζει build (και items)")
    if p_miss * p_worse_miss >= 0.1:
        discuss.append(f"{round(100 * p_miss * p_worse_miss)}% να τελειώσει το budget με χειρότερο skill από το τωρινό")
    row.update(decision="roll", expectedRolls=round(rolls, 2), budget=budget,
               pMissBudget=round(p_miss, 3), riskEndWorse=round(p_miss * p_worse_miss, 3), discuss=discuss,
               expectedFinal=round(final), expectedGain=round(final - base_power),
               buildChanging=[{"skill": o["skill"], "p": o["p"], **o["buildChange"]} for o in outcomes if o.get("buildChange")],
               buildChanceAccepted=round(sum(o["p"] for o in bc) / p_accept, 3))
    return row


# ---------------------------------------------------------------- the roster

def allocate(heroes, stock):
    """Rank every slot to roll by expected power gain per die, the die weighted by how scarce it is (after the
    reserve), with weak skill sets first among near-equals; give each its dice budget while they last."""
    P = rules()["policy"]
    avail = {d: max(0, stock.get(d, 0) - P["reserve"].get(d, 0)) for d in DICE}
    ref = max(avail["Basic Skill Die"], 1)
    weight = {d: ref / max(avail[d], 1) for d in DICE}
    tasks = []
    for h in heroes:
        for s in h["slots"]:
            if s["decision"] != "roll":
                continue
            dice = [d for d in P["useBySlot"][str(s["skillSlot"])] if s["skillSlot"] in rules()["dice"][d]["slots"]]
            per_die = s["expectedGain"] / (s["expectedRolls"] * weight[dice[0]])
            tasks.append({"hero": h["hero"], "class": h["class"], "skillSlot": s["skillSlot"], "current": s["current"],
                          "pMissBudget": s["pMissBudget"], "riskEndWorse": s["riskEndWorse"], "discuss": s["discuss"],
                          "rating": s["rating"], "acceptLine": s["acceptLine"], "expectedRolls": s["expectedRolls"],
                          "budget": s["budget"], "expectedGain": s["expectedGain"],
                          "expectedGainPct": round(100 * s["expectedGain"] / (h["power"] or 1), 1),
                          "perRoll": s["perRoll"], "buildChanging": s["buildChanging"], "diceAllowed": dice,
                          "weak": h["weak"], "strength": h["strength"], "rerollBeforeItems": h["rerollBeforeItems"],
                          "priority": round(per_die * (0.75 + 0.5 * (1 - h["strength"])), 1)})
    tasks.sort(key=lambda t: -t["priority"])
    left = dict(avail)
    for t in tasks:
        need = t["budget"]
        have = sum(left[d] for d in t["diceAllowed"])
        if have < math.ceil(t["expectedRolls"]):
            t["status"], t["dice"] = "noDice", {}
            continue
        take = {}
        for d in t["diceAllowed"]:
            n = min(left[d], need)
            if n:
                take[d] = n
                left[d] -= n
                need -= n
            if not need:
                break
        t["status"], t["dice"] = "planned", take
        t["die"] = next(iter(take))
    planned = [t for t in tasks if t["status"] == "planned"]
    order = []
    for t in planned:
        if t["hero"] not in order:
            order.append(t["hero"])
    for i, hid in enumerate(order, 1):
        first = True
        for t in planned:
            if t["hero"] == hid:
                t["heroOrder"] = i
                # One slot per hero at a time: its other slots change value once this one changes, so they wait
                # for a recompute (`python -m review.rerolls` after logging the roll).
                t["step"] = "now" if first else "afterRecompute"
                first = False
    return tasks, {"stock": stock, "reserve": P["reserve"], "available": avail, "left": left, "weight": {d: round(w, 2) for d, w in weight.items()},
                   "planned": {d: avail[d] - left[d] for d in DICE}}, order


def _plan(name):
    return plan_hero(name)


def run(names=None, workers=None, update_reviews=True):
    ensure_roll_log()
    log = roll_log()
    names = names or list(D.heroes())
    workers = workers or min(8, multiprocessing.cpu_count() or 1)
    if workers > 1 and len(names) > 1:
        with multiprocessing.get_context("spawn").Pool(workers) as pool:
            heroes = pool.map(_plan, names)
    else:
        heroes = [plan_hero(n, log) for n in names]
    stock = dice_stock(log)
    tasks, dice, order = allocate(heroes, stock)
    # listed in the order to do them: each hero's next roll first (best first), then the ones after a recompute
    tasks.sort(key=lambda t: (t["status"] != "planned", t.get("step") != "now", -t["priority"]))
    by_hero = {h["hero"]: h for h in heroes}
    for t in tasks:
        h = by_hero[t["hero"]]
        h.setdefault("tasks", []).append({k: t[k] for k in ("skillSlot", "status", "dice", "priority", "heroOrder", "step")
                                          if k in t})
    out = {
        "generatedAt": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "rules": {k: rules()[k] for k in ("source", "confirmed", "odds", "policy")},
        "dice": dice, "order": order, "tasks": tasks,
        "rerollFirst": [h["hero"] for h in heroes if h["rerollBeforeItems"]],
        "totals": {"slotsToRoll": sum(1 for t in tasks if t["status"] == "planned"),
                   "noDice": sum(1 for t in tasks if t["status"] == "noDice"),
                   "expectedGain": sum(t["expectedGain"] for t in tasks if t["status"] == "planned"),
                   "expectedDice": round(sum(t["expectedRolls"] for t in tasks if t["status"] == "planned"), 1)},
        "log": {"file": str(ROLLS.relative_to(D.ROOT)), "applied": sum(len(h["rollsApplied"]) for h in heroes)},
        "heroes": heroes,
        "notes": [
            "Ποτέ gems για να κρατήσεις το παλιό skill: κάθε ρίψη κρατιέται όπως βγει.",
            "Ρίχνεις στο ίδιο slot μέχρι να βγει skill πάνω από τη γραμμή αποδοχής (το πάνω τρίτο των πιθανών), "
            "μετά πας στο επόμενο slot / ήρωα. Τα ζάρια του budget φτάνουν με ~75% πιθανότητα.",
            "Skill με «αλλάζει build» (π.χ. Bow Master): σταματάμε και το συζητάμε, μαζί με την αλλαγή item.",
            "Odds: slot 1 από την οθόνη reroll του παιχνιδιού, τα slots 2–4 από το wiki (Hero Skills) μέχρι να "
            "διαβαστούν: review/reroll_rules.json.",
        ],
    }
    D.REVIEWS.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1) + "\n")
    if update_reviews:
        _embed(out)
    return out


def _embed(out):
    """Copy each hero's plan into data/reviews/<hero>.json and a compact one into summary.json, so the site and
    the other sessions read it through the files they already read."""
    log = roll_log()
    for h in out["heroes"]:
        f = D.REVIEWS / f"{h['hero']}.json"
        if not f.exists():
            continue
        r = json.loads(f.read_text())
        r["rerolls"] = h
        r["classSkills"] = class_skills_for(h["hero"], log)
        r["gaps"] = [g for g in r.get("gaps") or [] if g.get("kind") != "skill"]
        for s in h["slots"]:
            if s["decision"] == "roll":
                r["gaps"].append({"kind": "skill", "gain": s["expectedGain"],
                                  "text": f"Reroll skill slot {s['skillSlot']} ({s['current']}): μέχρι να βγει ένα από "
                                          f"{len(s['acceptLine']['skills'])} skills (+{D.gr(s['expectedGain'])} power "
                                          f"κατά μέσο όρο, ~{s['expectedRolls']} ρίψεις)."})
        f.write_text(json.dumps(r, ensure_ascii=False, indent=1) + "\n")
    sf = D.REVIEWS / "summary.json"
    if sf.exists():
        s = json.loads(sf.read_text())
        s["rerolls"] = {k: out[k] for k in ("generatedAt", "dice", "order", "rerollFirst", "totals", "notes", "log")}
        s["rerolls"]["tasks"] = out["tasks"]
        s["rerollFirst"] = out["rerollFirst"]
        s["dice"] = [{"hero": t["hero"], "class": t["class"], "skill": t["current"], "tierName": t["current"],
                      "rating": t["rating"], "skillSlot": t["skillSlot"], "pBetter": t["perRoll"]["pBetter"],
                      "pWorse": t["perRoll"]["pWorse"], "better": t["acceptLine"]["skills"][:6],
                      "die": t.get("die") or (t["diceAllowed"] or ["?"])[0], "budget": t["budget"],
                      "expectedRolls": t["expectedRolls"], "expectedGain": t["expectedGain"],
                      "status": t["status"], "buildChanging": bool(t["buildChanging"])}
                     for t in out["tasks"] if t["status"] == "planned"]
        sf.write_text(json.dumps(s, ensure_ascii=False, indent=1) + "\n")


# ---------------------------------------------------------------- CLI

def print_hero(h, tasks):
    print(f"## {h['hero']} — {h['class']}: skills {', '.join(h['skills'])} · δύναμη skill set {round(100 * h['strength'])}%"
          + (" · αδύναμο" if h["weak"] else "") + (" · reroll πριν από items" if h["rerollBeforeItems"] else ""))
    for s in h["slots"]:
        t = next((x for x in tasks if x["hero"] == h["hero"] and x["skillSlot"] == s["skillSlot"]), None)
        head = f"- slot {s['skillSlot']} {s['current']} [{s['rating']}] ({round(100 * (s['percentile'] or 0))}% των πιθανών κάτω του)"
        if s.get("keptWith"):
            k = s["keptWith"]
            head += (f" [με {k['item']} {k['quality']} ({k['kind']}) στο slot {k['slot']}: "
                     f"{D.gr(k['powerWithout'])} → {D.gr(k['powerWith'])}]")
        if s["decision"] != "roll":
            print(head + f": κράτα — {s['reason']}")
            continue
        a = s["acceptLine"]
        dice = ", ".join(f"{n} {d.replace(' Skill Die', '')}" for d, n in (t or {}).get("dice", {}).items()) or "δεν φτάνουν τα ζάρια"
        print(head + f": ρίξε μέχρι {', '.join(a['skills'][:6])}{'…' if len(a['skills']) > 6 else ''} "
              f"(P {round(100 * a['pAccept'])}% ανά ρίψη, ~{s['expectedRolls']} ρίψεις, budget {s['budget']}: {dice}) "
              f"→ +{D.gr(s['expectedGain'])} power")
        for b in s["buildChanging"][:3]:
            print(f"    αλλάζει build: {b['skill']} → {b['item']} ({b['kind']}) στο slot {b['slot']}: "
                  f"{D.gr(b['powerWithout'])} → {D.gr(b['powerWith'])} — σταμάτα και συζήτησέ το")


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv and argv[0] == "--class-skills":  # display data only, no calc
        embed_class_skills(argv[1:] or None)
        return 0
    if argv and argv[0] != "--all":
        out = json.loads(OUT.read_text())
        h = next((x for x in out["heroes"] if x["hero"].lower() == " ".join(argv).lower()), None)
        if not h:
            raise SystemExit(f"no plan for {' '.join(argv)}")
        print_hero(h, out["tasks"])
        return 0
    out = run()
    d = out["dice"]
    print(f"ζάρια: " + ", ".join(f"{k.replace(' Skill Die', '')} {d['stock'][k]} (κράτα {d['reserve'][k]}, πλάνο {d['planned'][k]})" for k in DICE))
    print(f"slots για reroll: {out['totals']['slotsToRoll']} (+{D.gr(out['totals']['expectedGain'])} power αναμενόμενα), "
          f"χωρίς ζάρια: {out['totals']['noDice']}; reroll πριν από items: {', '.join(out['rerollFirst']) or '—'}")
    for i, t in enumerate([t for t in out["tasks"] if t["status"] == "planned"][:15], 1):
        print(f"{i:>2}. {t['hero']} slot {t['skillSlot']} {t['current']} [{t['rating']}] με {t['die']} ×{t['budget']}: "
              f"μέχρι {', '.join(t['acceptLine']['skills'][:4])}… → +{D.gr(t['expectedGain'])} ({t['expectedGainPct']}%)"
              + (" · τώρα" if t.get("step") == "now" else " · μετά από ξαναϋπολογισμό")
              + ("".join(f"\n      συζήτησε: {d}" for d in t["discuss"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
