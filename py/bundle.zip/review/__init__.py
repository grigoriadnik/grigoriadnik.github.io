"""Hero reviews: how good each hero is, what to change per slot and from where, roster-wide lists.

    .venv/bin/python -m review              # every hero → data/reviews/<hero>.json + summary.json
    .venv/bin/python -m review "Hero 6"   # print one hero's review (from the saved files)

Numbers come from calc.compute / calc.diff only. README.md here.
"""
