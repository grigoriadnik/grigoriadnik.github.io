"""One hero's review: how good it is, the big gaps, per-slot options with their gain from calc.diff, skills.

Everything is measured in the game's hero power, as calc computes it (calc.diff → delta.power). The roster-wide
allocation of owned items and enchants (one owner, one copy) is in plan.py.
"""
import copy
import json

from . import data as D
from .data import hr

MIN_GAIN = 0.004        # a change under 0.4% of the hero's power (and under 150 power) is not worth a move: keep
LEGENDARY_WORTH = 0.05  # Legendary is flagged only when it adds at least 5% of the hero's power over Epic
# How a source weighs when picking the recommended option. The owner (2026-10-30) wants the best item whatever its
# source, so these only break near-ties: free, then craft, then Market by how often the item shows up there
# (data.AVAILABILITY); too-rare items (special) are never recommended.
WEIGHT = {"enchant": 1.0, "inventory": 1.0, "freed": 1.0, "craft": 0.985, "market": 0.97, "special": 0.0}
RANK = {"enchant": 1, "inventory": 1, "freed": 1, "craft": 2, "market": 3, "special": 4}
LABEL = {"enchant": "Enchant από το stock σου (δωρεάν)", "inventory": "Στην αποθήκη σου — το φοράς (δωρεάν)"}
RATING_RANK = {"S+": 0, "S": 1, "A": 2, "B": 3, "C": 4, "D": 5}
REROLL_RATINGS = ("B", "C", "D")
TIERS_BELOW_TOP = 2     # crafted/bought candidates: the top equippable tier and the two below it
OWNED_TIERS_BELOW = 4   # items already in storage: down to four tiers below the top


class Hero:
    """A hero with calc at hand: gain(changes) = calc.diff delta for a list of slot changes (cached)."""

    def __init__(self, name):
        self.raw = D.hero(name)
        self.name = self.raw["hero"]
        self.h = D.for_compute(self.raw)  # T1 skill names: for compute() on a changed hero
        self.cls = hr.fuzzy(self.raw["class"], hr.classes(), "class")
        self.promoted = bool(self.cls["isPromoted"])
        self.max_tier = self.raw.get("maxEquipmentTier") or hr.max_item_tier(self.raw.get("level") or 40)
        self.shown = D.compute(self.raw)   # with the game's tier names: computed vs the screen
        self.base = D.compute(self.h)      # tiers from the element, as calc.diff's 'before' 
        self.power = self.base["stats"]["power"] or 0
        self.slots = {s["slot"]: s for s in self.raw["slots"]}
        self._cache = {}

    def gain(self, changes):
        key = json.dumps(changes, sort_keys=True)
        if key not in self._cache:
            self._cache[key] = D.delta(D.diff(self.raw, changes))
        return self._cache[key]

    def min_gain(self):
        return max(150, MIN_GAIN * self.power)


def change(slot, it, quality, element, spirit):
    return {"slot": slot, "item": it["name"], "quality": quality, "element": element, "spirit": spirit}


# ---------------------------------------------------------------- candidates

def pool(hero, n):
    """Every item of the top tiers that fits slot n (any source)."""
    lo = hero.max_tier - TIERS_BELOW_TOP
    return [it for it in hr.items() if lo <= it["tier"] <= hero.max_tier and it["type"] not in ("Element", "Spirit")
            and hr.item_fits(hero.cls, n, it)]


def candidates(hero, n, owned_only=False):
    cur = hero.slots.get(n) or {}
    cur_it = D.item(cur["item"]) if cur.get("item") else None
    cur_q = (cur.get("quality") or "Epic").title()
    out = []
    if cur_it:
        out.append({"kind": "enchant", "it": cur_it, "quality": cur_q, "own_el": cur.get("element"),
                    "own_sp": cur.get("spirit")})
    for e in D.inventory_items():
        it = D.item(e["item"])
        if not it or not (hero.max_tier - OWNED_TIERS_BELOW <= it["tier"] <= hero.max_tier) \
                or not hr.item_fits(hero.cls, n, it):
            continue
        if cur_it and it["name"] == cur_it["name"] and D.QUALITY_ORDER.index(e["quality"]) <= D.QUALITY_ORDER.index(cur_q):
            continue
        out.append({"kind": "inventory", "it": it, "quality": e["quality"], "inv": e["key"],
                    "own_el": e.get("element"), "own_sp": e.get("spirit"), "invCount": e["count"]})
    for it in pool(hero, n):
        if cur_it and it["name"] == cur_it["name"] and D.QUALITY_ORDER.index(cur_q) >= D.QUALITY_ORDER.index("Epic"):
            continue
        src = D.item_source(it["name"])
        if owned_only and src["kind"] != "craft":
            continue
        out.append({"kind": src["kind"], "it": it, "quality": "Epic", "source": src})
    return out


def element_options(hero, it):
    """Element enchants worth trying on an item: the class's own T14 (Spellblade: the item's affinity elements
    and the T14 the owner holds most of). None = the item's built-in element fills the slot."""
    if D.built_in(it)[0]:
        return [None]
    etype = hr.class_element(hero.cls)
    if etype != "all":
        return [D.element_ladder(etype)[0]]
    names = [D.element_ladder(a)[0] for a in hr.item_affinity_elements(it) if a != "all" and D.element_ladder(a)]
    stock = D.enchant_stock()
    t14 = [D.element_ladder(t)[0] for t in ("fire", "water", "air", "earth", "light", "dark")]
    names.append(max(t14, key=lambda x: stock.get(x, 0)))
    return list(dict.fromkeys(names))


def fits(it, enchant):
    """An enchant goes on an item up to one tier above it: the roster has T12 enchants on T11 items and none
    further apart (the game's exact rule is not in our data)."""
    return enchant is None or enchant["tier"] <= it["tier"] + 1


def fit_element(it, name):
    """The best enchant of that element the item can take (T14 on a T12 item falls back to T12)."""
    if name is None:
        return None
    e = D.element_info(name)
    for n in D.element_ladder(e["elementType"]):
        if fits(it, D.element_info(n)):
            return n
    return None


def spirit_ranking(hero, n):
    """Spirits on slot n's current item, best power first: the hero-wide effects rank the same on any item."""
    cur = hero.slots.get(n) or {}
    it = D.item(cur["item"]) if cur.get("item") else None
    if not it:
        return list(D.SPIRITS)
    q = (cur.get("quality") or "Epic").title()
    scored = []
    for sp in D.SPIRITS:
        if sp == "Titan Spirit" and not hero.promoted:
            continue
        g = hero.gain([change(n, it, q, cur.get("element"), sp)])["power"]
        scored.append((g, sp))
    return [sp for _, sp in sorted(scored, key=lambda x: -x[0])]


def spirit_options(hero, it, ranked):
    if D.built_in(it)[1]:
        return [None]
    opts = ranked[:3] + [D.affinity_spirit(it), "Tomb-Bound Spirit"]
    if hero.promoted:
        opts.append("Titan Spirit")
    return [s for s in dict.fromkeys(opts) if s in D.SPIRITS and (hero.promoted or s != "Titan Spirit")]


def evaluate(hero, n, cand, ranked, others=()):
    """Best element and spirit for one candidate on slot n (others: changes on the other slots, for builds).
    Keeping an enchant the item already carries costs nothing; a new one comes from the stock."""
    it, q = cand["it"], cand["quality"]
    els = [cand.get("own_el")] if cand.get("own_el") else []
    els += [fit_element(it, e) for e in element_options(hero, it)]
    els = list(dict.fromkeys(els))
    sps = [cand.get("own_sp")] if cand.get("own_sp") else []
    sps += [sp for sp in spirit_options(hero, it, ranked) if fits(it, D.spirit_info(sp))]
    sps = list(dict.fromkeys(sps)) or [None]
    others = [o for o in others if o["slot"] != n]
    tried = {}

    def run(el, sp):
        if (el, sp) not in tried:
            tried[(el, sp)] = hero.gain(others + [change(n, it, q, el, sp)])
        return tried[(el, sp)]
    best_el = max(els, key=lambda el: run(el, sps[0])["power"])
    best_sp = max(sps, key=lambda sp: run(best_el, sp)["power"])
    g = run(best_el, best_sp)
    alts = sorted(([el, sp, v["power"]] for (el, sp), v in tried.items()), key=lambda x: -x[2])
    return {"el": best_el, "sp": best_sp, "gain": g, "alts": alts}


def notes_for(ev):
    notes = []
    if ev["sp"] == "Tomb-Bound Spirit":
        notes.append("Tomb-Bound: +20% στο άθροισμα των bonus του item (όπως στο παιχνίδι, βήμα S01)· διπλό στο "
                     "Tower/Tomb of Titans")
    return notes


def option(hero, n, cand, ev):
    it = cand["it"]
    bel, bsp = D.built_in(it)
    kind = cand["kind"]
    src = cand.get("source") or {}
    needs_el = ev["el"] if ev["el"] and ev["el"] != cand.get("own_el") else None
    needs_sp = ev["sp"] if ev["sp"] and ev["sp"] != cand.get("own_sp") else None
    g = ev["gain"]
    out = {
        "kind": kind, "rank": RANK[kind], "label": LABEL.get(kind) or src.get("label"),
        "detail": src.get("detail") or ("ίδιο item, άλλο enchant" if kind == "enchant" else
                                         f"στην αποθήκη: {cand.get('invCount', 1)}" if kind == "inventory" else ""),
        "item": it["name"], "tier": it["tier"], "type": it["type"], "quality": cand["quality"],
        "element": ev["el"] or bel, "elementBuiltIn": bool(bel and not ev["el"]),
        "spirit": ev["sp"] or bsp, "spiritBuiltIn": bool(bsp and not ev["sp"]),
        "needs": {"item": cand.get("inv"), "element": needs_el, "spirit": needs_sp},
        "gain": g, "gainPct": round(100 * g["power"] / hero.power, 2) if hero.power else None,
        "gems": 0 if kind in ("enchant", "inventory", "craft") else None,
        "change": change(n, it, cand["quality"], ev["el"], ev["sp"]),
        "own": {"element": cand.get("own_el"), "spirit": cand.get("own_sp")},
        "alts": ev["alts"][:8],
        "notes": notes_for(ev),
    }
    out["weight"] = src.get("weight", WEIGHT[kind]) if kind == "market" else WEIGHT[kind]
    out["availability"] = src.get("availability") or ("owned" if kind in ("enchant", "inventory") else None)
    out["score"] = g["power"] * out["weight"]
    if kind == "market":
        out["cost"] = "gold στο Market (gems μόνο αν ο πωλητής ζητά gems)"
    elif kind == "special":
        out["cost"] = "μόνο αν το έχεις (Antique tokens / pack / event)"
    return out


# ---------------------------------------------------------------- slots

def review_slot(hero, n):
    cur = hero.slots.get(n) or {}
    ranked = spirit_ranking(hero, n)
    evaluated = []
    for cand in candidates(hero, n):
        ev = evaluate(hero, n, cand, ranked)
        evaluated.append((cand, ev))
    opts = [option(hero, n, c, e) for c, e in evaluated]
    worn = [s for s in hero.slots.values() if s.get("slot") != n and D.is_artifact(s.get("item"))]
    for o in opts:
        o["artifact"] = D.is_artifact(o["item"])
        if o["artifact"] and worn:
            o["artifactWith"] = {"slot": worn[0]["slot"], "item": worn[0]["item"]}
            o["notes"] = o["notes"] + [f"Ένα Artifact ανά ήρωα: πρώτα να βγει το {worn[0]['item']} (slot {worn[0]['slot']})"]
    worth = [o for o in opts if o["gain"]["power"] >= hero.min_gain()]
    best_by_kind = {}
    for o in sorted(opts, key=lambda o: -o["gain"]["power"]):
        best_by_kind.setdefault(o["kind"], []).append(o)
    shown = []
    for kind, k in (("enchant", 1), ("inventory", 2), ("craft", 2), ("market", 1), ("special", 1)):
        shown += [o for o in best_by_kind.get(kind, [])[:k] if o["gain"]["power"] > 0]
    ranked_opts = sorted((o for o in worth if o["kind"] != "special"), key=lambda o: -o["score"])
    buy = sorted((o for o in worth if o["kind"] in ("market", "special")), key=lambda o: -o["gain"]["power"])
    cur_it = D.item(cur["item"]) if cur.get("item") else None
    return {
        "slot": n, "types": hr.slot_types(hero.cls, n),
        "current": {"item": cur.get("item"), "tier": cur.get("tier") or (cur_it or {}).get("tier"),
                    "type": cur.get("type") or (cur_it or {}).get("type"), "quality": cur.get("quality"),
                    "element": cur.get("element") or (D.built_in(cur_it)[0] if cur_it else None),
                    "spirit": cur.get("spirit") or (D.built_in(cur_it)[1] if cur_it else None),
                    "source": D.item_source(cur["item"]) if cur.get("item") else None},
        "spiritRanking": ranked[:6],
        "options": sorted(shown, key=lambda o: (o["rank"], -o["gain"]["power"]))[:7],
        "choices": ranked_opts[:12],   # options worth a move (no "if you have it"), best score first: plan.py picks
        "buy": buy[:4],                # the best Market / too-rare options, for the Market list
        "pool": _pool(worth),          # the best distinct items, for the alternatives (plan.finish)
        "_cands": [c for c, e in sorted(evaluated, key=lambda ce: -ce[1]["gain"]["power"])],  # for the builds
    }


def _pool(opts, n=8):
    """The best option of each item that is not too rare, best gain first (light copies)."""
    seen, out = set(), []
    for o in sorted(opts, key=lambda o: -o["gain"]["power"]):
        if o["kind"] == "special" or o["item"] in seen:
            continue
        seen.add(o["item"])
        keep = ("kind", "label", "detail", "item", "tier", "type", "quality", "element", "elementBuiltIn", "spirit",
                "spiritBuiltIn", "availability", "change")
        out.append(dict({k: o[k] for k in keep}, gain=o["gain"]["power"]))
        if len(out) >= n:
            break
    return out


def legendary(hero, n, opt):
    """What a Legendary of the recommended item (or the current one) adds over its Epic, by calc.diff."""
    if opt:
        ch = dict(opt["change"])
        if ch["quality"] == "Legendary":
            return None
        base_power = opt["gain"]["power"]
    else:
        cur = hero.slots.get(n) or {}
        if not cur.get("item") or (cur.get("quality") or "").title() == "Legendary":
            return None
        ch = {"slot": n, "item": cur["item"], "quality": cur.get("quality"), "element": cur.get("element"),
              "spirit": cur.get("spirit")}
        base_power = 0
    if (ch["quality"] or "").title() != "Epic":
        ep = dict(ch, quality="Epic")
        base_power = hero.gain([ep])["power"]
        ch = ep
    g = hero.gain([dict(ch, quality="Legendary")])
    extra = g["power"] - base_power
    return {"item": ch["item"], "extraPower": extra, "extraPct": round(100 * extra / hero.power, 2) if hero.power else None,
            "worth": bool(hero.power and extra >= LEGENDARY_WORTH * hero.power),
            "how": "Legendary από fusion ή craft — τύχη· μόνο με συζήτηση πρώτα"}


# ---------------------------------------------------------------- builds

def build(hero, per_slot, picks=8, passes=2):
    """Coordinate ascent over the slots: each slot takes the option that adds most to the whole build.
    per_slot: {n: [(cand, ev), ...]} ranked by single-slot gain. Unlimited enchants."""
    chosen = {}
    ranked = {n: spirit_ranking(hero, n) for n in per_slot}
    for _ in range(passes):
        for n, cands in per_slot.items():
            others = [c for k, c in chosen.items() if k != n]
            base = hero.gain(others)["power"] if others else 0
            best, best_power = None, base
            for cand, _ev in cands[:picks]:
                if len(D.artifact_slots(hero.raw, others + [{"slot": n, "item": cand["it"]["name"]}])) > 1:
                    continue  # one Artifact per hero
                ev = evaluate(hero, n, cand, ranked[n], others)
                if ev["gain"]["power"] > best_power:
                    best, best_power = (cand, ev), ev["gain"]["power"]
            if best:
                chosen[n] = change(n, best[0]["it"], best[0]["quality"], best[1]["el"], best[1]["sp"])
                chosen[n]["kind"] = best[0]["kind"]
            else:
                chosen.pop(n, None)
    changes = [dict((k, v) for k, v in c.items() if k != "kind") for c in chosen.values()]
    res = D.diff(hero.raw, changes) if changes else None
    return {"changes": [chosen[n] for n in sorted(chosen)],
            "power": res["stats"]["power"] if res else hero.power,
            "gain": D.delta(res) if res else {k: 0 for k in D.STAT_KEYS}}


def stc_build(hero):
    """The STC best-in-slot set for the class, Epic, each item with its best element and spirit."""
    sets = hr.sets_for_class(hero.cls)
    if not sets:
        return None
    s = sets[0]
    per_slot, used = {}, set()
    for row in s["slots"]:
        it = D.item(row["name"])
        if not it or it["tier"] > hero.max_tier:
            continue
        n = next((k for k in range(1, 7) if k not in used and hr.item_fits(hero.cls, k, it)), None)
        if n is None:
            continue
        used.add(n)
        per_slot[n] = [({"kind": D.item_source(it["name"])["kind"], "it": it, "quality": "Epic"}, None)]
    b = build(hero, per_slot, picks=1, passes=2)
    # build() keeps the current item where the STC one is weaker for this hero; the set itself is what we report
    b["heading"] = s["heading"]
    b["notes"] = s["notes"]
    b["items"] = [{"slot": n, "item": c[0][0]["it"]["name"], "tier": c[0][0]["it"]["tier"]}
                  for n, c in sorted(per_slot.items())]
    return b


# ---------------------------------------------------------------- hero-level gaps

def element_need(cls, skill_names, promoted):
    need = 0
    for name in skill_names:
        sk = hr.skills().get(name.lower())
        if not sk:
            continue
        top = sk["tiers"][-1] if promoted else [t for t in sk["tiers"] if not t["requiresPromotion"]][-1]
        need = max(need, top["elementThreshold"])
    tiers = cls["innate"]["tiers"]
    top = tiers[-1] if promoted else [t for t in tiers if not t["requiresPromotion"]][-1]
    return max(need, top["elementThreshold"])


def promotion(hero):
    if hero.promoted or not hero.cls.get("promotesTo"):
        return None
    p = copy.deepcopy(hero.h)
    p["promoted"] = True
    p["seeds"] = hero.base["seedsUsed"]
    r = D.compute(p)
    promo = hr.classes().get(hero.cls["promotesTo"].lower())
    before = {s["name"]: s["tier"] for s in hero.base["skills"]}
    after = [{"name": s["name"], "from": before.get(s["name"]), "to": s["tier"], "tierName": s["tierName"]}
             for s in r["skills"]]
    gain = (r["stats"]["power"] or 0) - hero.power
    titans = [s["slot"] for s in hero.raw["slots"] if s.get("spirit") == "Titan Spirit"]
    return {"to": hero.cls["promotesTo"], "power": r["stats"]["power"], "gain": gain,
            "gainPct": round(100 * gain / hero.power, 1) if hero.power else None,
            "delta": {k: r["stats"][k] - hero.base["stats"][k] for k in D.STAT_KEYS if r["stats"][k] is not None},
            "skills": after, "innate": {"from": hero.base["innate"]["name"], "to": r["innate"]["name"]},
            "elementNeed": element_need(promo, D.base_skill_names(hero.raw), True) if promo else None,
            "titanSlots": titans,
            "skillSlotsAfter": promo["skillUnlockLevels"] if promo else None,
            "extraSkillSlot": bool(promo and len(promo["skillUnlockLevels"]) > len(hero.cls["skillUnlockLevels"])),
            "cost": "δεν το έχουμε στα δεδομένα — διάβασέ το στην οθόνη του ήρωα πριν από το OK"}


def element_review(hero, promo):
    used, comp = hero.base["elementUsed"], hero.base["elementComputed"]
    need = element_need(hero.cls, D.base_skill_names(hero.raw), hero.promoted)
    out = {"shown": hero.raw.get("elementShown"), "computed": comp, "used": used, "need": need,
           "needAfterPromotion": promo["elementNeed"] if promo else None}
    if used >= need:
        out["status"] = "ok"
        out["text"] = f"element {used} ≥ {need}: όλα τα skills στο max tier" + (f" (περίσσευμα {used - need})" if used > need else "")
    else:
        out["status"] = "short"
        out["text"] = f"element {used} < {need}: λείπουν {need - used} για το max tier"
    if promo and promo["elementNeed"] and used < promo["elementNeed"]:
        out["text"] += f"· μετά το promotion θέλει {promo['elementNeed']} (λείπουν {promo['elementNeed'] - used})"
    weak = []
    for s in hero.raw["slots"]:
        e = D.element_info(s.get("element"))
        it = D.item(s["item"]) if s.get("item") else None
        if it and D.built_in(it)[0]:
            continue
        if not e:
            weak.append({"slot": s["slot"], "issue": "χωρίς element"})
        elif hr.class_element(hero.cls) not in ("all", e["elementType"]) and "all" not in hr.item_affinity_elements(it or {}):
            weak.append({"slot": s["slot"], "issue": f"{e['name']} δεν μετράει σε {hero.cls['element']} ήρωα"})
        elif e["tier"] < 14:
            weak.append({"slot": s["slot"], "issue": f"{e['name']} είναι T{e['tier']} (το T14 δίνει +{35 - e['elementAmount']} element και περισσότερα stats)"})
    out["weakSlots"] = weak
    return out


def skills_review(hero):
    page = hr.rating_page(hero.cls)
    names = D.base_skill_names(hero.raw)
    computed = {s["name"]: s for s in hero.base["skills"]}
    pool = [s for s in hr.skills().values() if not s.get("isInnate") and hero.cls["name"] in (s.get("classes") or [])
            and s["name"] not in names]
    slot_of = {t["skill"]: t["slot"] for t in hero.raw.get("skillTiers") or []}
    rarity_of = {t["skill"]: t.get("rarity") for t in hero.raw.get("skillTiers") or []}
    out = []
    for name in names:
        r = page.get(name)
        rank = RATING_RANK.get(r, 6)
        better = [s["name"] for s in pool if RATING_RANK.get(page.get(s["name"]), 6) < rank]
        worse = [s["name"] for s in pool if RATING_RANK.get(page.get(s["name"]), 6) > rank]
        c = computed.get(name) or {}
        row = {"name": name, "tier": c.get("tier"), "tierName": c.get("tierName"), "rating": r,
               "rarity": rarity_of.get(name), "skillSlot": slot_of.get(name),
               "reroll": r in REROLL_RATINGS or r is None}
        if row["reroll"] and pool:
            row["pBetter"] = round(len(better) / len(pool), 2)
            row["pWorse"] = round(len(worse) / len(pool), 2)
            row["poolSize"] = len(pool)
            row["better"] = sorted(better, key=lambda x: RATING_RANK.get(page.get(x), 6))[:8]
        out.append(row)
    return out


SEED_ITEM = {"attack": "Seed of Power", "defense": "Seed of Resistance", "hp": "Seed of Vitality"}
SEED_CAP = 40  # without a blossom (calc/data/rules.json)


def seeds_review(hero):
    """Seeds the hero could still take, per stat, and what they add (calc.compute with the seeds filled up).
    The game shows no seed count: calc infers it from the shown stats; 'sure' is false where it could not."""
    used = hero.base.get("seedsUsed") or {}
    inferred = set(hero.base.get("seedsInferred") or [])
    out = {}
    for stat, name in SEED_ITEM.items():
        have = used.get(stat) or 0
        if have >= SEED_CAP:
            continue
        h = copy.deepcopy(hero.h)
        h["seeds"] = dict(used, **{stat: SEED_CAP})
        r = D.compute(h)
        gain = (r["stats"]["power"] or 0) - hero.power
        if gain > 0:
            out[stat] = {"item": name, "have": have, "need": SEED_CAP - have, "sure": stat in inferred, "gain": gain,
                         "delta": r["stats"][stat] - hero.base["stats"][stat]}
    return out


def confidence(hero):
    chk = hero.shown.get("check") or {}
    p = chk.get("power") or {}
    shown, comp = p.get("shown"), p.get("computed")
    pct = round(100 * (comp - shown) / shown, 1) if shown and comp is not None else None
    off = [k for k, v in chk.items() if k != "power" and v.get("diff") not in (0, None) and
           abs(v["diff"]) > max(1, 0.01 * abs(v.get("shown") or 0))]
    if pct is None:
        level = "low"
    elif abs(pct) <= 1 and not off:
        level = "high"
    elif abs(pct) <= 5:
        level = "medium"
    else:
        level = "low"
    names = {"attack": "ATK", "defense": "DEF", "hp": "HP", "evasion": "EVA", "critChance": "crit chance",
             "critDamage": "crit damage", "element": "element", "threat": "threat"}
    off_text = ", ".join(names.get(k, k) for k in off)
    text = {"high": "Σίγουρα νούμερα: το calc βγάζει τα stats και το power που δείχνει το παιχνίδι.",
            "medium": f"Σχεδόν σωστά: το calc απέχει {pct:+}% στο power" + (f" και διαφέρει στο {off_text}" if off else "") + ".",
            "low": f"Αβέβαια νούμερα: το calc απέχει {pct:+}% από το power του παιχνιδιού — οι σειρές μετράνε, "
                   f"τα ακριβή κέρδη όχι."}[level]
    items_off = []
    for s in hero.raw["slots"]:
        shown_it = s.get("shown") or {}
        mine = next((x for x in hero.shown.get("slots", []) if x.get("slot") == s["slot"]), {})
        for stat in ("attack", "defense", "hp"):
            a, b = shown_it.get(stat), mine.get(stat)
            if a and b is not None and abs(a - b) > max(2, 0.03 * a):
                items_off.append({"slot": s["slot"], "item": s.get("item"), "stat": stat, "shown": a, "computed": b})
    if items_off:
        text += " Το popup του item δείχνει άλλα νούμερα από το calc: " + ", ".join(
            sorted({f"slot {x['slot']} {x['item']} ({names.get(x['stat'], x['stat'])} {D.gr(x['shown'])} αντί για {D.gr(x['computed'])})"
                    for x in items_off})) + " — το calc το ψάχνει."
    return {"level": level, "powerShown": shown, "powerComputed": comp, "diffPct": pct, "statsOff": off,
            "itemsOff": items_off, "text": text, "warnings": hero.shown.get("warnings", [])}


# ---------------------------------------------------------------- one hero

def analyze(name):
    """Everything about one hero that does not depend on the other heroes (allocation is in plan.py)."""
    hero = Hero(name)
    slots = [review_slot(hero, n) for n in range(1, 7)]
    per_slot = {s["slot"]: [(c, None) for c in s.pop("_cands")] for s in slots}
    ideal = build(hero, per_slot)
    owned_slots = {n: [c for c in cs if c[0]["kind"] in ("enchant", "inventory", "craft")] for n, cs in per_slot.items()}
    owned = build(hero, owned_slots)
    stc = stc_build(hero)
    promo = promotion(hero)
    ceiling = max(ideal["power"], stc["power"] if stc else 0, hero.power)
    return {
        "kind": "hero", "id": hero.name, "hero": hero.name, "class": hero.cls["name"],
        "classType": hero.cls["type"], "element": hero.cls["element"], "level": hero.raw.get("level"),
        "promoted": hero.promoted, "promotesTo": hero.cls.get("promotesTo"), "maxTier": hero.max_tier,
        "order": hero.raw.get("order"), "capturedAt": hero.raw.get("capturedAt"),
        "power": {"shown": hero.raw["stats"].get("power"), "computed": hero.power},
        "confidence": confidence(hero),
        "score": {"current": hero.power, "ceiling": ceiling, "pct": round(100 * hero.power / ceiling, 1) if ceiling else None,
                  "stc": stc["power"] if stc else None, "owned": owned["power"],
                  "ownedPct": round(100 * owned["power"] / ceiling, 1) if ceiling else None},
        "promotion": promo,
        "elementReview": element_review(hero, promo),
        "skills": skills_review(hero),
        "seeds": seeds_review(hero),
        "slots": slots,
        "ideal": ideal, "ownedBuild": owned, "stc": stc,
        "legendary": {s["slot"]: legendary(hero, s["slot"], s["choices"][0] if s["choices"] else None) for s in slots},
    }
