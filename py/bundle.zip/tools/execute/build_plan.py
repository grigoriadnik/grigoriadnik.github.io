"""Turn the review into an ordered action plan: data/actions/plan.json + data/actions/PLAN.md (Greek).

    .venv/bin/python tools/execute/build_plan.py            # after `python -m review`
    .venv/bin/python tools/execute/build_plan.py --keep     # keep the status/result of steps already in plan.json

Order (gain per cost): the Tomb-Bound test, free equips from storage, enchants from stock, promotions, seeds,
owner crafts, Market buys, dice rerolls. Each stored item and enchant goes to one step only (the review's
allocation); the script checks that against the stock and stops if two steps want the same thing.
"""
import collections
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
REVIEWS = os.path.join(ROOT, "data", "reviews")
ROSTER = os.path.join(ROOT, "data", "roster")
OUT = os.path.join(ROOT, "data", "actions")

TOMB = "Tomb-Bound Spirit"
# The first Tomb-Bound step: a stored item with an empty spirit slot, so nothing is lost if calc is wrong
# (Tomb-Bound's own flat stats still beat the T14 alternative), and the popup can be read before and after.
TEST = ("Hero 16", 6)

PHASES = [
    ("test", "Τεστ Tomb-Bound"),
    ("equip", "Φόρεμα από την αποθήκη"),
    ("enchant", "Enchant από το stock"),
    ("promotion", "Promotion"),
    ("seeds", "Seeds"),
    ("craft", "Craft (εσύ) και μετά φόρεμα"),
    ("market", "Market (εσύ) και μετά φόρεμα"),
    ("reroll", "Reroll με dice (τύχη)"),
]
KIND_PHASE = {"inventory": "equip", "freed": "equip", "enchant": "enchant", "promotion": "promotion", "seeds": "seeds",
              "craft": "craft", "market": "market"}


def load(path):
    with open(path) as f:
        return json.load(f)


def sgn(n):
    return ("+" if n >= 0 else "−") + fmt(abs(n))


def fmt(n):
    return "—" if n is None else f"{n:,}".replace(",", ".")


def slot_of(review, n):
    for s in review["slots"]:
        if s["slot"] == n:
            return s
    return None


def enchant_actions(slot, rec, base):
    """Enchant sub-actions for a slot change, and what each overwrites (the game cannot take an enchant off)."""
    acts, lost = [], []
    needs = rec.get("needs") or {}
    for kind in ("element", "spirit"):
        want = needs.get(kind)
        if not want:
            continue
        old = (base or {}).get(kind)
        acts.append({"do": "enchant", "box": kind, "enchant": want, "replaces": old})
        if old and old != want:
            lost.append(old)
    return acts, lost


def step_for_move(m, review, order):
    phase = KIND_PHASE[m["kind"]]
    st = {"hero": m["hero"], "class": review["class"], "gameIndex": order.index(m["hero"]) + 1,
          "slot": m.get("slot"), "phase": phase, "kind": m["kind"], "text": m["text"],
          "gain": {"power": m["gain"], "pct": m.get("gainPct"), "alone": m.get("gainAlone")},
          "heroPower": review["power"]["shown"], "confidence": review["confidence"]["level"],
          "gems": 0 if m["kind"] in ("inventory", "enchant", "seeds", "craft") else m.get("gems"),
          "status": "planned", "notes": list(m.get("notes") or [])}
    if m["kind"] in ("inventory", "freed", "enchant", "craft", "market"):
        s = slot_of(review, m["slot"])
        rec, cur = s["recommended"], s["current"]
        st["before"] = {k: cur.get(k) for k in ("item", "quality", "tier", "element", "spirit")}
        st["after"] = {"item": rec["item"], "quality": rec["quality"], "tier": rec["tier"],
                       "element": rec["element"], "spirit": rec["spirit"]}
        st["change"] = rec["change"]
        if rec.get("withoutTombBound"):
            st["gain"]["withoutTombBound"] = rec["withoutTombBound"]
        acts = []
        if m["kind"] == "enchant":
            ench, lost = enchant_actions(s, rec, cur)
            acts += ench
        else:
            if m["kind"] == "inventory":
                src = "την αποθήκη"
                own = rec.get("own") or {}
            elif m["kind"] == "freed":
                src = f"την αποθήκη (το βγάζει το βήμα του {m['after']})"
                own = rec.get("own") or {}
                st["dependsOn"] = m["after"]
                st["status"] = "waits-step"
            elif m["kind"] == "craft":
                src = "το craft σου"
                own = {}
            else:
                src = "την αγορά σου από το Market"
                own = {}
            acts.append({"do": "equip", "item": rec["item"], "quality": rec["quality"], "from": src,
                         "replaces": (cur["item"] + " (" + (cur.get("quality") or "?") + ")") if cur.get("item") else None})
            ench, lost = enchant_actions(s, rec, own)
            acts += ench
        # the review picks items with their target enchants; boxes whose enchant the stock lacks (at the item's
        # quality or better) stay as they are now and are filled in a later step, when the enchant arrives
        missing = m.get("enchantsMissing") or {}
        if missing:
            now = cur if m["kind"] == "enchant" else (rec.get("own") or {}) if m["kind"] in ("inventory", "freed") else {}
            st["target"] = dict(st["after"])
            st["change"] = dict(st["change"])
            for box in missing:
                st["after"][box] = now.get(box)
                st["change"][box] = now.get(box)
            acts = [a for a in acts if not (a["do"] == "enchant" and a["box"] in missing)]
            lost = [a["replaces"] for a in acts if a["do"] == "enchant" and a["replaces"] and a["replaces"] != a["enchant"]]
            st["waitsFor"] = [missing[b] for b in ("element", "spirit") if b in missing]
            now_gain = m.get("nowGain", 0)
            st["gain"].update({"target": m["gain"], "power": now_gain, "alone": now_gain,
                               "pct": round(100.0 * now_gain / review["power"]["shown"], 2)})
            if not m.get("doNow") and st["status"] == "planned":
                st["status"] = "waits-enchant"
        st["alternatives"] = m.get("alternatives") or rec.get("alternatives")
        st["availability"] = m.get("availability")
        st["actions"] = acts
        st["consumes"] = {"enchants": [a["enchant"] for a in acts if a["do"] == "enchant"]}
        if m["kind"] == "inventory":
            st["consumes"]["storedItem"] = rec["item"] + " (" + rec["quality"] + ")"
        if m["kind"] == "freed":
            st["consumes"]["freedItem"] = rec["item"] + " (" + rec["quality"] + ")"
        st["lost"] = lost
        st["freed"] = (cur["item"] + " (" + cur["quality"] + ")" +
                       ("" if not (cur.get("element") or cur.get("spirit")) else
                        ", με " + " + ".join(x for x in (cur.get("element"), cur.get("spirit")) if x))
                       ) if m["kind"] != "enchant" and cur.get("item") else None
        st["tombBound"] = TOMB in [a.get("enchant") for a in acts]
    if m["kind"] == "promotion":
        p = review["promotion"]
        st["to"] = p["to"]
        st["actions"] = [{"do": "promote", "to": p["to"]}]
        st["consumes"] = {"gold": "διαβάζεται στην οθόνη του ήρωα", "other": "διαβάζεται στην οθόνη"}
        st["lost"] = []
        st["tombBound"] = False
    if m["kind"] == "seeds":
        st["actions"] = [{"do": "use", "item": m["item"], "count": int(m["text"].split()[0])}]
        st["consumes"] = {"seeds": {m["item"]: int(m["text"].split()[0])}}
        st["lost"] = []
        st["tombBound"] = False
    who = {"inventory": "claude", "freed": "claude", "enchant": "claude", "promotion": "claude", "seeds": "claude",
           "craft": "owner+claude", "market": "owner+claude"}[m["kind"]]
    st["who"] = who
    st["cost"] = cost_text(st, m)
    st["reversible"] = {
        "inventory": "εν μέρει: το item ξαναβγαίνει, τα enchants που μπαίνουν όχι",
        "freed": "ναι: μόνο αλλαγή item",
        "enchant": "όχι: το enchant δεν βγαίνει, το παλιό χάνεται",
        "promotion": "όχι",
        "seeds": "όχι",
        "craft": "όχι (υλικά του craft)· το φόρεμα ναι",
        "market": "όχι (gold)· το φόρεμα ναι",
    }[m["kind"]]
    return st


def cost_text(st, m):
    parts = []
    if m["kind"] == "promotion":
        return "gold/υλικά: διαβάζεται στην οθόνη πριν από το OK"
    if m["kind"] == "seeds":
        return f"{st['actions'][0]['count']} {st['actions'][0]['item']} από την αποθήκη"
    if m["kind"] == "freed":
        return f"τίποτα (το item το βγάζει το βήμα του {m['after']})"
    if m["kind"] == "craft":
        parts.append(f"craft {m['item']} μέχρι Epic (εσύ)")
    if m["kind"] == "market":
        parts.append(f"{m['item']} Epic από Market (gold)")
    en = st["consumes"]["enchants"]
    if en:
        parts.append(" + ".join(en) + " από το stock")
    if st.get("lost"):
        parts.append("χάνεται: " + ", ".join(st["lost"]))
    if st.get("waitsFor"):
        parts.append("λείπει (μπαίνει όταν έρθει): " + ", ".join(st["waitsFor"]))
    return "; ".join(parts) or "τίποτα"


def reroll_steps(summary, order):
    # summary["dice"] comes from the reroll planner (review/rerolls.py): one slot per hero, a dice budget and the
    # expected gain; the roll itself is logged in data/actions/rolls.json, not through step.py
    out = []
    for d in summary["dice"]:
        budget = d.get("budget") or 1
        out.append({"hero": d["hero"], "class": d["class"], "gameIndex": order.index(d["hero"]) + 1,
                    "slot": None, "phase": "reroll", "kind": "reroll",
                    "text": f"Reroll {d['skill']} [{d['rating']}] (skill {d['skillSlot']}) με {d['die']} ×{budget}",
                    "skill": d["skill"], "tierName": d["tierName"], "rating": d["rating"],
                    "skillSlot": d["skillSlot"], "odds": {"better": d["pBetter"], "worse": d["pWorse"]},
                    "betterExamples": d.get("better"), "die": d["die"], "budget": budget,
                    "expectedRolls": d.get("expectedRolls"), "buildChanging": d.get("buildChanging"),
                    "actions": [{"do": "reroll", "skill": d["skill"], "die": d["die"]}],
                    "consumes": {"dice": {d["die"]: budget}}, "lost": [d["skill"] + " (αν βγει άλλο)"],
                    "who": "claude", "gems": 0, "cost": f"μέχρι {budget} {d['die']}",
                    "reversible": "όχι — τύχη, μπορεί να βγει χειρότερο",
                    "gain": {"power": None, "expected": d.get("expectedGain"),
                             "note": "αναμενόμενο κέρδος του planner· το πραγματικό φαίνεται μετά τη ρίψη"},
                    "heroPower": d.get("power"), "tombBound": False, "status": "planned", "notes": []})
    return out


def check_allocation(steps, inv):
    """Every enchant and stored item at most as many times as the stock holds."""
    stock = collections.Counter()
    for e in inv["enchants"]:
        stock[e["item"]] += e.get("count") or 1
    items = collections.Counter()
    for it in inv["items"]:
        items[f"{it['item']} ({it['quality']})"] += it.get("count") or 1
    want_e, want_i, problems = collections.Counter(), collections.Counter(), []
    for s in steps:
        if s["phase"] in ("craft", "market") or s["status"] in ("done", "skipped", "failed"):
            continue  # not yet made (the review checks those against stock too), or already taken from the stock
        for e in s.get("consumes", {}).get("enchants", []):
            want_e[e] += 1
        if s.get("consumes", {}).get("storedItem"):
            want_i[s["consumes"]["storedItem"]] += 1
    for e, n in want_e.items():
        if n > stock[e]:
            problems.append(f"{e}: {n} βήματα, stock {stock[e]}")
    for i, n in want_i.items():
        if n > items[i]:
            problems.append(f"{i}: {n} βήματα, αποθήκη {items[i]}")
    left = {e: stock[e] - want_e[e] for e in want_e}
    return problems, dict(want_e), left


def use_freed(steps, reviews):
    """An item a step takes off a hero goes back to storage with its enchants, and the review does not offer it
    again. Give it to a later equip step's slot when calc says it beats that step alone: it costs no enchants."""
    sys.path.insert(0, ROOT)
    from calc import diff
    items = {it["name"]: it for it in load(os.path.join(ROOT, "data", "items.json"))}
    type_name = {x["key"]: x["name"] for x in load(os.path.join(ROOT, "data", "lookups.json"))["itemTypes"]}
    heroes = {}
    for i, s in enumerate(steps):
        b = s.get("before")
        if s["phase"] not in ("test", "equip") or not b or b["quality"] not in ("Epic", "Legendary"):
            continue
        it = items.get(b["item"]) or {}
        kinds = {it.get("type")} | {type_name.get(k) for k in it.get("subTypes") or []}
        best = None
        for t in steps[i + 1:]:
            if t["phase"] != "equip" or t.get("dependsOn") or not kinds & set(slot_of(reviews[t["hero"]], t["slot"])["types"]):
                continue
            h = heroes.setdefault(t["hero"], load(os.path.join(ROSTER, "heroes", t["hero"] + ".json")))
            ch = {"slot": t["slot"], "item": b["item"], "quality": b["quality"], "element": b["element"],
                  "spirit": b["spirit"]}
            g = diff(h, [ch])["delta"]["power"]
            alone = t["gain"].get("alone") or t["gain"]["power"]
            if g > alone and (best is None or g - alone > best[0]):
                best = (g - alone, t, ch, g, alone)
        if not best:
            continue
        _, t, ch, g, alone = best
        old = t["after"]
        t["notes"].append(f"Αντί για {old['item']} {old['quality']} από την αποθήκη (+{fmt(alone)}): το {b['item']} "
                          f"{b['quality']} που βγαίνει στο βήμα του {s['hero']} slot {s['slot']}, με τα enchants του "
                          f"(calc +{fmt(g)}), χωρίς να ξοδευτούν enchants. Το {old['item']} μένει στην αποθήκη.")
        t.update({"dependsOn": f"{s['hero']} slot {s['slot']}", "change": ch,
                  "after": {"item": b["item"], "quality": b["quality"], "tier": b["tier"],
                            "element": b["element"], "spirit": b["spirit"]},
                  "actions": [{"do": "equip", "item": b["item"], "quality": b["quality"],
                               "from": f"την αποθήκη (βγαίνει από {s['hero']})",
                               "replaces": t["before"]["item"] + " (" + t["before"]["quality"] + ")"}],
                  "consumes": {"enchants": [], "freedItem": f"{b['item']} ({b['quality']})"}, "lost": [],
                  "tombBound": False, "cost": f"τίποτα (το item βγαίνει από {s['hero']})",
                  "reversible": "ναι: μόνο αλλαγή item",
                  "text": f"φόρεσε {b['item']} ({b['quality']}) που βγαίνει από {s['hero']}, αντί για {t['before']['item']}"})
        t["gain"].update({"power": g, "alone": g, "pct": round(100.0 * g / t["heroPower"], 2)})
        t["gain"].pop("withoutTombBound", None)
        if t["status"] == "planned":
            t["status"] = "waits-step"


def owner_tasks(steps, summary):
    """What the owner gathers between sessions (read by the site's bucket list): items to craft or buy on the
    Market, grouped by item and quality with the steps that wait on them, and the enchants the stock lacks
    (by the quality the waiting items need)."""
    out = {"craft": [], "market": [], "enchants": []}
    for phase in ("craft", "market"):
        groups = collections.OrderedDict()
        for s in steps:
            if s["phase"] != phase or s["status"] in ("done", "skipped", "failed"):
                continue
            a = s["after"]
            g = groups.setdefault((a["item"], a["quality"]), {"item": a["item"], "quality": a["quality"],
                                                              "tier": a.get("tier"), "count": 0, "steps": [],
                                                              "for": [], "gain": 0})
            g["count"] += 1
            g["steps"].append(s["id"])
            g["for"].append(f"{s['hero']} slot {s['slot']}")
            g["gain"] += s["gain"].get("power") or 0
        out[phase] = list(groups.values())
    for e in summary.get("enchantsShort") or []:
        by_q = collections.Counter(f.get("quality") or "Epic" for f in e.get("for") or [])
        out["enchants"].append({"enchant": e["enchant"], "count": e["count"],
                                "byQuality": {q: n for q, n in by_q.items()}, "gain": e.get("lost")})
    return out


def build(keep):
    summary = load(os.path.join(REVIEWS, "summary.json"))
    order = load(os.path.join(ROSTER, "index.json"))["heroes"]
    inv = load(os.path.join(ROSTER, "inventory.json"))
    reviews = {}
    for name in order:
        reviews[name] = load(os.path.join(REVIEWS, name + ".json"))
    steps = []
    for m in summary["allMoves"]:
        if m["kind"] == "freed" and m["quality"] not in ("Epic", "Legendary"):
            continue  # the owner's rule: only Epic and Legendary items
        steps.append(step_for_move(m, reviews[m["hero"]], order))
    steps += reroll_steps(summary, order)
    test_done = keep and ((load(os.path.join(OUT, "plan.json")) or {}).get("tombBoundTest") or {}).get("status") == "done"
    for s in steps:
        if (s["hero"], s["slot"]) == TEST and s["tombBound"]:
            s["phase"] = "test"
            s["notes"].insert(0, "Πρώτο βήμα: φόρεμα, διάβασμα του popup, Tomb-Bound, ξανά διάβασμα, σύγκριση με το calc. "
                                 "Μετά το Apotheosis.")
        elif s["tombBound"] and not test_done:
            s["status"] = "waits-test"
    rank = {p: i for i, (p, _) in enumerate(PHASES)}
    steps.sort(key=lambda s: (rank[s["phase"]], -(s["gain"].get("power") or 0),
                              -(s["odds"]["better"] - s["odds"]["worse"]) if s["phase"] == "reroll" else 0))
    if not any(m["kind"] == "freed" for m in summary["allMoves"]):
        use_freed(steps, reviews)  # older reviews did not offer items freed by other steps
    test = {"step": None, "status": "pending"}
    if keep and os.path.exists(os.path.join(OUT, "plan.json")):
        old_plan = load(os.path.join(OUT, "plan.json"))
        test = old_plan.get("tombBoundTest") or test
        old = {(o["hero"], o.get("slot"), o["kind"], o["text"]): o for o in old_plan["steps"]
               if o["status"] in ("done", "skipped", "failed")}
        for s in steps:
            o = old.pop((s["hero"], s.get("slot"), s["kind"], s["text"]), None)
            if o:
                s["status"], s["result"], s["id"] = o["status"], o.get("result"), o["id"]
        # finished steps the new review no longer lists (their change is now the hero's current gear) stay as they were
        steps += list(old.values())
        steps.sort(key=lambda s: (rank[s["phase"]], s["status"] not in ("done", "skipped", "failed"),
                                  -(s["gain"].get("power") or 0),
                                  -(s["odds"]["better"] - s["odds"]["worse"]) if s["phase"] == "reroll" else 0))
    # ids of finished steps never change (log.json refers to them); new steps are numbered after the highest one
    n = max([int(s["id"][1:]) for s in steps if s.get("id")] or [0])
    for s in steps:
        if not s.get("id"):
            n += 1
            s["id"] = f"S{n:02d}"
    problems, used, left = check_allocation(steps, inv)
    if problems:
        print("Δύο βήματα θέλουν το ίδιο πράγμα:\n- " + "\n- ".join(problems))
        sys.exit(1)
    plan = {"generatedAt": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "fromReview": summary["generatedAt"],
            "rules": ["Ένα OK = ένα βήμα. Πριν από κάθε βήμα: τι πατιέται και τι κοστίζει.",
                      "Gems: κανένα βήμα δεν θέλει. Αν φανεί κόστος σε gems, σταματάμε και ρωτάμε με το ακριβές ποσό.",
                      "Craft: ο κάτοχος. Ο Claude φοράει και κάνει enchant μετά, με νέο OK.",
                      "Reroll: τύχη· συζήτηση πριν και μετά από κάθε ρίψη.",
                      "Enchant πάνω σε enchant: το παλιό χάνεται (το παιχνίδι δεν βγάζει enchants).",
                      "Τα items που βγαίνουν από ήρωα γυρνάνε στην αποθήκη με τα enchants τους (freed).",
                      "Ένα item παίρνει μόνο enchants της ποιότητάς του ή καλύτερης («Required quality»): το "
                      "διαθέσιμο πλήθος φαίνεται στο παιχνίδι, πριν από κάθε enchant."],
            "phases": [{"id": p, "title": t} for p, t in PHASES],
            "tombBoundTest": dict(test, step=next((s["id"] for s in steps if s["phase"] == "test"), test["step"])),
            "enchantsUsed": used, "enchantsLeft": left, "ownerTasks": owner_tasks(steps, summary), "steps": steps}
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "plan.json"), "w") as f:
        json.dump(plan, f, indent=1, ensure_ascii=False)
        f.write("\n")
    write_md(plan)
    print(f"{len(steps)} βήματα → data/actions/plan.json, PLAN.md")


WHO = {"claude": "Claude", "owner+claude": "εσύ → Claude", "owner": "εσύ"}
STATUS = {"planned": "", "waits-test": "μετά το τεστ", "waits-step": "μετά από", "waits-enchant": "περιμένει enchant",
          "done": "✅", "skipped": "παράλειψη", "failed": "✗"}


def status_label(s):
    if s["status"] == "waits-step":
        return "μετά από " + s["dependsOn"]
    if s["status"] == "waits-enchant":
        return "περιμένει " + ", ".join(s.get("waitsFor") or [])
    return STATUS[s["status"]]


def write_md(plan):
    L = ["# Πλάνο ενεργειών", "",
         "Από το review της " + plan["fromReview"][:16].replace("T", " ") + ". Σειρά: κέρδος ανά κόστος. "
         "Κάθε βήμα θέλει δικό του OK στο chat. Αρχείο: [plan.json](plan.json), αποτελέσματα: [log.json](log.json).", "",
         "Κανόνες: " + " ".join(plan["rules"]), "",
         "«θ.» = η θέση του ήρωα στη λίστα του παιχνιδιού (αλλάζει όταν αλλάζει το power).", ""]
    for pid, title in PHASES:
        steps = [s for s in plan["steps"] if s["phase"] == pid]
        if not steps:
            continue
        L += [f"## {title}", ""]
        if pid != "reroll":
            L += [f"{len(steps)} βήματα, μαζί περίπου +{fmt(sum(s['gain'].get('power') or 0 for s in steps))} power "
                  f"(calc).", ""]
        if pid == "reroll":
            L += ["| # | Ήρωας | Skill | Καλύτερο / χειρότερο | Die | |", "|---|---|---|---|---|---|"]
            for s in steps:
                L.append(f"| {s['id']} | {s['hero']} (θ.{s['gameIndex']}) | {s['skill']} [{s['rating']}] | "
                         f"{round(s['odds']['better'] * 100)}% / {round(s['odds']['worse'] * 100)}% | {s['die']} | "
                         f"{status_label(s)} |")
        else:
            L += ["| # | Ήρωας | Slot | Τι | Ποιος | Κόστος | Αναστρέψιμο | Κέρδος (calc) | |",
                  "|---|---|---|---|---|---|---|---|---|"]
            for s in steps:
                g = s["gain"]
                gain = f"+{fmt(g['power'])} ({g.get('pct')}%)"
                if g.get("withoutTombBound"):
                    gain += f"; χωρίς Tomb-Bound +{fmt(g['withoutTombBound']['gain'])}"
                if g.get("target") is not None and s["status"] not in ("done", "skipped", "failed"):
                    gain += f"; με όλα τα enchants +{fmt(g['target'])}"
                res = (s.get("result") or {}).get("powerGain") or {}
                if res.get("game") is not None:
                    gain += f"; **παιχνίδι {sgn(res['game'])}**"
                L.append(f"| {s['id']} | {s['hero']} (θ.{s['gameIndex']}) | {s['slot'] or '—'} | {short(s)} | "
                         f"{WHO[s['who']]} | {s['cost']} | {s['reversible'].split(':')[0]} | {gain} | "
                         f"{status_label(s)} |")
        L.append("")
    L += ["## Enchants που μένουν στο stock μετά το πλάνο", "",
          ", ".join(f"{e} {n}" for e, n in sorted(plan["enchantsLeft"].items())), ""]
    with open(os.path.join(OUT, "PLAN.md"), "w") as f:
        f.write("\n".join(L))


def short(s):
    if s["kind"] == "promotion":
        return f"Promotion σε {s['to']}"
    if s["kind"] == "seeds":
        return s["text"]
    if s["kind"] == "enchant":
        a = [x for x in s["actions"] if x["do"] == "enchant"]
        return s["before"]["item"] + ": " + ", ".join(
            (x["replaces"] or "κενό") + " → " + x["enchant"] for x in a)
    a = s["after"]
    return (f"{a['item']} T{a['tier']} {a['quality']} αντί {s['before']['item']} {s['before']['quality']} · "
            f"{a['element'] or '—'} · {a['spirit'] or '—'}")


if __name__ == "__main__":
    build("--keep" in sys.argv)
