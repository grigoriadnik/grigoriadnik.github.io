"""Search items (gear, elements, spirits) and optionally build a labelled icon sheet for matching screenshots.

Usage:
  find_item.py "admiral"                              # name search
  find_item.py --type "Heavy Armor" --min-tier 13      # browse a type
  find_item.py --type Spirit --min-tier 12 --sheet /tmp/x.png   # icon sheet (needs the project .venv: Pillow)
  find_item.py --class Lord --slot 1 --min-tier 14     # what fits a class's slot
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c  # noqa: E402

p = argparse.ArgumentParser()
p.add_argument("query", nargs="?", default="")
p.add_argument("--type")
p.add_argument("--class", dest="cls")
p.add_argument("--slot", type=int)
p.add_argument("--min-tier", type=int, default=1)
p.add_argument("--max-tier", type=int, default=16)
p.add_argument("--affinity", help="element (light, fire, ...) or spirit key the item should have affinity for")
p.add_argument("--sort", choices=["tier", "attack", "defense", "hp"], default="tier")
p.add_argument("--limit", type=int, default=40)
p.add_argument("--sheet", help="write a PNG of the matching icons with names here")
a = p.parse_args()

cls = c.fuzzy(a.cls, c.classes(), "class") if a.cls else None
found = []
for it in c.items():
    if a.query and a.query.lower() not in it["name"].lower():
        continue
    if a.type and it["type"].lower() != a.type.lower():
        continue
    if not a.min_tier <= it["tier"] <= a.max_tier:
        continue
    if cls and a.slot and not c.item_fits(cls, a.slot, it):
        continue
    if cls and not a.slot and not any(c.item_fits(cls, s, it) for s in range(1, 7)):
        continue
    if a.affinity:
        aff = c.item_affinity_elements(it) + [(it.get("affinity") or {}).get("spirit")]
        if a.affinity.lower() not in aff:
            continue
    found.append(it)

key = (lambda i: (-i["tier"], i["name"])) if a.sort == "tier" else (lambda i: -i["stats"].get(a.sort, 0))
found.sort(key=key)
found = found[: a.limit]

for it in found:
    aff = it.get("affinity") or {}
    innate = it.get("innate") or {}
    print(f"T{it['tier']:<2} {it['name']} [{it['type']}] {c.fmt_stats(it['stats'])}"
          f" | affinity: {', '.join(c.item_affinity_elements(it)) or '-'} / {aff.get('spirit') or '-'}"
          + (f" | built-in: {innate.get('element') or ''} {innate.get('spirit') or ''}" if innate.get("element") or innate.get("spirit") else "")
          + f" | {it['icon']}")
print(f"{len(found)} shown")

if a.sheet and found:
    from PIL import Image, ImageDraw  # project .venv only

    cell, label_h, cols = 112, 30, 6
    rows = (len(found) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell, rows * (cell + label_h)), "white")
    draw = ImageDraw.Draw(sheet)
    for n, it in enumerate(found):
        x, y = (n % cols) * cell, (n // cols) * (cell + label_h)
        icon = Image.open(c.ROOT / it["icon"]).convert("RGBA")
        icon.thumbnail((cell - 12, cell - 12))
        sheet.paste(icon, (x + (cell - icon.width) // 2, y + 4), icon)
        draw.text((x + 3, y + cell - 4), f"{n + 1}. T{it['tier']}", fill="black")
        draw.text((x + 3, y + cell + 8), it["name"][:19], fill="black")
    sheet.save(a.sheet)
    print(f"sheet: {a.sheet}")
