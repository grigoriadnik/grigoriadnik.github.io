"""Shared loaders and game rules for the hero-review scripts. Data lives in <project>/data (see README.md)."""
import difflib
import json
import re
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
DATA = ROOT / "data"

# Stat multiplier per quality. Epic x2 and Legendary x3 come from st-central's Merchant Academia;
# Superior/Flawless are the commonly quoted values. Enchantment stats are not scaled by quality.
QUALITY = {"Normal": 1.0, "Superior": 1.25, "Flawless": 1.5, "Epic": 2.0, "Legendary": 3.0}

# Highest item tier a hero can equip, by level (copied from the dowob hero form).
_TIER_LEVELS = [0, 3, 6, 9, 12, 16, 19, 22, 25, 27, 29, 32, 34, 36, 38, 40]

# Spirits that give no combat power: shop/gold spirits and XP-only spirits.
NO_COMBAT_SPIRITS = {"Fresh Spirit", "Xolotl Spirit", "Quetzalcoatl Spirit", "Ancestor Spirit",
                     "Owl Spirit", "Kirin Spirit", "Scholar Spirit", "Hippo Spirit"}
# Called "powercrept" by st-central: fine early, always worth replacing on an endgame hero.
WEAK_SPIRITS = {"Wolf Spirit", "Ram Spirit", "Ox Spirit", "Viper Spirit", "Bunny Spirit", "Goose Spirit",
                "Rhino Spirit", "Horse Spirit", "Cat Spirit", "Eagle Spirit", "Armadillo Spirit"}


def _load(name):
    return json.loads((DATA / name).read_text())


@lru_cache(None)
def classes():
    return {c["name"].lower(): c for c in _load("classes.json")}


@lru_cache(None)
def skills():
    return {s["name"].lower(): s for s in _load("skills.json")}


@lru_cache(None)
def items():
    return _load("items.json")


@lru_cache(None)
def items_by_name():
    return {i["name"].lower(): i for i in items()}


@lru_cache(None)
def spirits():
    return {s["name"].lower(): s for s in _load("spirit_effects.json")}


@lru_cache(None)
def element_enchants():
    """Element enchant name -> {elementType, tier, elementAmount, stats, key}."""
    out = {}
    for etype in _load("lookups.json")["elementTypes"]:
        for e in etype["enchantments"]:
            out[e["name"].lower()] = {**e, "elementType": etype["key"]}
    return out


@lru_cache(None)
def element_by_key():
    """Built-in element key as items.json writes it (innate.element, e.g. 'tidal', 't14dark') -> element enchant."""
    return {e["key"]: e for e in element_enchants().values()}


ROSTER_HEROES = DATA / "roster" / "heroes"
GEAR = DATA / "gear"


def hero_file(name_or_path):
    """A hero JSON: a path as given, else data/roster/heroes/<name>.json (read from the phone), else
    data/gear/<name>.json (an older screenshot reading). None when there is neither."""
    p = Path(name_or_path)
    if p.suffix == ".json" and p.exists():
        return p
    for folder in (ROSTER_HEROES, GEAR):
        f = folder / f"{name_or_path}.json"
        if f.exists():
            return f
    return None


@lru_cache(None)
def ratings():
    return _load("skill_ratings.json")


@lru_cache(None)
def heroes():
    return {h["name"].lower(): h for h in _load("heroes.json")}


@lru_cache(None)
def bis_sets():
    return _load("bis_stc.json")["sets"]


def fuzzy(name, table, kind):
    """Look a name up case-insensitively, falling back to the closest match (or exit with suggestions)."""
    if name is None:
        return None
    key = name.strip().lower()
    for candidate in (key, f"{key} spirit", f"{key} element"):
        if candidate in table:
            return table[candidate]
    close = difflib.get_close_matches(key, table.keys(), n=5, cutoff=0.6)
    if len(close) >= 1 and difflib.SequenceMatcher(None, key, close[0]).ratio() > 0.85:
        return table[close[0]]
    raise SystemExit(f"Unknown {kind} '{name}'. Closest: {', '.join(close) or 'none'}")


def max_item_tier(level):
    return max(i + 1 for i, lvl in enumerate(_TIER_LEVELS) if level >= lvl)


def class_element(cls):
    return cls["element"].lower()


def best_element_enchant(cls, tier=14):
    """The class's own element enchant at a tier (Spellblade's 'all' can use any; Light is a fine default)."""
    etype = class_element(cls)
    etype = "light" if etype == "all" else etype
    return next(e for e in element_enchants().values() if e["elementType"] == etype and e["tier"] == tier)


def item_affinity_elements(item):
    aff = (item.get("affinity") or {}).get("element")
    return aff if isinstance(aff, list) else ([aff] if aff else [])


def element_contribution(cls, item, enchant):
    """Element points an enchant gives this hero — the dowob hero form's rule.

    The enchant counts only if it matches the class element (or the class or item accepts all elements);
    a matching item affinity or built-in element adds +10 for enchants above 15 points, else +5.
    """
    affinity = item_affinity_elements(item)
    if not ("all" in affinity or class_element(cls) == "all" or class_element(cls) == enchant["elementType"]):
        return 0
    if "all" in affinity:
        return enchant["elementAmount"] + 5
    innate = (item.get("innate") or {}).get("element")
    matched = innate == enchant["key"] or enchant["elementType"] in affinity
    return enchant["elementAmount"] + ((10 if enchant["elementAmount"] > 15 else 5) if matched else 0)


def reached_tier(tiers, element, promoted):
    return [t for t in tiers if element >= t["elementThreshold"] and (promoted or not t["requiresPromotion"])][-1]


def slot_types(cls, slot):
    return cls["equipmentSlots"].get(f"slot{slot}", [])


def item_fits(cls, slot, item):
    allowed = set(slot_types(cls, slot))
    if item["type"] in allowed:
        return True
    type_names = {t["key"]: t["name"] for t in _load("lookups.json")["itemTypes"]}
    return any(type_names.get(s) in allowed for s in item.get("subTypes") or [])


def rating_page(cls, skill_set="Default"):
    return ratings().get(skill_set, ratings()["Default"]).get(cls["ratingPage"]) or ratings()["Default"][cls["ratingPage"]]


def sets_for_class(cls):
    """STC best-in-slot sets for this class: exact class heading first, then its base/promotion pair."""
    names = {cls["name"], cls["baseClass"], cls.get("promotesTo") or ""}
    exact = [s for s in bis_sets() if s["heading"] == cls["name"]]
    pair = [s for s in bis_sets() if " / " in s["heading"] and set(s["heading"].split(" / ")) & names]
    return exact or pair


@lru_cache(None)
def item_sources():
    return _load("item_sources.json")


def item_source(name):
    """Short label for how the owner can get an item: research blueprint, pack, chest, Antique Store."""
    s = item_sources().get(name)
    if not s:
        return "source unknown"
    parts = []
    if s["antiqueTokens"]:
        parts.append(f"Antique Store {s['antiqueTokens']} tokens")
    unlock = s["unlock"]
    if not unlock:
        parts.append("regular blueprint" if s["researchScrolls"] else "no blueprint info")
    elif "Chest" in unlock:
        parts.append(f"chest: {unlock}")
    else:
        parts.append(f"pack/event: {unlock}")
    return ", ".join(parts)


def stc_spirit_guidance(cls):
    """Spirits STC's notes name for this class (Titan aside), and the item the Titan should go on."""
    notes = " ".join(n for s in sets_for_class(cls) for n in s["notes"])
    names = []
    for word in re.findall(r"[A-Za-z']+", notes):
        spirit = spirits().get(f"{word.lower()} spirit")
        if spirit and spirit["name"] not in names and spirit["name"] not in ("Titan Spirit",):
            names.append(spirit["name"])
    titan = re.search(r"Enchant the ([\w ]+?) with titan", notes, re.I)
    return names, (titan.group(1).lower() if titan else None)


def fmt_stats(stats, mult=1.0):
    return ", ".join(f"{k} {round(v * mult):,}" for k, v in stats.items()) or "-"
