"""Print everything the data knows about a hero or class: skills, element targets, slots, BiS sets.

Usage: hero_context.py "Hero 6"   or   hero_context.py Ninja
A hero read from the phone (data/roster/heroes/) wins over the older dowob record (data/heroes.json).
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c  # noqa: E402

query = " ".join(sys.argv[1:])
roster_file = c.ROSTER_HEROES / f"{query}.json"
roster = json.loads(roster_file.read_text()) if roster_file.exists() else None
hero = c.heroes().get(query.lower())
cls = c.fuzzy(roster["class"] if roster else hero["heroClass"]["name"] if hero else query, c.classes(), "hero or class")
promoted = cls["isPromoted"]
promo = c.classes().get((cls["promotesTo"] or "").lower())

print(f"# {cls['name']} ({cls['type']}, element {cls['element']}) — {'promoted' if promoted else 'NOT promoted → ' + cls['promotesTo']}")
print(f"skill slots unlock at levels {cls['skillUnlockLevels']}" + (f"; after promotion {promo['skillUnlockLevels']}" if promo else ""))
for label, k in (("innate now", cls), ("innate after promotion", promo)):
    if k:
        print(f"{label}: " + " → ".join(f"T{t['tier']} {t['name']} @{t['elementThreshold']}{'+promo' if t['requiresPromotion'] else ''}" for t in k["innate"]["tiers"]))
print("item slots: " + " | ".join(f"{s[-1]}: {', '.join(t)}" for s, t in cls["equipmentSlots"].items()))
print(f"element enchant to use: {c.best_element_enchant(cls)['name']} (T14, 35) — T12 {c.best_element_enchant(cls, 12)['name']} (25)")

if roster:
    element = roster.get("elementShown") or 0
    st = roster.get("stats") or {}
    print(f"\n## Read from the phone {roster.get('capturedAt')}: {roster['hero']} — level {roster.get('level')}, element {element}")
    print("stats: " + ", ".join(f"{k} {v:,}" if isinstance(v, int) else f"{k} {v}" for k, v in st.items() if v is not None))
    page = c.rating_page(cls)
    need = 0
    for t in roster.get("skillTiers") or []:
        info = c.skills().get(t["skill"].lower())
        if t.get("innate") or not info:
            continue
        top = info["tiers"][-1] if promoted else [x for x in info["tiers"] if not x["requiresPromotion"]][-1]
        need = max(need, top["elementThreshold"])
        print(f"- {t['skill']} [{page.get(t['skill'], '?')}] T{t['tier']} {t['name']}"
              + ("" if t["tier"] >= top["tier"] else f"  (max here T{top['tier']} @{top['elementThreshold']})"))
    innate_top = cls["innate"]["tiers"][-1] if promoted else [t for t in cls["innate"]["tiers"] if not t["requiresPromotion"]][-1]
    need = max(need, innate_top["elementThreshold"])
    print(f"innate: {roster.get('innate')}; element needed for every skill + innate at max tier: {need} "
          f"({'OK' if element >= need else 'SHORT by ' + str(need - element)})")
    for sl in roster.get("slots") or []:
        print(f"  slot {sl.get('slot')}: T{sl.get('tier')} {sl.get('item')} {sl.get('quality')} · {sl.get('element')} · {sl.get('spirit')}")
    print(f"full review with calc's numbers: .venv/bin/python -m review \"{roster['hero']}\"")

if hero and not roster:
    element = hero["element"]
    print(f"\n## Site record (may be older than the screenshot): {hero['name']} — level {hero['level']}, element {element}")
    if hero["attack"] > 1:
        print(f"stats: ATK {hero['attack']:,} DEF {hero['defense']:,} HP {hero['hp']:,} EVA {hero['evasion']}% "
              f"crit {hero['critChance']}% x{hero['critDamage']} threat {hero['threat']} seeds {hero['hpSeeds']}/{hero['attackSeeds']}/{hero['defenseSeeds']}")
    else:
        print("stats: not entered on the site")
    need = need_promoted = 0
    for s in hero["skills"]:
        info = c.skills()[s["name"].lower()]
        now = c.reached_tier(info["tiers"], element, promoted)
        top = info["tiers"][-1] if promoted else [t for t in info["tiers"] if not t["requiresPromotion"]][-1]
        need = max(need, top["elementThreshold"])
        need_promoted = max(need_promoted, info["tiers"][-1]["elementThreshold"])
        print(f"- {s['name']} [{s['rating']}] now T{now['tier']} {now['name']}: {now['description']}"
              + ("" if now == top else f"  (max here T{top['tier']} @{top['elementThreshold']})")
              + ("" if promoted else f"  (T4 {info['tiers'][-1]['name']} @{info['tiers'][-1]['elementThreshold']} after promotion: {info['tiers'][-1]['description']})"))
    innate_top = cls["innate"]["tiers"][-1] if promoted else [t for t in cls["innate"]["tiers"] if not t["requiresPromotion"]][-1]
    need = max(need, innate_top["elementThreshold"])
    print(f"element needed for every skill + innate at max tier: {need} (site record has {element}, {'OK' if element >= need else 'SHORT by ' + str(need - element)})")
    if promo:
        need_promoted = max(need_promoted, promo["innate"]["tiers"][-1]["elementThreshold"])
        print(f"after promotion to {promo['name']} it needs {need_promoted} ({'OK' if element >= need_promoted else 'SHORT by ' + str(need_promoted - element)})")

page = c.rating_page(cls)
by_letter = {}
for name, letter in page.items():
    by_letter.setdefault(letter, []).append(name)
print("\n## Skill ratings for " + cls["ratingPage"])
for letter in ("S+", "S", "A", "B", "C", "D"):
    if letter in by_letter:
        print(f"{letter}: {', '.join(by_letter[letter])}")

print("\n## STC best-in-slot (endgame target, mostly Antique Store items)")
for s in c.sets_for_class(cls):
    print(f"### {s['heading']}")
    for n in s["notes"]:
        print(f"  note: {n}")
    for slot in s["slots"]:
        print(f"  - T{slot['tier']} {slot['name']} ({', '.join(f'{k} {v}' for k, v in slot['stats'].items())})"
              f" affinity [{', '.join(slot['affinity']) or '-'}] → {slot['element'] or '-'}"
              + (f" + {slot['spirit']}" if slot["spirit"] else "")
              + (f"  [antique from {slot['antiqueStoreFrom']}]" if slot["antiqueStoreFrom"] else ""))
