"""Check a hero's gear and rank what to change (quick rule-based check; the full review with calc's numbers is
`.venv/bin/python -m review "<hero>"`, see review/README.md).

Usage: evaluate.py "Hero 6"      # data/roster/heroes/Hero 6.json (read from the phone), else data/gear/
       evaluate.py hero.json       # any file in the format below (e.g. a screenshot reading)

hero.json (only "class" or a known "hero", and "slots", are required):
{
  "hero": "Hero 1", "class": "Praetorian", "level": 40,
  "skills": ["Death Dealer", "..."],          # any tier's names; defaults to the site's record
  "role": "dps" | "tank" | "evasion",         # optional; guessed from the skills otherwise
  "stats": {"attack": 37726, "defense": 23600, "hp": 1077, "evasion": 68, "critChance": 32, "critDamage": 6.5},
  "elementShown": 250,                         # element value the game shows; used for skill tiers when given
  "slots": [{"slot": 1, "item": "Titan Admiral Arms", "quality": "Epic",
             "element": "Apotheosis Element", "spirit": "Titan Spirit"},
            {"item": "Ancient Statuette", ...},          # no "slot": placed by item type
            {"slot": 6, "unknown": true}]                 # could not read it: skipped, not reported as empty
}
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c  # noqa: E402

ROLE_SPIRITS = {
    "dps": ["Leviathan Spirit", "Behemoth Spirit", "Chimera Spirit", "Kraken Spirit", "Bear Spirit"],
    "tank": ["Ouroboros Spirit", "Tarrasque Spirit", "Mammoth Spirit", "Hydra Spirit"],
    "evasion": ["Griffin Spirit", "Ouroboros Spirit", "Carbuncle Spirit", "Lion Spirit"],
}
MAIN_STAT = {"dps": "attack", "tank": "defense", "evasion": "defense"}
LEGENDARY_SHARE = 0.15  # flag Legendary when it adds at least this share of the hero's main gear stat

source = c.hero_file(" ".join(sys.argv[1:]))
if source is None:
    raise SystemExit(f"no hero file for '{' '.join(sys.argv[1:])}' in data/roster/heroes/ or data/gear/, and no such .json")
spec = json.loads(source.read_text())
known = c.heroes().get((spec.get("hero") or "").lower())
cls = c.fuzzy(spec.get("class") or (known and known["heroClass"]["name"]), c.classes(), "class")
promoted = cls["isPromoted"]
level = spec.get("level") or (known and known["level"]) or 40
top_tier = c.max_item_tier(level)
type_names = {t["key"]: t["name"] for t in c._load("lookups.json")["itemTypes"]}
issues, notes = [], []  # issues: (priority, slot or None, text)


def add(priority, slot, text):
    issues.append((priority, slot, text))


def skill_info(name):
    """Accept a T1 name or any tier's name."""
    for s in c.skills().values():
        if any(t["name"].lower() == name.lower() for t in s["tiers"]):
            return s
    return c.fuzzy(name, c.skills(), "skill")


skill_names = spec.get("skills") or [s["name"] for s in (known or {}).get("skills", [])]
hero_skills = [skill_info(n) for n in skill_names]
innate = {"name": cls["innate"]["name"], **c.skills()[cls["innate"]["name"].lower()]}


def guess_role():
    """Sum the skills' T4 percentages per role; crit and evasion points are worth more than raw %."""
    score = {"dps": 0.0, "tank": 0.0, "evasion": 0.0}
    weight = {"Attack": ("dps", 1), "Critical Hit Chance": ("dps", 3), "Critical Hit Damage": ("dps", 1 / 3),
              "Defense": ("tank", 1), "Health": ("tank", 1), "Evasion": ("evasion", 5)}
    for s in hero_skills:
        for pct, stat in re.findall(r"\+(\d+)% (?:bonus )?(Attack|Critical Hit Chance|Critical Hit Damage|Defense|Health|Evasion)",
                                    s["tiers"][-1]["description"] or ""):
            role_name, w = weight[stat]
            score[role_name] += int(pct) * w
    return max(score, key=lambda k: (score[k], k == "dps"))


role = spec.get("role") or guess_role()
main = MAIN_STAT[role]
stc_spirits, titan_target = c.stc_spirit_guidance(cls)
default_spirit = stc_spirits[0] if stc_spirits else ROLE_SPIRITS[role][0]
good_spirits = set(stc_spirits) | set(ROLE_SPIRITS[role])


def item_types(item):
    return {item["type"]} | {type_names.get(t) for t in item.get("subTypes") or []}


# ---- Place every entry in a slot: keep the given slot when the item fits, otherwise move it by item type.
entries = []
for s in spec["slots"]:
    e = dict(s)
    e["item_data"] = c.fuzzy(s["item"], c.items_by_name(), "item") if s.get("item") else None
    entries.append(e)
taken = {e["slot"] for e in entries if e.get("slot") and (e.get("unknown") or not e["item_data"]
                                                           or c.item_fits(cls, e["slot"], e["item_data"]))}
for e in entries:
    item = e["item_data"]
    if not item or e.get("unknown") or (e.get("slot") and c.item_fits(cls, e["slot"], item)):
        continue
    free = [n for n in range(1, 7) if n not in taken and c.item_fits(cls, n, item)]
    if free:
        if e.get("slot"):
            notes.append(f"{item['name']} does not fit slot {e['slot']}; placed in slot {free[0]} ({', '.join(c.slot_types(cls, free[0]))})")
        e["slot"] = free[0]
        taken.add(free[0])
    else:
        e["slot"] = None  # an extra item with no slot left for it: reported, but kept out of the slot list
for n in range(1, 7):
    if n not in taken and not any(e.get("slot") == n for e in entries):
        add(50, n, f"nothing listed for slot {n} ({', '.join(c.slot_types(cls, n))}) — empty, or not read from the screenshot?")

# ---- Pass 1: read every slot (fit, element, spirit).
rows, element_total, titans, unknown_slots = [], 0, [], []
for s in sorted(entries, key=lambda e: e["slot"] or 99):
    slot, item = s["slot"], s["item_data"]
    if s.get("unknown"):
        unknown_slots.append(slot)
        continue
    if not item:
        add(100, slot, f"slot {slot} is empty — equip a T{top_tier} {' / '.join(c.slot_types(cls, slot))}")
        continue
    quality = (s.get("quality") or "Epic").title()
    row = {"slot": slot, "item": item, "quality": quality, "mult": c.QUALITY[quality], "types": item_types(item),
           "gap": top_tier - item["tier"], "fits": c.item_fits(cls, slot, item)}
    if slot is None:
        row["fits"] = False
        add(100, None, f"{item['name']} ({item['type']}) has no free slot on a {cls['name']} — two items read for one slot? recheck the screenshot")
    elif not row["fits"]:
        add(100, slot, f"{item['name']} ({item['type']}) does not fit slot {slot} ({', '.join(c.slot_types(cls, slot))})")

    affinity = c.item_affinity_elements(item)
    built_in = (item.get("innate") or {}).get("element")
    enchant = c.element_by_key().get(built_in) if built_in else None  # innate.element is a key ('tidal'), not a name
    if s.get("element"):
        enchant = c.fuzzy(s["element"], c.element_enchants(), "element enchant")
    if enchant:
        points = c.element_contribution(cls, item, enchant)
        element_total += points
        row["element"] = f"{enchant['name']} (T{enchant['tier']}) → +{points} element"
        if points == 0:
            add(60, slot, f"{enchant['name']} is {enchant['elementType']}, so it adds no element to a {cls['element']} hero — use {c.best_element_enchant(cls)['name']}")
        elif enchant["tier"] < 14:
            add(15, slot, f"element is T{enchant['tier']} {enchant['name']}; {c.best_element_enchant(cls)['name']} (T14) gives more stats and element")
    else:
        row["element"] = "none"
        add(70, slot, f"no element enchant — add {c.best_element_enchant(cls)['name']}")
    if affinity:
        row["element"] += f" [item affinity: {', '.join(affinity)}]"

    spirit_aff = (item.get("affinity") or {}).get("spirit")
    if s.get("spirit"):
        spirit = c.fuzzy(s["spirit"], c.spirits(), "spirit")
        boosted = spirit_aff == spirit["uid"]
        row["spirit"] = f"{spirit['name']} (T{spirit['tier']}): {spirit['effectWithAffinity'] if boosted else spirit['effect']}" + (" [affinity +]" if boosted else "")
        if spirit["name"] in c.NO_COMBAT_SPIRITS:
            add(65, slot, f"{spirit['name']} gives no combat power ({spirit['effect']}) — replace with {default_spirit}")
        elif spirit["name"] in c.WEAK_SPIRITS:
            add(30, slot, f"{spirit['name']} is outdated ({spirit['effect']}) — {default_spirit} is much stronger")
        elif spirit["name"] == "Titan Spirit":
            titans.append(slot)
        elif spirit["tier"] < 12:
            add(20, slot, f"{spirit['name']} is T{spirit['tier']}; a T14 spirit ({default_spirit}) adds more stats and a stronger effect")
        elif spirit["name"] not in good_spirits and not boosted:
            add(18, slot, f"{spirit['name']} ({spirit['effect']}) is not what STC/the role table suggests here — {default_spirit}")
    else:
        row["spirit"] = "none"
        add(70, slot, f"no spirit — add {default_spirit}")
    aff_spirit = next((x for x in c.spirits().values() if x["uid"] == spirit_aff), None) if spirit_aff else None
    if aff_spirit:
        row["spirit"] += f" [item likes {aff_spirit['name']}: {aff_spirit['effectWithAffinity']}]"
    rows.append(row)

if titans and not promoted:
    add(60, titans[0], "Titan Spirit does nothing until the hero is promoted")
if len(titans) > 1:
    add(55, titans[1], f"{len(titans)} Titan spirits: only the largest counts — move the extra to {default_spirit}")
if promoted and not titans:
    titan_items = [r for r in rows if (r["item"].get("affinity") or {}).get("spirit") == "titan"]
    where = (f"slot {titan_items[0]['slot']} ({titan_items[0]['item']['name']} has Titan affinity → +20% HP/MS)" if titan_items
             else f"the {titan_target} (STC note)" if titan_target else "one item")
    add(35, None, f"no Titan Spirit: a promoted hero gets +15% HP/Mana Shield from one — put it on {where}")
if not promoted:
    add(95, None, f"Promote to {cls['promotesTo']}: unlocks T4 skills/innate (and more slots for some classes) — bigger than any gear change")

# ---- Element: the game's own number decides the skill tiers; the gear sum only cross-checks the reading.
shown = spec.get("elementShown")
element = shown if shown is not None else element_total
need, tier_notes, active = 0, [], []
for s in hero_skills + [innate]:
    top = s["tiers"][-1] if promoted else [t for t in s["tiers"] if not t["requiresPromotion"]][-1]
    need = max(need, top["elementThreshold"])
    now = c.reached_tier(s["tiers"], element, promoted)
    tier_notes.append(f"{s['name']} T{now['tier']}/{top['tier']}")
    active.append((s["name"], now.get("description") or next(t["description"] for t in s["tiers"] if t["tier"] == now["tier"])))
if shown is not None and abs(shown - element_total) > 5 and not unknown_slots:
    add(85, None, f"reading check: the gear adds up to element {element_total} but the game shows {shown} — an enchant or item was probably misread; recheck before trusting the element advice")
if element < need:
    add(75, None, f"element {element} < {need}: some skills are not at max tier — put {c.best_element_enchant(cls)['name']} on more items (affinity items give +10)")

# ---- Skill bonuses tied to item types decide which slots matter most.
# Each rule is (skill, sentence, item types, stats, bonus); it applies once per item even when a Dual Wield matches two types.
rules, to_attack, weight_notes = [], set(), []


def type_list(text):
    out = []
    for name in re.split(r",\s*|\s+and\s+", text.strip(" .")):
        name = name.strip()
        out.append(name if name in type_names.values() else name.rstrip("s"))
    return out


for name, desc in active:
    for sentence in re.split(r"(?<=\.)\s+", desc or ""):
        m = re.match(r"\+(\d+)% (Attack|Defense) with (.+)", sentence)
        if m:
            rules.append((name, sentence, set(type_list(m.group(3))), {m.group(2).lower()}, int(m.group(1)) / 100))
            continue
        m = re.match(r"\+(\d+)% (?:bonus from all items with|with) (.+)", sentence)
        if m:
            rules.append((name, sentence, set(type_list(m.group(2))), {"attack", "defense", "hp"}, int(m.group(1)) / 100))
            continue
        m = re.match(r"Equipped (\w[\w ]*)'s DEF is added to ATK", sentence)
        if m:
            to_attack.add(m.group(1))
            weight_notes.append(f"{name}: {sentence}")
weight_notes = [f"{r[0]}: {r[1]}" for r in rules] + weight_notes


def effective(item, mult):
    """Item stats x quality x the hero's item-type skill bonuses (enchants and flat % skills left out)."""
    types = item_types(item)
    out = {}
    for stat, value in item["stats"].items():
        bonus = sum(pct for _, _, rule_types, stats, pct in rules if stat in stats and types & rule_types)
        out[stat] = value * mult * (1 + bonus)
    if types & to_attack:
        out["attack"] = out.get("attack", 0) + out.get("defense", 0)
    return out


def alternatives(slot, current, n=3):
    """Best Epic items for this slot and hero by main stat (then defense), from the top two tiers."""
    pool = [i for i in c.items() if i["tier"] >= top_tier - 1 and i["name"] != current["name"]
            and i["type"] not in ("Element", "Spirit") and c.item_fits(cls, slot, i)]
    score = lambda i: (round(effective(i, 2.0).get(main, 0)), round(effective(i, 2.0).get("defense", 0)))
    return sorted(pool, key=score, reverse=True)[:n]


totals = {}
for r in rows:
    r["eff"] = effective(r["item"], r["mult"])
    r["gain"] = {k: round(v - r["eff"].get(k, 0)) for k, v in effective(r["item"], 3.0).items()} if r["quality"] != "Legendary" else {}
    r["alts"] = alternatives(r["slot"], r["item"]) if r["fits"] else []
    if r["slot"] is None:
        continue  # an extra item is not worn, so it does not count toward the gear totals
    for k, v in r["eff"].items():
        totals[k] = totals.get(k, 0) + v
main_total = totals.get(main, 0) or 1

for r in rows:
    if r["slot"] is None:
        continue
    it, share = r["item"], r["eff"].get(main, 0) / main_total
    # An item outside every skill bonus that applies to its slot, when a boosted type would be far stronger.
    slot_rules = [x for x in rules if x[2] & set(c.slot_types(cls, r["slot"]))]
    best = r["alts"][0] if r["alts"] else None
    if slot_rules and not any(r["types"] & x[2] for x in slot_rules) and best \
            and item_types(best) & set().union(*(x[2] for x in slot_rules)) \
            and effective(best, 2.0).get(main, 0) >= 1.3 * effective(it, 2.0).get(main, 0):
        r["mismatch"] = True
        boosted = ", ".join(sorted(set().union(*(x[2] for x in slot_rules)) & set(c.slot_types(cls, r["slot"]))))
        add(92, r["slot"], f"{it['name']} is a {it['type']}, so it gets none of {slot_rules[0][0]}'s bonus ({slot_rules[0][1].rstrip('.')}) — "
                           f"use one of {boosted} instead — {best['name']} would give {round(effective(best, 2.0).get(main, 0)):,} {main} vs {round(effective(it, 2.0).get(main, 0)):,}")
    if r["gap"] >= 2 and not r.get("mismatch"):
        # Lower tiers hurt most where the slot carries the hero's main stat.
        add(70 + 5 * r["gap"] + round(20 * share), r["slot"],
            f"{it['name']} is T{it['tier']}, {r['gap']} tiers under T{top_tier} (slot = {share:.0%} of gear {main})")
    elif r["gap"] == 1 and not r.get("mismatch"):
        # Many T15 Antique Store items beat crafted T16s, so this is only a prompt to compare.
        add(10, r["slot"], f"{it['name']} is T{it['tier']}: check the alternatives listed for this slot")
    if r["gain"] and not r.get("mismatch") and r["fits"]:
        g = r["gain"].get(main, 0) / main_total
        if g >= LEGENDARY_SHARE:
            add(25, r["slot"], f"Legendary {it['name']} adds +{r['gain'].get(main, 0):,} {main} (+{g:.0%} of gear {main}) — worth it if you can fuse one")

# ---- Report.
print(f"source: {source.relative_to(c.ROOT) if source.is_relative_to(c.ROOT) else source}"
      + (f" ({spec.get('source')}, {spec.get('capturedAt')})" if spec.get("capturedAt") else ""))
print(f"# {spec.get('hero') or cls['name']}: {cls['name']} ({cls['type']}, element {cls['element']}), level {level}, "
      f"{'promoted' if promoted else 'NOT promoted'}, role {role}{'' if spec.get('role') else ' (guessed from skills — set role to override)'}")
print(f"max item tier at this level: T{top_tier}; element enchant to use: {c.best_element_enchant(cls)['name']}")
print(f"spirits: STC note for this class → {', '.join(stc_spirits) or 'none'}"
      + (f", Titan on the {titan_target}" if titan_target else "") + f"; role table ({role}) → {', '.join(ROLE_SPIRITS[role][:3])}")
print(f"element: game shows {shown if shown is not None else '?'}, gear adds up to {element_total}"
      + (f" (slots not read: {unknown_slots})" if unknown_slots else "")
      + f"; needed for max tiers: {need} → {'OK, surplus ' + str(element - need) if element >= need else 'SHORT by ' + str(need - element)}")
print("skill tiers: " + "; ".join(tier_notes))
if weight_notes:
    print("item-type skill bonuses (these make some slots worth more): " + " | ".join(weight_notes))
for n in notes:
    print(f"note: {n}")

print("\n## Slots (stats = base x quality x item-type skill bonuses)")
for r in rows:
    it = r["item"]
    print(f"{'slot ' + str(r['slot']) if r['slot'] else 'extra (no slot)'}: T{it['tier']} {it['name']} [{it['type']}] {r['quality']} → {c.fmt_stats(r['eff'])}"
          f" ({r['eff'].get(main, 0) / main_total:.0%} of gear {main}) — {c.item_source(it['name'])}")
    print(f"   element: {r['element']}")
    print(f"   spirit:  {r['spirit']}")
    if r["gain"]:
        print(f"   Legendary would add {c.fmt_stats(r['gain'])} = +{r['gain'].get(main, 0) / main_total:.0%} gear {main}")
    for n, a in enumerate(r["alts"]):
        eff = effective(a, 2.0)
        extra = f"; as Legendary +{round(eff.get(main, 0) / 2):,} {main}" if n == 0 else ""
        aff = "/".join(c.item_affinity_elements(a))
        print(f"   option {n + 1}: T{a['tier']} {a['name']} [{a['type']}] Epic {c.fmt_stats(eff)}"
              f"{' · affinity ' + aff if aff else ''}{' · likes ' + a['affinity']['spirit'] if (a.get('affinity') or {}).get('spirit') else ''}"
              f" — {c.item_source(a['name'])}{extra}")
for n in unknown_slots:
    print(f"slot {n}: not read from the screenshot")
print("gear totals: " + c.fmt_stats(totals))

print("\n## Priorities (highest first)")
for pri, slot, text in sorted(issues, key=lambda x: -x[0]):
    print(f"[{pri:>3}] {'slot ' + str(slot) if slot else 'hero  '}: {text}")
if not issues:
    print("nothing obvious — only Legendary/starforge/transcendence upgrades are left")
review_file = c.DATA / "reviews" / f"{spec.get('hero')}.json"
if spec.get("hero") and review_file.exists():
    print(f"\nfull review (calc's numbers, sources, what to craft/buy, one owner per item): "
          f".venv/bin/python -m review \"{spec['hero']}\"")
