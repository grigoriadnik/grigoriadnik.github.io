"""Rebuild calc/data/base_stats.json: every class's base HP/ATK/DEF for levels 1-50 and its fixed stats.

Sources (both public Google Sheets, read through the gviz CSV endpoint like scripts/fetch_official.py):
- Ress' Hero & Quest Simulator, sheet "Hero Stats": HP/ATK/DEF per class and level 1-50.
- Kabam's official Data Spreadsheet, sheet "Heroes": level-1 HP/ATK/DEF (cross-check), EVA, crit chance,
  crit damage and threat per class.

Usage: .venv/bin/python -I calc/build_data.py
"""
import csv
import io
import json
import re
import urllib.parse
import urllib.request
from pathlib import Path

OUT = Path(__file__).resolve().parent / "data" / "base_stats.json"
RESS = "1LM8yySoXgyxute3xv5qKqBOt86Xcr41LEDncdrPp4EA"
OFFICIAL = "1WLa7X8h3O0-aGKxeAlCL7bnN8-FhGd3t7pz2RCzSg8c"
MAX_LEVEL = 50


def sheet(doc, name):
    url = f"https://docs.google.com/spreadsheets/d/{doc}/gviz/tq?tqx=out:csv&sheet={urllib.parse.quote(name)}"
    raw = urllib.request.urlopen(url, timeout=60).read().decode("utf-8")
    return list(csv.reader(io.StringIO(raw)))


def number(text):
    m = re.match(r"\s*([\d.]+)", text.replace(",", ""))
    return float(m.group(1)) if m else None


def ress_levels():
    """{class: {"hp": [L1..L50], "attack": [...], "defense": [...]}} from the HP / ATK / DEF blocks."""
    out, stat = {}, None
    for row in sheet(RESS, "Hero Stats"):
        head = row[0].strip()
        if head in ("HP", "ATK", "DEF"):
            stat = {"HP": "hp", "ATK": "attack", "DEF": "defense"}[head]
            continue
        values = [number(v) for v in row[1:MAX_LEVEL + 1]]
        if stat and head and all(v is not None for v in values):
            out.setdefault(head, {})[stat] = [int(v) for v in values]
    return out


def official_classes():
    """{class: {...}} from the three class columns of the official Heroes sheet (each block is 5 rows)."""
    rows = sheet(OFFICIAL, "Heroes")
    out = {}
    for off in (1, 9, 17):
        for i, r in enumerate(rows):
            if len(r) > off + 6 and r[off + 4] == "HP":
                name = r[off].split("\n")[0].strip().title()
                cell = lambda dr, dc: rows[i + dr][off + dc]
                out[name] = {
                    "hp1": number(cell(0, 5)), "attack1": number(cell(1, 5)), "defense1": number(cell(2, 5)),
                    "evasion": number(cell(3, 5)), "critChance": number(cell(1, 3)),
                    "critDamage": number(cell(2, 3)), "threat": number(cell(3, 3)),
                    "notes": {k: v for k, v in (("evasion", cell(3, 5)), ("critChance", cell(1, 3))) if "(" in v},
                }
    return out


def main():
    levels, official = ress_levels(), official_classes()
    classes, problems = {}, []
    for name, fixed in sorted(official.items()):
        lv = levels.get(name)
        if not lv or set(lv) != {"hp", "attack", "defense"}:
            problems.append(f"{name}: missing from Ress' Hero Stats")
            continue
        for stat in ("hp", "attack", "defense"):
            if lv[stat][0] != fixed[f"{stat}1"]:
                problems.append(f"{name} {stat} L1: Ress {lv[stat][0]} vs official {fixed[stat + '1']}")
        classes[name] = {
            **lv,
            "evasion": fixed["evasion"], "critChance": fixed["critChance"],
            "critDamage": fixed["critDamage"], "threat": fixed["threat"],
            **({"officialNotes": fixed["notes"]} if fixed["notes"] else {}),
        }
    data = {
        "_about": "Base stats per hero class. hp/attack/defense are lists for levels 1..50 (index 0 = level 1). "
                  "evasion and critChance are percentage points, critDamage the crit multiplier, threat the "
                  "class threat rating. officialNotes keeps the official sheet's conditional innate text.",
        "_sources": {
            "levels": f"Ress' Hero & Quest Simulator, sheet 'Hero Stats' (docs.google.com/spreadsheets/d/{RESS}); "
                      "it imports Ress' 'Hero Data New' sheet",
            "fixed": f"Kabam's official Data Spreadsheet, sheet 'Heroes' (docs.google.com/spreadsheets/d/{OFFICIAL}); "
                     "its level-1 HP/ATK/DEF match Ress' level 1 for every class (checked by this script)",
        },
        "classes": classes,
    }
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text(json.dumps(data, indent=1))
    print(f"{len(classes)} classes written to {OUT}")
    if problems:
        raise SystemExit("problems:\n" + "\n".join(problems))


if __name__ == "__main__":
    main()
