"""Computed vs shown, per stat and per item, for every hero the roster session read from the phone.

Usage: .venv/bin/python calc/validate.py [folder]     (default: data/roster/heroes, then data/roster/champions)

Prints one table per hero or champion (with the seed counts inferred where the roster has none; for a champion also
the Titan Soul and the power factor), every item whose computed stats differ from its own popup (roster
slots[].shown / items[].shown), and a summary of the stats that do not match, so a formula step can be fixed and
this rerun. A unit with slots that were not read is listed but left out of the summary.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:  # also runs as a plain script: .venv/bin/python calc/validate.py
    sys.path.insert(0, str(ROOT))
from calc import compute  # noqa: E402
from calc.engine import SHORT, STAT_KEYS  # noqa: E402

# Rounding: ATK sums six items rounded half a point each before x (1 + ATK%), so a few points (at most 0.04%);
# power keeps decimals the shown stats do not (at most 0.05%). Everything else must match within 1 or exactly.
TOLERANCE = {"attack": (2, 0.0004), "defense": (2, 0), "hp": (1, 0), "power": (2, 0.0005)}
# Champions: each power-up adds a fractional reward (rank 10's / 6), so a few points; above level 40 (Titan Soul)
# the level table is Ress' estimate, at most 0.15% off on the owner's champions. Power is the hero formula times the
# factor measured on the shown power (README § Champions), so it only follows the stats.
TOLERANCE_CHAMPION = {"attack": (3, 0.0015), "defense": (3, 0.0015), "hp": (3, 0.0015), "power": (2, 0.001)}
ITEM_STATS = ("attack", "defense", "hp", "evasion", "critChance")


def tolerance(stat, shown, champion=False):
    flat, rel = (TOLERANCE_CHAMPION if champion else TOLERANCE).get(stat, (0, 0))
    return max(flat, rel * abs(shown or 0))


def item_misses(hero, result):
    """[(slot, item, stat, computed, shown)] for every item whose popup differs from the computed stat by more than 1."""
    out = []
    raw = {s.get("slot"): s for s in hero.get("slots") or hero.get("items") or []}
    for s in result["slots"]:
        shown = (raw.get(s["slot"]) or {}).get("shown")
        if not s.get("item") or not shown:
            continue
        for k in ITEM_STATS:
            c, w = s.get(k) or 0, shown.get(k) or 0
            if abs(c - w) > 1:
                out.append((s["slot"], s["item"], k, c, w))
    return out


def validate(folder):
    files = sorted(Path(folder).glob("*.json"))
    if not files:
        print(f"No heroes or champions in {folder} yet — the roster session fills it from the phone. Nothing to check.")
        return 0
    misses, items_off, items_checked, checked = {}, [], 0, 0
    for f in files:
        hero = json.loads(f.read_text())
        try:
            r = compute(hero)
        except ValueError as e:
            print(f"\n# {f.name}: cannot compute — {e}")
            continue
        partial = any(s.get("unknown") for s in r["slots"])
        champ = r.get("kind") == "champion"
        plus = f" +{r['rankPlus']}" if champ and r["rankPlus"] else ""
        title = (f"{r['champion']} (L{r['level']}, rank {r['rank']}{plus}, Titan Soul {'yes' if r['titanSoul'] else 'no'})"
                 if champ else f"{r['hero']} ({r['class']} L{r['level']})")
        print(f"\n# {title}{'  — slots not read, totals short' if partial else ''}")
        if champ:
            print(f"  power = hero formula x {r['extra']['powerFactor']} (factor measured on the shown power)")
        if r.get("seedsInferred"):
            print("  seeds inferred: " + ", ".join(f"{SHORT[k]} {r['seedsUsed'][k]}" for k in r["seedsInferred"]))
        print(f"  {'stat':<12}{'computed':>12}{'shown':>12}{'diff':>10}")
        for k in STAT_KEYS:
            c = r["check"].get(k)
            if not c:
                continue
            bad = abs(c["diff"]) > tolerance(k, c["shown"], champ)
            print(f"  {SHORT[k]:<12}{c['computed']:>12}{c['shown']:>12}{c['diff']:>10}{'  <--' if bad else ''}")
            if bad and not partial:
                misses.setdefault(k, []).append(f"{r.get('hero') or r.get('champion')} ({c['diff']:+})")
        off = item_misses(hero, r)
        items_checked += sum(1 for s in hero.get("slots") or hero.get("items") or [] if s.get("shown"))
        for slot, item, k, c, w in off:
            print(f"  item slot {slot} {item}: {SHORT[k]} computed {c}, popup {w} ({w - c:+})")
            items_off.append(f"{r.get('hero') or r.get('champion')} slot {slot} {item} {SHORT[k]} ({w - c:+})")
        checked += not partial
    print(f"\n{checked} fully read {'champions' if Path(folder).name == 'champions' else 'heroes'} checked, "
          f"{items_checked} item popups.")
    for k, who in misses.items():
        print(f"  {SHORT[k]} off for {len(who)}: {', '.join(who)}")
    if items_off:
        print(f"  item popups off: {len(items_off)}: {'; '.join(items_off)}")
    if not misses and not items_off:
        print("  every stat and every item within rounding.")
    return 1 if misses or items_off else 0


if __name__ == "__main__":
    if len(sys.argv) > 1:
        sys.exit(validate(sys.argv[1]))
    heroes = validate(ROOT / "data" / "roster" / "heroes")
    champions = validate(ROOT / "data" / "roster" / "champions")
    sys.exit(heroes or champions)
