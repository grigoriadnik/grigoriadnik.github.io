"""Rebuild calc/data/champions.json: each champion's base stats per level, rank rewards, element per rank and
leader skill per tier.

Sources (public Google Sheets, read as CSV through the export endpoint, which keeps every cell as typed):
- Kabam's official Data Spreadsheet, tab "Champions": level-1 HP/ATK/DEF, crit chance, crit damage, threat, EVA,
  element, class type, each rank's reward ("+7 Health, +31 Attack, +43 Defense" or "Leader Skill Upgraded: ..."),
  the "11 (+X)" power-up reward and the element breakpoints per rank.
- the same spreadsheet, tab "Skills": every leader skill tier's text.
- Ress' Hero & Quest Simulator V9.8.1, tab "Champion 1": HP/ATK/DEF per champion for levels 1-50 (level 1 and 40 from
  the game, 2-39 and 41-49 interpolated, 50 Ress' own estimate) and the exact power-up reward (rank 10's reward / 6;
  the official text rounds it down).

Usage: .venv/bin/python -I calc/build_champions.py
"""
import csv
import io
import json
import re
import urllib.request
from pathlib import Path

OUT = Path(__file__).resolve().parent / "data" / "champions.json"
OFFICIAL = "1WLa7X8h3O0-aGKxeAlCL7bnN8-FhGd3t7pz2RCzSg8c"
RESS = "1LM8yySoXgyxute3xv5qKqBOt86Xcr41LEDncdrPp4EA"
GID = {"champions": 256894468, "skills": 1214352620, "ress": 1440090012}
STATS = {"Health": "hp", "Attack": "attack", "Defense": "defense"}


def sheet(doc, gid):
    url = f"https://docs.google.com/spreadsheets/d/{doc}/export?format=csv&gid={gid}"
    return list(csv.reader(io.StringIO(urllib.request.urlopen(url, timeout=60).read().decode("utf-8"))))


def number(text):
    m = re.match(r"\s*([\d.]+)", (text or "").replace(",", ""))
    return float(m.group(1)) if m else None


def reward(text):
    """'+7 Health, +31 Attack, +43 Defense' -> {"hp": 7, "attack": 31, "defense": 43}; a leader upgrade -> {}."""
    return {STATS[w]: float(n) for n, w in re.findall(r"\+([\d.]+) (Health|Attack|Defense)", text)}


def official():
    """{name: {...}} from the Champions tab: one block per champion, its name in capitals at column B."""
    rows = sheet(OFFICIAL, GID["champions"])
    out, breakpoints = {}, []
    for i, r in enumerate(rows):
        if len(r) > 6 and r[3] == "Prerequisite" and r[1].isupper() and r[1].strip():
            cell = lambda dr, dc: rows[i + dr][dc] if i + dr < len(rows) and dc < len(rows[i + dr]) else ""
            c = {"name": r[1].title(), "element": cell(1, 2), "classType": cell(3, 2), "unlock": cell(2, 2),
                 "prerequisite": r[4], "hp1": number(cell(0, 6)), "attack1": number(cell(1, 6)),
                 "defense1": number(cell(2, 6)), "evasion": number(cell(3, 6)), "critChance": number(cell(1, 4)),
                 "critDamage": number(cell(2, 4)), "threat": number(cell(3, 4)), "ranks": {}, "powerUp": None,
                 "leaderAt": {}}
            j = i + 5
            while j < len(rows) and rows[j][1].strip():
                rank, text = rows[j][1].strip(), rows[j][3]
                if "(+X)" in rank:
                    c["powerUp"] = reward(text)
                    c["powerUpRank"] = int(rank.split()[0])
                    m = re.match(r"\s*(\d+)\s*\+\s*\((\d+)\s*\*\s*X\)", rows[j][2])
                    c["powerUpCoins"] = {"base": int(m.group(1)), "perPowerUp": int(m.group(2)), "text": rows[j][2].strip()} if m else None
                else:
                    c["ranks"][rank] = reward(text)
                    c.setdefault("coins", {})[rank] = number(rows[j][2])
                    m = re.match(r"Leader Skill Upgraded: (.+)", text)
                    if m:
                        c["leaderAt"][rank] = m.group(1).strip()
                if rows[j][8].strip().isdigit() and rows[j][9].strip().isdigit():
                    breakpoints.append([int(rows[j][8]), int(rows[j][9])])
                j += 1
            out[c["name"]] = c
    return out, breakpoints


def leader_skills():
    """{champion: [{"tier", "name", "text"}]} from the Skills tab (type "Leader")."""
    out = {}
    for r in sheet(OFFICIAL, GID["skills"]):
        if len(r) > 6 and r[1] == "Leader":
            out.setdefault(r[6].strip(), []).append({"tier": int(r[2]), "name": r[0].strip(), "text": r[5].strip()})
    for v in out.values():
        v.sort(key=lambda t: t["tier"])
    return out


def ress():
    """Levels 1-50 per champion and the exact power-up reward, from Ress' 'Champion 1' tab."""
    rows = sheet(RESS, GID["ress"])
    names = set()
    levels = {}
    for i, r in enumerate(rows[:-2]):
        # A champion's level rows: its name in column A, the L40-L1 gap in B, then levels 1..50 in C..AZ (HP, ATK, DEF).
        if r[0].strip() and number(r[1]) is not None and all(number(x) is not None for x in r[2:52]) \
                and not rows[i + 1][0].strip() and not rows[i + 2][0].strip():
            levels[r[0].strip()] = {st: [number(x) for x in rows[i + k][2:52]]
                                    for k, st in enumerate(("hp", "attack", "defense"))}
            names.add(r[0].strip())
    power_up = {}
    for i, r in enumerate(rows):
        # The per-rank reward tables: a header row naming the champions from column AE, then ranks 1..11, 11+1...
        if len(r) > 41 and r[30].strip() == "Argon" and r[41].strip() == "Yami":
            stat = {0: "hp", 1: "attack", 2: "defense"}[len(power_up)]
            plus = next(rows[k] for k in range(i + 1, i + 20) if rows[k][29].strip() == "11+1")
            power_up[stat] = {r[30 + n].strip(): number(plus[30 + n]) for n in range(12)}
    return levels, {name: {st: power_up[st][name] for st in power_up} for name in power_up["hp"]}


def main():
    champs, breakpoints = official()
    leaders = leader_skills()
    levels, power_up = ress()
    problems = []
    for name, c in champs.items():
        lv = levels.get(name)
        if not lv:
            problems.append(f"{name}: no level table in Ress' Champion 1")
            continue
        c["levels"] = lv
        for st in ("hp", "attack", "defense"):
            if lv[st][0] != c[f"{st}1"]:
                problems.append(f"{name} {st} L1: Ress {lv[st][0]} vs official {c[st + '1']}")
        if c["powerUp"] is not None and name in power_up:
            last = c["ranks"][str(c["powerUpRank"] - 1)]
            exact = {st: last.get(st, 0) / 6 for st in ("hp", "attack", "defense")}
            for st, v in exact.items():
                if abs(v - power_up[name][st]) > 1e-6 or int(v) != c["powerUp"].get(st):
                    problems.append(f"{name} power-up {st}: rank {c['powerUpRank'] - 1} / 6 = {v:g}, Ress "
                                    f"{power_up[name][st]}, official text {c['powerUp'].get(st)}")
            c["powerUpExact"] = exact
        c["leader"] = leaders.get(name, [])
        if not c["leader"]:
            problems.append(f"{name}: no leader skill in the Skills tab")
    data = {
        "_about": "Champion base stats and rank rewards. levels: HP/ATK/DEF for levels 1..50 (index 0 = level 1). "
                  "ranks: the reward of each rank (cumulative = sum up to the rank); powerUpExact: what each power-up "
                  "past the last rank adds (that rank's reward / 6; the official text 'powerUp' rounds it down). "
                  "elementBreakpoints: [rank, element] where rank counts on past the last one (12 = 11+1). coins: champion coins "
                  "to reach each rank; powerUpCoins: base + perPowerUp x X for the next power-up, X = power-ups done. "
                  "leader: the leader skill per tier, the tier reached at the ranks in leaderAt.",
        "_sources": {
            "official": f"Kabam's official Data Spreadsheet (docs.google.com/spreadsheets/d/{OFFICIAL}), tabs "
                        "'Champions' and 'Skills'",
            "levels": f"Ress' Hero & Quest Simulator V9.8.1 (docs.google.com/spreadsheets/d/{RESS}), tab 'Champion 1': "
                      "level 1 and 40 are the game's (level 1 = the official sheet for every champion), 2-39 and 41-49 "
                      "interpolated, 50 Ress' estimate. The owner's champions at level 40-50 fit within a few points "
                      "(calc/README.md § Champions)",
            "titanSoul": "Ress 'Champion 1'!B18:B20: with a Titan Soul the rank counts two power-ups more and its "
                         "rewards x1.5; the owner's six champions with one fit it (calc/README.md § Champions)",
        },
        "titanSoul": {"extraPowerUps": 2, "rankMultiplier": 1.5},
        "elementBreakpoints": breakpoints,
        "champions": champs,
    }
    OUT.write_text(json.dumps(data, indent=1, ensure_ascii=False))
    print(f"{len(champs)} champions written to {OUT}: {', '.join(champs)}")
    if problems:
        raise SystemExit("problems:\n" + "\n".join(problems))


if __name__ == "__main__":
    main()
