"""Game data the calculator reads: the project's data/*.json through the hero-review skill's helpers
(scripts/common.py: quality multipliers, item/spirit/element tables, element rule), plus calc/data/*.json."""
import difflib
import importlib.util
import json
import math
import re
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CALC_DATA = Path(__file__).resolve().parent / "data"


def _hero_review_common():
    path = ROOT / ".claude" / "skills" / "hero-review" / "scripts" / "common.py"
    spec = importlib.util.spec_from_file_location("hero_review_common", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


hr = _hero_review_common()


class Unknown(LookupError):
    """A name that is not in the game data (misread, or a new item the data does not have yet)."""


@lru_cache(None)
def calc_data(name):
    return json.loads((CALC_DATA / name).read_text())


def rules():
    return calc_data("rules.json")


def base_stats(cls_name):
    return calc_data("base_stats.json")["classes"].get(cls_name)


def lookup(name, table, kind):
    """Case-insensitive lookup with a 'Spirit'/'Element' suffix and a close-match fallback (ratio > 0.85)."""
    key = name.strip().lower()
    for candidate in (key, f"{key} spirit", f"{key} element"):
        if candidate in table:
            return table[candidate]
    close = difflib.get_close_matches(key, table.keys(), n=3, cutoff=0.6)
    if close and difflib.SequenceMatcher(None, key, close[0]).ratio() > 0.85:
        return table[close[0]]
    raise Unknown(f"unknown {kind} '{name}'" + (f" (closest: {', '.join(close)})" if close else ""))


def find_class(name):
    return lookup(name, hr.classes(), "class")


def find_item(name):
    return lookup(name, hr.items_by_name(), "item")


def find_spirit(name):
    return lookup(name, hr.spirits(), "spirit")


def find_element(name):
    return lookup(name, hr.element_enchants(), "element enchant")


@lru_cache(None)
def _skills_by_name():
    """Non-innate skills by any tier's name; a T1 name wins over another skill's tier name."""
    out = {}
    skills = [s for s in hr._load("skills.json") if not s.get("isInnate")]
    for s in skills:
        for t in s["tiers"][1:]:
            out.setdefault(t["name"].lower(), s)
    for s in skills:
        out[s["name"].lower()] = s
    return out


def find_skill(name):
    return lookup(name, _skills_by_name(), "skill")


@lru_cache(None)
def element_by_key():
    """Built-in element key (data/items.json innate.element) -> element enchant."""
    return {e["key"]: e for e in hr.element_enchants().values()}


@lru_cache(None)
def spirit_by_uid():
    return {s["uid"]: s for s in hr.spirits().values()}


@lru_cache(None)
def type_names():
    """Item type key ('wd') -> name ('Dagger')."""
    return {t["key"]: t["name"] for t in hr._load("lookups.json")["itemTypes"]}


@lru_cache(None)
def _official_skills():
    """Item uid -> its own skill key (a_* artifacts, q_* quivers), from calc/data/official_items.json."""
    path = CALC_DATA / "official_items.json"
    if not path.exists():
        return {}
    return {uid: it["skill"] for uid, it in json.loads(path.read_text())["items"].items()
            if (it.get("skill") or "")[:2] in ("a_", "q_")}


def item_skill(item):
    return _official_skills().get(item["uid"])


@lru_cache(None)
def _official_by_name():
    path = CALC_DATA / "official_items.json"
    return {it["name"]: it for it in json.loads(path.read_text())["items"].values()} if path.exists() else {}


@lru_cache(None)
def blueprint_boosts(path=None):
    """Item name -> the base-stat multiplier of the owner's blueprint, from the Item Collection popup numbers that
    the roster session keeps in data/roster/blueprints.json ('status': the popup's OCR text, which holds the
    blueprint's stats and gold value in any order, e.g. "888 +5% 30,950,000 ..." or "21,750,000 1,340 ...").
    A blueprint that reached its starforge milestone "baseStats*1.25" shows its base stats x1.25 (Stone Jaguar
    Greaves: 888 = round(710 x 1.25)), plus a built-in element's or spirit's stats as always. The item's main stat
    is looked for among the numbers before the description; a blueprint is listed when it shows plain (1.0) or
    boosted (the factor of the item's own starforge milestone)."""
    path = Path(path) if path else ROOT / "data" / "roster" / "blueprints.json"
    if not path.exists():
        return {}
    official, out = _official_by_name(), {}
    for entries in json.loads(path.read_text()).get("byType", {}).values():
        for e in entries:
            o, item = official.get(e["item"]), hr.items_by_name().get(e["item"].lower())
            stats = {k: item["stats"][k] for k in ("attack", "defense", "hp") if item and item["stats"].get(k)}
            if not (o and stats and (e.get("status") or isinstance(e.get("stats"), dict))):
                continue
            if isinstance(e.get("stats"), dict):  # the popup's numbers as roster parsed them, if it does
                nums = [v for v in e["stats"].values() if isinstance(v, (int, float))]
            else:
                head = []
                for tok in e["status"].split():
                    if len(re.findall(r"[A-Za-z]", tok)) >= 3:  # the description starts
                        break
                    head.append(tok)
                nums = [int(x.replace(",", "")) for x in re.findall(r"\d[\d,]*", " ".join(head))]
                nums = [x for x in nums if x < 100000]  # larger: the blueprint's gold value
            k = max(stats, key=stats.get)
            extra = 0
            built_in = element_by_key().get((item.get("innate") or {}).get("element"))
            if built_in:
                extra += _round({x["type"]: x["value"] for x in built_in["stats"]}.get(k, 0) * 1.5)
            spirit = spirit_by_uid().get((item.get("innate") or {}).get("spirit"))
            if spirit:
                extra += _round(spirit["stats"].get(k, 0) * 1.5)
            factor = next((float(s.split("*")[1]) for s in o.get("starforge") or [] if s.startswith("baseStats*")), None)
            for f in (1.0, factor):
                want = _round(stats[k] * f) + _round(min(extra, stats[k]) * f)
                if f and any(abs(x - want) <= 1 for x in nums):
                    out[e["item"]] = f
                    break
    return out


def _round(x):
    return math.floor(x + 0.5 + 1e-9)


@lru_cache(None)
def weapon_types():
    """Item type names in the 'Weapon' group (Sword, Bow, Wand, ...)."""
    return frozenset(t["name"] for t in hr._load("lookups.json")["itemTypes"] if t.get("group") == "Weapon")


def item_types(item):
    return {item["type"]} | {type_names().get(t) for t in item.get("subTypes") or []} - {None}


@lru_cache(None)
def dowob_heroes():
    return hr.heroes()
