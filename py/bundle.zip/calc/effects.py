"""Turn the game's effect texts (skills, class innates, spirits) into numbers.

The texts are the game's own, as dowob and the official Data Spreadsheet give them (data/skills.json,
data/classes.json, data/spirit_effects.json). Each clause becomes one effect dict with a "kind":

  pct        +X% Attack/Defense/Health          -> {"stat", "value"}  (hero-wide % bonus)
  flat       +X Attack/Defense/Health           -> {"stat", "value"}  (added before the % bonus)
  add        +X% Evasion / Crit Chance / Crit Damage, +X Threat, +X HP regen -> {"stat", "value"}
  gear       +X% bonus stats from all equipment -> {"value"}
  typed      +X% Attack with T / Defense with T / bonus from all items with T -> {"stats", "types", "value"}
  shield_to_atk, innate_element_items, threat_to_atk, atk_per_element, item_stats, eva_cap
  set        "Critical Hit Chance is set to X% and cannot change" (artifacts) -> {"stat", "value"}
  no_weapons "Equipped weapons grant no bonuses" (Torc of Peace)
  until_damaged  +X% Evasion / Crit Chance until damaged: the hero's Info screen counts it -> {"stat", "value"}
  conditional  only in some rounds or situations, not on the hero screen -> {"text", "tag", "value"}
  xp_to_atk  "+X% XP → Attack" (Thinkin' Cap's Central Thinking) -> {"value"}: X% of the hero's XP % becomes ATK %
  other      no stat effect (XP, rest time, break chance, mana shield, ...); "+X% XP" also carries {"stat": "xp",
             "value"}, for Central Thinking
  unknown    a clause this parser does not know: the caller warns instead of dropping it silently
"""
import re

N = r"(\d+(?:\.\d+)?)"
STAT_WORD = {"Attack": "attack", "Defense": "defense", "Health": "hp"}

# Checked in this order; the first match wins.
_RULES = [
    (rf"^\+{N}% Attack on the first round$", "conditional", "first_round_atk"),
    (rf"^\+{N}% Attack when enemy's HP is below 50%$", "conditional", "low_hp_enemy_atk"),
    (rf"^\+{N}% Evasion until damaged$", "until_damaged", "evasion"),
    (rf"^\+{N}% Critical Hit Chance until damaged$", "until_damaged", "critChance"),
    (rf"^(Critical Hit Chance|Evasion) is set to {N}% and cannot change$", "set", None),
    (r"^Equipped weapons grant no bonuses$", "no_weapons", None),
    (r"begins combat at|deals 2x damage against", "conditional", None),
    (r"until damaged|when HP falls|against bosses|after dodging|first attack|on the first round|"
     r"Effect is doubled|Regain bonuses|consecutive critical|Stacks \d+ times|Guaranteed evasion|"
     r"ignores Elemental Barriers|Skill effect is doubled", "conditional", None),
    (rf"^\+{N}% (Attack|Defense|Health)$", "pct", None),
    (rf"^\+{N} (Attack|Defense|Health)$", "flat", None),
    (rf"^\+{N}% Evasion$", "add", "evasion"),
    (rf"^\+{N}% Critical Hit Chance$", "add", "critChance"),
    (rf"^\+{N}% Critical Hit Damage$", "add", "critDamage"),
    (rf"^\+{N} Threat(?: Rating)?$", "add", "threat"),
    (rf"^\+{N} HP Regen per turn$|^Heal {N} HP each turn$", "add", "regen"),
    (rf"^\+{N}% bonus stats from all equipment$", "gear", None),
    (rf"^\+{N}% (Attack|Defense) with (.+)$", "typed", None),
    (rf"^\+{N}% (?:bonus from all items )?with (.+)$", "typed_all", None),
    (r"^Equipped Shield's DEF is added to ATK$", "shield_to_atk", None),
    (rf"^\+{N}% extra bonus from equipment with innate elements$", "innate_element_items", None),
    (rf"^{N}% of total Threat is added as an attack multiplier$", "threat_to_atk", None),
    (rf"^{N}% Attack per point in any Element$", "atk_per_element", None),
    (rf"^{N}% bonus to enchanted item's stats$", "item_stats", None),
    (rf"^\+{N}% to max Evasion$", "eva_cap", None),
    (rf"^\+{N}% XP → Attack$", "xp_to_atk", None),
    (rf"^\+{N}% XP$", "other", "xp"),
    (r"Mana Shield|XP$|Resting Time|Break Chance|Polonia|items stolen|fatal blow|Lethal attack|"
     r"Elemental Barriers|Learns skills faster|Champion skills|Energy cost|second attempt|"
     r"learn (?:a very )?powerful|Guarantees a Critical Hit|Instantly defeats|cannot break|collection value|"
     r"Collection Score|Dragon Invasion|Airship Power|from Champions|Lost City of Gold", "other", None),
]


def clauses(text):
    """Split a description into clauses: sentences first, then comma lists of separate bonuses
    ("+8% Attack, +3% Critical Hit Chance"), but not comma lists of item types ("with Dagger, Bow").
    Artifact texts also join whole sentences with commas ("..., Equipped weapons grant no bonuses")."""
    out = []
    for sentence in re.split(r"\.(?:\s+|$)", (text or "").strip()):
        out.extend(c.strip() for c in re.split(r",\s+(?=[+-]|Heal |\d|Skill |Critical Hit Chance is|Evasion is|"
                                               r"Equipped |User |Nullify |Wearer)", sentence) if c.strip())
    return out


def type_names(text, known):
    """'Dagger, Bow, Crossbow, Instrument' / 'Spells' -> {'Dagger', ...} / {'Spell'}."""
    out = set()
    for name in re.split(r",\s*|\s+and\s+", text.strip(" .")):
        name = name.strip()
        out.add(name if name in known or not name.endswith("s") else name[:-1])
    return out


def parse_clause(clause, known_types=()):
    for pattern, kind, extra in _RULES:
        m = re.search(pattern, clause)
        if not m:
            continue
        nums = [g for g in m.groups() if g and re.fullmatch(N, g)]
        value = float(nums[0]) if nums else None
        if kind == "conditional":
            return {"kind": kind, "tag": extra, "value": value if extra else None, "text": clause}
        if kind in ("pct", "flat"):
            return {"kind": kind, "stat": STAT_WORD[m.group(2)], "value": value}
        if kind == "add":
            return {"kind": kind, "stat": extra, "value": value}
        if kind == "until_damaged":
            return {"kind": kind, "stat": extra, "value": value, "text": clause}
        if kind == "set":
            return {"kind": kind, "stat": {"Critical Hit Chance": "critChance", "Evasion": "evasion"}[m.group(1)],
                    "value": value, "text": clause}
        if kind == "typed":
            return {"kind": "typed", "stats": (STAT_WORD[m.group(2)],),
                    "types": type_names(m.group(3), known_types), "value": value, "text": clause}
        if kind == "typed_all":
            return {"kind": "typed", "stats": ("attack", "defense", "hp"),
                    "types": type_names(m.group(2), known_types), "value": value, "text": clause}
        if kind == "other":
            return dict({"kind": kind, "text": clause}, **({"stat": extra, "value": value} if extra else {}))
        return {"kind": kind, "value": value, "text": clause}
    return {"kind": "unknown", "text": clause}


def parse(text, known_types=()):
    return [parse_clause(c, known_types) for c in clauses(text)]
