"""Print a hero's or champion's stats step by step and compare them with what the game showed.

Usage: .venv/bin/python -m calc "Hero 6" [--json] [--catalyst-is-staff]
       .venv/bin/python -m calc "Argon"            (or "Argon and Arnold")
       .venv/bin/python -m calc path/to/hero.json

A hero is read from data/roster/heroes/<name>.json, else from data/heroes.json (dowob: stats but no gear); a
champion from data/roster/champions/<name>.json (its full name or first name).
"""
import argparse
import json
import sys
from pathlib import Path

from . import compute
from .engine import SHORT, STAT_KEYS
from .gamedata import ROOT, dowob_heroes

ORDER = ("attack", "defense", "hp", "evasion", "critChance", "critDamage", "threat", "regen", "element", "power")


def load_hero(name):
    path = Path(name)
    if path.suffix == ".json" and path.exists():
        return json.loads(path.read_text()), str(path)
    roster = ROOT / "data" / "roster" / "heroes"
    for f in sorted(roster.glob("*.json")):
        data = json.loads(f.read_text())
        if name.lower() in (f.stem.lower(), str(data.get("hero", "")).lower()):
            return data, str(f.relative_to(ROOT))
    for f in sorted((ROOT / "data" / "roster" / "champions").glob("*.json")):
        if name.lower() in (f.stem.lower(), f.stem.split()[0].lower()):
            return json.loads(f.read_text()), str(f.relative_to(ROOT))
    known = dowob_heroes().get(name.lower())
    if known:
        return known, "data/heroes.json (dowob: no gear)"
    raise SystemExit(f"No hero '{name}' in data/roster/heroes/ or data/heroes.json")


def fmt(v):
    if isinstance(v, float) and not v.is_integer():
        return f"{v:,.2f}".rstrip("0").rstrip(".")
    return f"{int(v):,}"


def print_report(r, source):
    if r.get("kind") == "champion":
        plus = f" +{r['rankPlus']}" if r["rankPlus"] else ""
        print(f"# {r['champion']} — level {r['level']}, rank {r['rank']}{plus}, "
              f"Titan Soul {'yes' if r['titanSoul'] else 'no'}, card {r['cardLevel']}  ({source})")
        print(f"element: {r['elementComputed']} ({r['elementFromRank']} from the rank)")
        if r["leader"]:
            print(f"leader skill: {r['leader']['name']} T{r['leader']['tier']} ({r['leader']['text']})")
        if r["nextPowerUp"]:
            print("next power-up adds: " + ", ".join(f"{SHORT[k]} +{v}" for k, v in r["nextPowerUp"].items()))
    else:
        print(f"# {r['hero']} — {r['class']} level {r['level']}, {'promoted' if r['promoted'] else 'not promoted'}  ({source})")
        print(f"element for skill tiers: {r['elementUsed']} (gear adds up to {r['elementComputed']})")
        print("skills: " + "; ".join(f"{s['name']} T{s['tier']} ({s['description']})" for s in r["skills"]))
        print(f"innate: {r['innate']['name']} T{r['innate']['tier']} ({r['innate']['description']})")
    for stat in ORDER:
        steps = [s for s in r["steps"] if s["stat"] == stat]
        if not steps:
            continue
        print(f"\n## {SHORT[stat]}")
        group = None
        for s in steps:
            if s["group"] != group:
                group = s["group"]
                print(f"  [{group}]")
            print(f"    {s['op']:>2} {fmt(s['value']):>10}  {s['label']}  → {fmt(s['total'])}")
    print("\n## Computed vs shown in the game")
    print(f"  {'stat':<12}{'computed':>12}{'shown':>12}{'diff':>10}")
    for k in STAT_KEYS:
        c = r["check"].get(k)
        shown = fmt(c["shown"]) if c else "—"
        diff = fmt(c["diff"]) if c else ""
        print(f"  {SHORT[k]:<12}{fmt(r['stats'][k]):>12}{shown:>12}{diff:>10}")
    if r["warnings"]:
        print("\n## Warnings (not confirmed, or missing input)")
        for w in r["warnings"]:
            print(f"  - {w}")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m calc", description=__doc__.split("\n")[0])
    ap.add_argument("hero", help="hero name (e.g. 'Hero 6') or a hero JSON file")
    ap.add_argument("--json", action="store_true", help="print the full result as JSON")
    ap.add_argument("--catalyst-is-staff", action="store_true", help="give the Mage/Archmage innate to Catalysts (Ress)")
    args = ap.parse_args(argv)
    hero, source = load_hero(args.hero)
    r = compute(hero, {"catalystIsStaff": True} if args.catalyst_is_staff else None)
    if args.json:
        json.dump(r, sys.stdout, indent=1, ensure_ascii=False)
        print()
    else:
        print_report(r, source)


if __name__ == "__main__":
    main()
