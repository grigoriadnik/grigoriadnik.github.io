"""Fetch the game's own item data from the official site playshoptitans.com/blueprints into
calc/data/official_items.json, compare it with data/items.json (dowob), and add the items dowob lacks.

Each blueprint list page (/blueprints/<category>/<type>) embeds the game's fields for every item of that type in
<script id="__NEXT_DATA__"> (props.pageProps.items): stats, affinities, built-in element/spirit, the item's own
skill (artifacts, quivers), crafting / starforge / ascension / transcendence upgrades, release date. About 50
pages, fetched one at a time with a pause between them. No login. (scripts/fetch_official.py is another script:
it reads Kabam's official Google Sheet.)

Usage:
    .venv/bin/python -I calc/fetch_site.py             # fetch, write calc/data/official_items.json, compare
    .venv/bin/python -I calc/fetch_site.py --compare   # compare the saved file with data/items.json only
    .venv/bin/python -I calc/fetch_site.py --add-new   # also append the items data/items.json lacks (in its own
                                                       # format, existing entries untouched) and their icons
"""
import io
import json
import re
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "calc" / "data" / "official_items.json"
ITEMS = ROOT / "data" / "items.json"
SITE = "https://playshoptitans.com"
START = ["/blueprints/weapons/ws", "/blueprints/armor/ah", "/blueprints/accessories/xq", "/blueprints/stones/xu",
         "/blueprints/enchantments/fire"]
PAUSE = 1.5  # seconds between requests
AGENT = "shopTitans-calc/1.0 (personal stats calculator)"
KEEP = ("type", "subtype", "multiType", "tier", "atk", "def", "hp", "eva", "crit", "shieldHp", "elementAffinity",
        "spiritAffinity", "lTag2", "lTag3", "skill", "excl", "chest", "releaseAt", "isTitanItem", "nonCraftable")
NUMBERS = ("atk", "def", "hp", "eva", "crit", "shieldHp", "tier")
ICON_SIZE = (64, 64)  # the size of the dowob icons already in assets/items, which icon matching uses


def get(path):
    req = urllib.request.Request(path if path.startswith("http") else SITE + path, headers={"User-Agent": AGENT})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read()


def page_data(path):
    html = get(path).decode("utf-8")
    m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.S)
    if not m:
        raise ValueError(f"{path}: no __NEXT_DATA__")
    return html, json.loads(m.group(1))


def number(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return v
    return int(f) if f.is_integer() else f


def item_record(it, texts):
    rec = {"name": texts.get(f"{it['uid']}_name", it["uid"])}
    for k in KEEP:
        if it.get(k) not in (None, "", 0, "0") or k in ("atk", "def", "hp"):
            rec[k] = number(it.get(k)) if k in NUMBERS else it.get(k)
    if it.get("skill"):
        rec["skillName"] = texts.get(f"skill_{it['skill']}_name")
    rec["crafting"] = [it.get(f"upgrade{n}") for n in range(1, 6) if it.get(f"upgrade{n}")]
    rec["starforge"] = [it.get(f"upgradeShiny{n}") for n in range(1, 6) if it.get(f"upgradeShiny{n}")]
    su = [it.get(f"supgrade{n}") for n in range(1, 7)]
    rec["ascension"], rec["transcendence"] = [s for s in su[:3] if s], [s for s in su[3:] if s]
    return rec


def crawl():
    seen, queue, items, build = set(), list(START), {}, None
    while queue:
        path = queue.pop(0)
        if path in seen:
            continue
        seen.add(path)
        html, data = page_data(path)
        build = build or data.get("buildId")
        pp = data["props"]["pageProps"]
        texts = pp.get("texts") or {}
        for it in pp.get("items") or []:
            items[it["uid"]] = item_record(it, texts)
        for link in re.findall(r'href="(/blueprints/[a-z]+/[a-z0-9]+)"', html):
            if link not in seen and not link.startswith("/blueprints/featured"):
                queue.append(link)
        print(f"{path}: {len(pp.get('items') or [])} items", flush=True)
        time.sleep(PAUSE)
    return {"_about": "The game's own item data from the official site (calc/fetch_site.py). Fields as the game "
                      "names them: atk/def/hp, eva/crit as fractions, shieldHp, elementAffinity/spiritAffinity, "
                      "lTag2/lTag3 (built-in element/spirit), multiType (a Dual Wield's second type), skill (the "
                      "item's own skill key: a_* artifacts, q_* quivers, i_* a spirit's), crafting / starforge / "
                      "ascension / transcendence upgrades.",
            "source": SITE + "/blueprints", "fetchedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "buildId": build, "pages": len(seen), "items": items}


def as_dowob(uid, o, type_names):
    """An official record in data/items.json's own format (as scripts/build_data.py writes it)."""
    stats = {}
    for k, dk, scale in (("atk", "attack", 1), ("def", "defense", 1), ("hp", "hp", 1), ("eva", "evasion", 100),
                         ("crit", "critical_chance", 100), ("shieldHp", "mana_shield", 1)):
        if o.get(k):
            stats[dk] = number(round(o[k] * scale, 6))
    aff = (o.get("elementAffinity") or "").split(",") if o.get("elementAffinity") else []
    boost = next((s.split("*")[1] for s in o.get("starforge") or [] if s.startswith("baseStats*")), None)
    return {
        "uid": uid, "name": o["name"], "tier": o["tier"], "type": type_names.get(o["type"], o["type"]),
        "subTypes": o["multiType"].split(",") if o.get("multiType") else None,
        "stats": stats,
        "affinity": {"element": aff[0] if len(aff) == 1 else (aff or None), "spirit": o.get("spiritAffinity")},
        "innate": {"element": o.get("lTag2"), "spirit": o.get("lTag3")},
        "starforgeStatBoost": f"{float(boost):.4f}" if boost else None,
        "transcendence": o.get("transcendence") or None,
        "icon": f"assets/items/{uid}.png",
    }


def type_names():
    return {t["key"]: t["name"] for t in json.loads((ROOT / "data" / "lookups.json").read_text())["itemTypes"]}


def compare(official):
    """How data/items.json differs from the game: every field that as_dowob() writes, except the icon."""
    dowob = {i["uid"]: i for i in json.loads(ITEMS.read_text())}
    names = type_names()
    diffs, missing = [], []
    for uid, o in sorted(official["items"].items()):
        if o.get("type") == "z":  # enchantments (elements, spirits): data/lookups.json, not items.json
            continue
        d = dowob.get(uid)
        if not d:
            missing.append(uid)
            continue
        mine = as_dowob(uid, o, names)
        for k in mine:
            if k != "icon" and mine[k] != d.get(k):
                diffs.append(f"{o['name']}: {k} dowob {d.get(k)!r}, game {mine[k]!r}")
    skills = {}
    for o in official["items"].values():
        if (o.get("skill") or "")[:2] in ("a_", "q_"):
            skills.setdefault(o["skill"], []).append(o["name"])
    print(f"\n{len(official['items'])} items on the site, {len(dowob)} in data/items.json.")
    print(f"Fields that differ ({len(diffs)}):" + "".join(f"\n  {x}" for x in diffs))
    print(f"Missing from data/items.json ({len(missing)}):" + "".join(
        f"\n  {official['items'][u]['name']} (T{official['items'][u].get('tier')} {official['items'][u]['type']}, "
        f"{official['items'][u].get('releaseAt') or 'no release date'})" for u in missing))
    print("Item skills:" + "".join(f"\n  {k} ({len(v)}): {', '.join(sorted(v)[:6])}{' …' if len(v) > 6 else ''}"
                                   for k, v in sorted(skills.items())))
    return missing


def fetch_icon(uid):
    """assets/items/<uid>.png from the site's 256 px icon, scaled to the 64 px RGBA of the dowob icons."""
    from PIL import Image
    path = ROOT / "assets" / "items" / f"{uid}.png"
    if path.exists():
        return True
    try:
        data = get(f"/assets/items/{uid}.png")
    except OSError as e:
        print(f"  no icon for {uid}: {e}")
        return False
    Image.open(io.BytesIO(data)).convert("RGBA").resize(ICON_SIZE, Image.LANCZOS).save(path)
    time.sleep(PAUSE)
    return True


def add_new(official, missing):
    """Append the missing items to data/items.json in its format; existing entries stay byte for byte."""
    names = type_names()
    text = ITEMS.read_text(encoding="utf-8")
    body = text.rstrip()
    if not body.endswith("]"):
        raise ValueError("data/items.json does not end with ']'")
    new = []
    for uid in missing:
        entry = as_dowob(uid, official["items"][uid], names)
        if not fetch_icon(uid):
            entry["icon"] = f"assets/item-types/{entry['type'].lower().replace(' ', '')}.png"
        new.append("\n".join(" " + line for line in json.dumps(entry, ensure_ascii=False, indent=1).split("\n")))
    if not new:
        print("data/items.json has every item.")
        return
    ITEMS.write_text(body[:-1].rstrip() + ",\n" + ",\n".join(new) + "\n]" + text[len(body):], encoding="utf-8")
    json.loads(ITEMS.read_text(encoding="utf-8"))
    print(f"appended {len(new)} items to data/items.json: "
          + ", ".join(official["items"][u]["name"] for u in missing))


def main(argv):
    if "--compare" not in argv:
        official = crawl()
        OUT.write_text(json.dumps(official, ensure_ascii=False, indent=1, sort_keys=True) + "\n")
        print(f"wrote {OUT.relative_to(ROOT)}: {len(official['items'])} items from {official['pages']} pages")
    official = json.loads(OUT.read_text())
    missing = compare(official)
    if "--add-new" in argv:
        add_new(official, missing)


if __name__ == "__main__":
    main(sys.argv[1:])
