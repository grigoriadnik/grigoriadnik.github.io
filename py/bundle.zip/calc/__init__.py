"""Shop Titans hero and champion stats and power, with every step of the game's arithmetic.

    from calc import compute, diff
    r = compute(hero)            # hero: data/roster/heroes/*.json format (or a data/heroes.json dowob record)
    r = compute(champion)        # champion: data/roster/champions/*.json format (it has "champion", not "hero")
    r["stats"], r["steps"], r["warnings"]
    diff(hero, [{"slot": 2, "item": "...", "quality": "Epic", "element": "...", "spirit": "..."}])
    diff(champion, [{"powerUps": 1}])   # champions: slot 1 Familiar, slot 2 Aurasong, or more power-ups
    infer_quality(hero, 2)       # [{"quality", "starforged", "diff"}] that fit the slot's own popup numbers

Contract: PLAN.md. Formula, sources and how sure each step is: calc/README.md.
"""
from . import champion as _champion
from . import engine as _engine


def compute(unit, options=None):
    if _champion.is_champion(unit):
        return _champion.compute_champion(unit, options)
    return _engine.compute(unit, options)


def diff(unit, changes, options=None):
    if _champion.is_champion(unit):
        return _champion.diff_champion(unit, changes, options)
    return _engine.diff(unit, changes, options)


def infer_quality(unit, slot, options=None):
    if _champion.is_champion(unit):
        return _champion.infer_quality_champion(unit, slot, options)
    return _engine.infer_quality(unit, slot, options)


__all__ = ["compute", "diff", "infer_quality"]
