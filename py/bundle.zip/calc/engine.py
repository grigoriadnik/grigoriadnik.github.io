"""Hero stats and power, step by step, in the order the game does the arithmetic. Formula and sources: README.md."""
import copy
import math
from pathlib import Path

from . import effects
from . import power as power_mod
from .gamedata import (Unknown, base_stats, blueprint_boosts, calc_data, element_by_key, find_class, find_element,
                       find_item, find_skill, find_spirit, hr, item_skill, item_types, rules, spirit_by_uid, type_names,
                       weapon_types)

STATS3 = ("attack", "defense", "hp")
SHORT = {"attack": "ATK", "defense": "DEF", "hp": "HP", "evasion": "EVA", "critChance": "crit chance",
         "critDamage": "crit damage", "threat": "threat", "regen": "HP regen", "element": "element",
         "power": "power"}
STAT_KEYS = ("attack", "defense", "hp", "evasion", "critChance", "critDamage", "element", "threat", "power")
ITEM_STAT = {"attack": "attack", "defense": "defense", "hp": "hp", "evasion": "evasion", "critChance": "critical_chance"}
TRANSCEND = {"atk": "attack", "def": "defense", "hp": "hp", "crit": "critChance", "eva": "evasion"}
SEED_NAME = {"attack": "Seeds of Power", "defense": "Seeds of Resistance", "hp": "Seeds of Vitality"}


def _text(tier):
    """A tier's effect text: the official sheet's where it differs from dowob (data/text_overrides.json)."""
    return calc_data("text_overrides.json")["tiers"].get(tier["name"], tier["description"])


def _round(x):
    """Half up, like Google Sheets' ROUND on positive numbers."""
    return math.floor(x + 0.5 + 1e-9)


def _floor(x):
    return math.floor(x + 1e-9)


def _num(x):
    return int(x) if float(x).is_integer() else round(x, 4)


def attack_parts(hero_part, gear_part, pct, card=1.0):
    """Final ATK = floor(hero part x bonus x card) + floor(gear part x bonus x card) (Ress Hero 1!AA140)."""
    mult = (1 + pct / 100) * card
    return _floor(hero_part * mult), _floor(gear_part * mult)


def _total(stat, hero_part, gear_part, pct, card):
    if stat == "attack":
        return sum(attack_parts(hero_part, gear_part, pct, card))
    return _round((hero_part + gear_part) * (1 + pct / 100) * card)


def _infer_seeds(stat, hero_part, gear_part, pct, card, shown, cap):
    """The seed count that makes the total match the shown stat, or None. The game shows seed counts nowhere safe
    to open, and they are almost always 0 or maxed (40, 80 with a blossom): one of those wins when it lands within
    the rounding of the six items (3 points); any other count must match within 1."""
    per = rules()["seeds"]["perSeed"][stat]
    one_point = (1 + pct / 100) * card  # one point of base or item stat, in the total

    def miss(n):
        return abs(_total(stat, hero_part + n * per, gear_part, pct, card) - shown)
    usual = min((miss(n), n) for n in (0, 40, 80) if n <= cap)
    if usual[0] <= max(1, 3 * one_point):  # 3 points: six items rounded half a point each
        return usual[1]
    best = min((miss(n), n) for n in range(cap + 1))
    return best[1] if best[0] <= 1 else None


class _Run:
    def __init__(self):
        self.steps, self.warnings = [], []

    def step(self, stat, group, label, op, value, total, note=None):
        s = {"stat": stat, "group": group, "label": label, "op": op, "value": _num(value), "total": _num(total)}
        if note:
            s["note"] = note
        self.steps.append(s)
        return total

    def warn(self, text):
        if text not in self.warnings:
            self.warnings.append(text)


# ---------------------------------------------------------------- input

def normalize(hero):
    """The roster format (data/roster/SCHEMA.md) as is; a dowob record from data/heroes.json converted to it."""
    if "heroClass" not in hero:
        return hero
    real = (hero.get("attack") or 0) > 1 or (hero.get("hp") or 0) > 1  # dowob keeps 1/1/1 for heroes never typed in
    return {
        "hero": hero["name"], "class": hero["heroClass"]["name"], "level": hero.get("level"),
        "seeds": {"hp": hero.get("hpSeeds"), "attack": hero.get("attackSeeds"), "defense": hero.get("defenseSeeds")}
        if real else {"hp": None, "attack": None, "defense": None},
        "cardLevel": hero.get("cardLevel"),
        "skills": [s["name"] for s in hero.get("skills", [])],
        "elementShown": hero.get("element"),
        "stats": {"attack": hero["attack"], "defense": hero["defense"], "hp": hero["hp"],
                  "evasion": hero["evasion"], "critChance": hero["critChance"],
                  "critDamage": float(hero["critDamage"]), "threat": hero["threat"], "power": None} if real else None,
        "slots": [{"slot": n, "unknown": True} for n in range(1, 7)],
        "source": "dowob",
    }


def _resolve_slot(raw, run, boosts=None):
    """One slot -> {slot, status: item|empty|unknown, item, quality, mult, enchant, spirit, ...}. boosts: the owner's
    starforged blueprints (item name -> factor); they decide 'starforged' where the slot does not say."""
    n = raw.get("slot")
    s = {"slot": n, "status": "unknown", "raw": raw}
    if raw.get("empty"):
        s["status"] = "empty"
        return s
    if raw.get("unknown") or not raw.get("item"):
        return s
    try:
        item = find_item(raw["item"])
    except Unknown as e:
        run.warn(f"slot {n}: {e} — slot left out of the stats")
        return s
    quality = (raw.get("quality") or "").title()
    if quality not in hr.QUALITY:
        run.warn(f"slot {n} {item['name']}: quality {raw.get('quality')!r} not read — assumed Epic")
        quality = "Epic"
    from_blueprint = raw.get("starforged") is None and (boosts or {}).get(item["name"], 1) > 1
    s.update(status="item", item=item, quality=quality, mult=hr.QUALITY[quality], types=item_types(item),
             weapon=item["type"] in weapon_types(), starforgedBlueprint=from_blueprint,
             starforged=bool(raw.get("starforged")) or from_blueprint, transcendence=int(raw.get("transcendence") or 0))

    built_in = (item.get("innate") or {}).get("element")
    s["enchant"], s["enchantBuiltIn"] = (element_by_key().get(built_in), True) if built_in else (None, False)
    if raw.get("element"):
        try:
            chosen = find_element(raw["element"])
            if built_in and chosen["key"] != built_in:
                run.warn(f"slot {n} {item['name']}: has a built-in {s['enchant']['name']}, but {chosen['name']} was read — using {chosen['name']}")
            s["enchant"], s["enchantBuiltIn"] = chosen, chosen["key"] == built_in
        except Unknown as e:
            run.warn(f"slot {n}: {e} — no element counted")

    built_in_spirit = (item.get("innate") or {}).get("spirit")
    s["spirit"], s["spiritBuiltIn"] = (spirit_by_uid().get(built_in_spirit), True) if built_in_spirit else (None, False)
    if raw.get("spirit"):
        try:
            s["spirit"] = find_spirit(raw["spirit"])
            s["spiritBuiltIn"] = s["spirit"]["uid"] == built_in_spirit
        except Unknown as e:
            run.warn(f"slot {n}: {e} — no spirit counted")
    s["spiritAffinity"] = bool(s["spirit"]) and (item.get("affinity") or {}).get("spirit") == s["spirit"]["uid"]
    return s


def spirit_effects(run, worn, promoted, cls_name, known_types):
    """(label, effect) for the spirits on the worn items: the '+' text on an item with that spirit affinity, x2 on an
    Idol, Titan only when promoted and only the largest; Tomb-Bound's "+X% bonus to enchanted item's stats" goes to
    its own slot's item bonus (s["itemBonus"]) instead."""
    fx = []
    titans, idol_mult = [], rules()["idolSpiritEffectMultiplier"]["value"]
    for s in worn:
        sp = s["spirit"]
        if not sp:
            continue
        text = sp["effectWithAffinity"] if s["spiritAffinity"] else sp["effect"]
        on_idol = "Idol" in s["types"]
        label = f"{sp['name']}{'+' if s['spiritAffinity'] else ''}{' on Idol x2' if on_idol else ''} (slot {s['slot']})"
        if on_idol and sp["name"] != "Titan Spirit":
            run.warn(f"slot {s['slot']}: {sp['name']} on an Idol counted twice (Ress; STC confirms it for Titan)")
        for e in effects.parse(text, known_types):
            e = dict(e)
            if e["kind"] == "item_stats":
                # Added to this item's own % bonus sum, next to the class/skill item bonuses: Hero 16's Epic Ultima
                # Deflector shows 6,243 = round((1510 + 133) x (1 + 2.00 + 0.60 + 0.20)) (execute, 2026-10-30).
                s["itemBonus"] = (label, e["value"])
                if s["spiritAffinity"]:
                    run.warn(f"slot {s['slot']}: {sp['name']}+ on its affinity item: +{e['value']:g}% item bonus "
                             f"from the '+' text, not checked in the game")
                continue
            if e["kind"] == "conditional":
                fx.append((label, e))
                continue
            if on_idol and e.get("value") is not None:
                e["value"] *= idol_mult
            if sp["name"] == "Titan Spirit" and e["kind"] == "pct":
                titans.append((e["value"], label, e))
                continue
            fx.append((label, e))
    if titans:
        titans.sort(key=lambda t: -t[0])
        if not promoted:
            run.warn(f"Titan Spirit does nothing on a non-promoted hero ({cls_name}) — not counted")
        else:
            fx.append((titans[0][1], titans[0][2]))
            if len(titans) > 1:
                run.warn(f"{len(titans)} Titan spirits: only the largest counts")
    return fx


def item_stats(run, worn, gear=(), typed=(), innate_el_items=0, shield_to_atk=False):
    """Each worn item's final ATK/DEF/HP/EVA/crit into s["final"], with its steps: base x quality + flats + enchants,
    x (starforge, transcendence), x (gear + type bonuses). Returns the slots whose enchants a % boost touched and the
    slots with a built-in element under Spellblade's innate, for the warnings."""
    R = rules()
    aff_mult = R["enchantAffinityStatMultiplier"]["value"]
    boosted_enchants, jack_items = [], []
    for s in worn:

        it, n = s["item"], s["slot"]
        group = f"slot{n}"
        trans = it.get("transcendence") or []
        trans_flat, trans_pct, trans_notes = {}, 0.0, []
        for level_no, t in enumerate(trans[:s["transcendence"]], 1):
            key, _, val = t.partition("+")
            if key in TRANSCEND:
                v = float(val) * (100 if key in ("crit", "eva") else 1)
                trans_flat[TRANSCEND[key]] = trans_flat.get(TRANSCEND[key], 0) + v
                trans_notes.append((level_no, TRANSCEND[key], v))
            elif t.startswith("baseStats*"):
                trans_pct += float(t.split("*")[1]) - 1
            else:
                run.warn(f"slot {n} {it['name']}: transcendence {level_no} '{t}' is not a hero stat — left out")
        sf = 0.0
        if s["starforged"]:
            boost = it.get("starforgeStatBoost")
            if boost is None:
                run.warn(f"slot {n} {it['name']}: starforged, but the data has no starforge boost — assumed x1.25")
            sf = float(boost or R["itemMultipliers"]["starforgeDefault"]) - 1
        if trans_pct and (s["enchant"] or s["spirit"]):
            boosted_enchants.append(str(n))
        affinity = hr.item_affinity_elements(it)
        s["elementAffinity"] = bool(s["enchant"]) and (s["enchantBuiltIn"] or s["enchant"]["elementType"] in affinity
                                                       or "all" in affinity)
        # One matching enchant (a built-in element counts) puts the item in affinity: both enchants then add x1.5,
        # rounded half up (the owner's item popups, game v26.10).
        s["affinity"] = s["elementAffinity"] or s["spiritAffinity"]
        el_mult = sp_mult = aff_mult if s["affinity"] else 1
        el_stats = {x["type"]: x["value"] for x in s["enchant"]["stats"]} if s["enchant"] else {}
        sp_stats = s["spirit"]["stats"] if s["spirit"] else {}
        if innate_el_items and (it.get("innate") or {}).get("element"):
            jack_items.append(str(n))
        # Starforge / transcendence III: x m on the base stat (rounded, as the blueprint shows it) and on each
        # enchant's stat (rounded), before quality: Stone Jaguar Greaves 888 = round(710 x 1.25), and an Epic one with
        # two 109-DEF enchants 888 x 2 + 2 x round(109 x 1.25) = 2048 (the owner's popups).
        m = 1 + (sf if s["starforged"] else 0) + trans_pct
        m_label = " + ".join(([f"starforged{' blueprint' if s['starforgedBlueprint'] else ''} +{sf:g}"]
                              if s["starforged"] else []) + ([f"transcendence III +{trans_pct:g}"] if trans_pct else []))
        s["final"] = {}
        for stat in STATS3:
            b = it["stats"].get(stat, 0)
            if not (b or trans_flat.get(stat)):
                s["final"][stat] = 0
                continue
            name = f"Slot {n} {it['name']}"
            v = run.step(stat, group, f"{name}: base {SHORT[stat]}", "=", b, b)
            if m != 1 and b:
                v = run.step(stat, group, f"× (1 + {m_label}), rounded", "×", m, _round(b * m))
            v = run.step(stat, group, f"{s['quality']} quality", "×", s["mult"], v * s["mult"])
            for level_no, tstat, tv in trans_notes:
                if tstat == stat:
                    tv = _round(tv * m)
                    v = run.step(stat, group, f"Transcendence {'I' * level_no}" + (f" x {m:g}" if m != 1 else ""),
                                 "+", tv, v + tv)
            for ench, stats_, mult, built_in in ((s["enchant"], el_stats, el_mult, s["enchantBuiltIn"]),
                                                 (s["spirit"], sp_stats, sp_mult, s["spiritBuiltIn"])):
                if not ench or not stats_.get(stat):
                    continue
                raw = _round(stats_[stat] * mult)
                added = min(raw, b)
                why = (f" x1.5 affinity = {raw}" if mult != 1 else "") + (f", capped at item base {b}" if added < raw else "")
                if m != 1:
                    why += f", x {m:g} = {_round(added * m)}"
                    added = _round(added * m)
                v = run.step(stat, group, f"{ench['name']}{' (built in)' if built_in else ''} {SHORT[stat]} "
                             f"{stats_[stat]}{why}", "+", added, v + added,
                             "enchants add only to stats the item has, up to its base value (Ress)")
            v = run.step(stat, group, "rounded", "=", _round(v), _round(v))
            bonus = [(lab, val) for lab, val in gear]
            for lab, e in typed:
                if stat in e["stats"] and s["types"] & e["types"]:
                    bonus.append((lab, e["value"]))
            if s.get("itemBonus"):
                bonus.append(s["itemBonus"])
            if bonus:
                total_pct = sum(val for _, val in bonus)
                label = " + ".join(f"{lab} {val:g}%" for lab, val in bonus)
                v = run.step(stat, group, f"× (1 + {label}), rounded", "×", 1 + total_pct / 100,
                             _round(v * (1 + total_pct / 100)))
            s["final"][stat] = v
        if shield_to_atk and "Shield" in s["types"] and s["final"]["defense"]:
            v = s["final"]["attack"] + s["final"]["defense"]
            run.step("attack", group, f"Shield Style: {it['name']}'s DEF {s['final']['defense']} added to ATK", "+",
                     s["final"]["defense"], v)
            s["final"]["attack"] = v
        for stat in ("evasion", "critChance"):
            v = it["stats"].get(ITEM_STAT[stat], 0) + trans_flat.get(stat, 0)
            s["final"][stat] = v
    return boosted_enchants, jack_items


def use_shown_items(run, worn):
    """Each item popup's own numbers (roster slots[].shown) in place of the computed ones: checks the totals on their
    own, apart from the item arithmetic (option shownItems)."""
    for s in worn:
        shown_item = s["raw"].get("shown")
        if not shown_item:
            continue
        for stat in STATS3 + ("evasion", "critChance"):
            if (shown_item.get(stat) or 0) != s["final"][stat]:
                run.step(stat, f"slot{s['slot']}", f"Slot {s['slot']}: the item popup shows {shown_item.get(stat) or 0}"
                         f" — used instead", "=", shown_item.get(stat) or 0, shown_item.get(stat) or 0)
            s["final"][stat] = shown_item.get(stat) or 0
    run.warn("item stats taken from the item popups (option shownItems), not computed")


# ---------------------------------------------------------------- the calculation

def compute(hero, options=None):
    """Stats, steps and warnings for one hero (roster format or a dowob record). Contract: PLAN.md.
    options: {"catalystIsStaff": True} follows Ress where the game text says otherwise (data/rules.json)."""
    return _compute(normalize(hero), options=options)


def _compute(hero, element_offset=None, options=None, tiers_from_element=False):
    """tiers_from_element: skill tiers always follow the element (diff), even where the hero's skills are given by
    the tier name the game showed; otherwise the game's tier wins over the element's."""
    run = _Run()
    R = rules()
    options = options or {}
    catalyst_is_staff = options.get("catalystIsStaff", R["catalystIsStaff"]["default"])

    # --- Class, promotion, level, seeds, card.
    try:
        cls = find_class(hero.get("class") or "")
    except Unknown as e:
        raise ValueError(f"{hero.get('hero')}: {e}")
    promoted = cls["isPromoted"]
    if hero.get("promoted") and not promoted and cls.get("promotesTo"):
        run.warn(f"'promoted' is true but the class reads {cls['name']} — computed as {cls['promotesTo']}")
        cls, promoted = find_class(cls["promotesTo"]), True
    elif hero.get("promoted") is False and promoted:
        run.warn(f"{cls['name']} is a promoted class but 'promoted' is false — computed as promoted")
    base = base_stats(cls["name"])
    level = hero.get("level")
    if not level:
        run.warn("level not read — assumed 40")
        level = 40
    level = max(1, min(int(level), len(base["hp"])))
    seeds = {}
    for stat in STATS3:
        v = (hero.get("seeds") or {}).get(stat)
        if v is not None and v > R["seeds"]["capWithBlossom"]:
            run.warn(f"{SEED_NAME[stat]} {v} is above the cap of {R['seeds']['capWithBlossom']} — check the reading")
        seeds[stat] = v  # None: inferred from the shown stat below, or 0
    card_level = hero.get("cardLevel")
    if card_level is None:
        run.warn("card level not read — assumed no card bonus (x1)")
        card_level = 0
    card = R["cardLevel"]["multiplier"].get(str(card_level), 1.0)
    if card_level and card_level != 1:
        run.warn(f"card level {card_level} counted as x{card:g} on ATK/DEF/HP (Ress' simulator; the game confirms "
                 f"x1.05 for card level 1 only)")

    # --- Slots.
    given = {r.get("slot"): r for r in hero.get("slots") or []}
    bp = options.get("blueprints", "owner")
    boosts = blueprint_boosts() if bp == "owner" else (blueprint_boosts(str(bp)) if isinstance(bp, (str, Path))
                                                       else dict(bp or {}))
    slots = [_resolve_slot(given.get(n) or {"slot": n, "unknown": True}, run, boosts) for n in range(1, 7)]
    unknown = [s["slot"] for s in slots if s["status"] == "unknown"]
    if unknown:
        run.warn(f"slots {', '.join(map(str, unknown))} not read — their stats are missing from every total")
    worn = [s for s in slots if s["status"] == "item"]

    # --- Element: the game's number decides skill tiers; the gear sum is shown and cross-checked.
    for s in worn:
        e = s["enchant"]
        s["elementPoints"] = hr.element_contribution(cls, s["item"], e) if e else 0
        s["elementAny"] = hr.element_contribution({"element": "All"}, s["item"], e) if e else 0
        if e and s["elementPoints"] and "all" in hr.item_affinity_elements(s["item"]) \
                and e["elementType"] != hr.class_element(cls) and hr.class_element(cls) != "all":
            run.warn(f"slot {s['slot']}: {e['name']} on an 'All'-affinity item counted as {cls['element']} element "
                     f"(dowob's rule); Ress' simulator would not count it")
    element_computed = sum(s["elementPoints"] for s in worn)
    element_any = sum(s["elementAny"] for s in worn)
    shown_el = hero.get("elementShown")
    if element_offset is not None:
        element_used = element_computed + element_offset
    elif shown_el is not None:
        element_used = shown_el
        if not unknown and shown_el != element_computed:
            run.warn(f"element: the gear adds up to {element_computed} but the game shows {shown_el} — "
                     f"skill tiers use {shown_el}; an enchant was probably misread")
    else:
        element_used = element_computed
    total_el = 0
    for s in worn:
        if s["enchant"]:
            total_el = run.step("element", f"slot{s['slot']}", f"Slot {s['slot']} {s['enchant']['name']}"
                                + (" (built in)" if s["enchantBuiltIn"] else "") + f" on {s['item']['name']}",
                                "+", s["elementPoints"], total_el + s["elementPoints"])
    run.step("element", "total", "Element from gear" + (" (slots not read are missing)" if unknown else ""),
             "=", element_computed, element_computed)
    if element_used != element_computed:
        run.step("element", "total", "Element the game shows, used for skill tiers", "=", element_used, element_used)

    # --- Skills, innate and spirits -> effects.
    known_types = set(type_names().values())
    fx = []  # (source label, effect)
    skill_out = []
    for name in hero.get("skills") or []:
        try:
            sk = find_skill(name)
        except Unknown as e:
            run.warn(f"{e} — skill left out")
            continue
        if cls["name"] not in sk.get("classes", []):
            run.warn(f"{sk['name']} is not listed as a {cls['name']} skill in the data — counted anyway")
        tier = hr.reached_tier(sk["tiers"], element_used, promoted)
        shown_tier = next((t for t in sk["tiers"] if t["name"].lower() == name.strip().lower()), None)
        if shown_tier and shown_tier["tier"] != tier["tier"] and name.strip().lower() != sk["name"].lower():
            run.warn(f"{sk['name']}: the game shows tier {shown_tier['tier']} ({shown_tier['name']}) "
                     f"but element {element_used} gives tier {tier['tier']} — using "
                     + ("the element's tier" if tiers_from_element else "the game's tier"))
            if not tiers_from_element:
                tier = shown_tier
        skill_out.append({"name": sk["name"], "tier": tier["tier"], "tierName": tier["name"],
                          "description": _text(tier)})
        for e in effects.parse(_text(tier), known_types):
            fx.append((f"{tier['name']} (T{tier['tier']} {sk['name']})", e))
    innate_tier = hr.reached_tier(cls["innate"]["tiers"], element_used, promoted)
    for e in effects.parse(_text(innate_tier), known_types):
        fx.append((f"{innate_tier['name']} (innate T{innate_tier['tier']})", e))

    fx.extend(spirit_effects(run, worn, promoted, cls["name"], known_types))

    # Items with a skill of their own: artifacts and quivers (the game's item field 'skill', calc/data/item_skills.json).
    for s in worn:
        key = item_skill(s["item"])
        sk = calc_data("item_skills.json")["skills"].get(key) if key else None
        if not sk:
            continue
        label = f"{sk['name']} ({s['item']['name']}, slot {s['slot']})"
        if sk.get("unsure"):
            run.warn(f"slot {s['slot']}: {label} '{sk['effect']}' left out — {sk['note']}")
            continue
        fx.extend((label, e) for e in effects.parse(sk["effect"], known_types))

    # A champion's leader skill on this hero (option "party": calc.champion.party_effects): a quest effect, not on the
    # hero's Info screen; Mercenary's innate makes it count 25% more.
    for label, e in options.get("party") or []:
        boost = 1.25 if "Champion skills" in _text(innate_tier) else 1
        fx.append((label + (" x1.25 (innate)" if boost != 1 else ""), dict(e, value=e["value"] * boost)))

    pct = {k: [] for k in STATS3}
    flat = {k: [] for k in STATS3}
    add = {k: [] for k in ("evasion", "critChance", "critDamage", "threat", "regen")}
    gear, typed, conditional = [], [], []
    shield_to_atk, innate_el_items, threat_to_atk, atk_per_el, eva_cap_extra = False, 0, 0, 0, 0
    until = {"evasion": [], "critChance": []}
    sets, no_weapons = {}, None
    xp, xp_to_atk = [], []
    for label, e in fx:
        kind = e["kind"]
        if kind == "pct":
            pct[e["stat"]].append((label, e["value"]))
        elif kind == "flat":
            flat[e["stat"]].append((label, e["value"]))
        elif kind == "add":
            add[e["stat"]].append((label, e["value"]))
        elif kind == "gear":
            gear.append((label, e["value"]))
        elif kind == "typed":
            if catalyst_is_staff and "(innate" in label and "Staff" in e["types"]:
                e = dict(e, types=e["types"] | {"Catalyst"})
            typed.append((label, e))
        elif kind == "shield_to_atk":
            shield_to_atk = True
        elif kind == "innate_element_items":
            innate_el_items = e["value"]
        elif kind == "threat_to_atk":
            threat_to_atk = e["value"]
        elif kind == "atk_per_element":
            atk_per_el = e["value"]
        elif kind == "eva_cap":
            eva_cap_extra += e["value"]
        elif kind == "until_damaged":
            until[e["stat"]].append((label, e["value"]))
        elif kind == "set":
            sets[e["stat"]] = (label, e["value"])
        elif kind == "no_weapons":
            no_weapons = label
        elif kind == "conditional":
            conditional.append((label, e))
        elif kind == "xp_to_atk":
            xp_to_atk.append((label, e["value"]))
        elif kind == "other" and e.get("stat") == "xp":
            xp.append((label, e["value"]))
        elif kind == "unknown":
            run.warn(f"{label}: effect not understood, left out: '{e['text']}'")
    for label, e in conditional:
        if e.get("tag") is None and "innate" in label and any(w in e["text"] for w in ("Attack", "Evasion", "Critical")):
            run.warn(f"{label}: '{e['text']}' is conditional — left out, as the Info screen does")
    if cls["name"] in ("Mage", "Archmage") and any("Catalyst" in s["types"] for s in worn):
        run.warn("Mage/Archmage innate and a Catalyst: the game text says Staff, Idol, Ress' simulator includes Catalyst — "
                 + ("computed like Ress" if catalyst_is_staff else "computed by the text"))

    # --- Each item: base x quality + flats + enchants, x (starforge, transcendence), x (gear + type bonuses).
    boosted_enchants, jack_items = item_stats(run, worn, gear, typed, innate_el_items, shield_to_atk)
    if options.get("shownItems"):
        use_shown_items(run, worn)
    if boosted_enchants:
        run.warn(f"slots {', '.join(boosted_enchants)}: transcendence III % applied like starforge, to the "
                 f"base and to each enchant's stats (confirmed for starforge only: the owner's Stone Jaguar Greaves)")
    if jack_items:
        run.warn(f"slots {', '.join(jack_items)}: Spellblade's '+{innate_el_items:g}% extra bonus from equipment with "
                 f"innate elements' left out — the item popup does not show it (Hero 15's Xolimnul's Fortress)")

    # --- Hero totals.
    st = {}
    threat = base["threat"] + sum(v for _, v in add["threat"])
    # Thinkin' Cap's Central Thinking "+50% XP → Attack": read as ATK % += 50% of the hero's XP % (skills, spirits).
    # A hypothesis that fits two Astramancers (data/benchmarks/2026-10-30), not the game's own text or a popup.
    xp_total = sum(v for _, v in xp)
    for label, share in xp_to_atk:
        if xp_total:
            pct["attack"].append((f"{label}: {share:g}% of XP +{xp_total:g}% (hypothesis, medium confidence)",
                                  share / 100 * xp_total))
            run.warn(f"{label}: '+{share:g}% XP → Attack' counted as ATK +{share / 100 * xp_total:g}% = {share:g}% of "
                     f"the hero's XP +{xp_total:g}% ({', '.join(f'{lab} {v:g}' for lab, v in xp)}) — a hypothesis "
                     f"that fits two benchmark Astramancers within 0.5% ATK, not checked on the owner's heroes")
    pct_atk = list(pct["attack"])
    if threat_to_atk:
        pct_atk.append((f"{threat_to_atk:g}% of threat {threat:g}", threat_to_atk / 100 * threat))
    if atk_per_el:
        pct_atk.append((f"{atk_per_el:g}% ATK per element point x {element_any}", atk_per_el * element_any))
    pcts = {"attack": pct_atk, "defense": pct["defense"], "hp": pct["hp"]}
    shown_stats = hero.get("stats") or {}
    seeds_inferred = []
    for stat in STATS3:
        per = R["seeds"]["perSeed"][stat]
        if seeds[stat] is None:
            n = None
            if shown_stats.get(stat) is not None and not unknown:
                n = _infer_seeds(stat, base[stat][level - 1] + sum(val for _, val in flat[stat]),
                                 sum(s["final"][stat] for s in worn if not (no_weapons and s["weapon"])),
                                 sum(val for _, val in pcts[stat]), card, shown_stats[stat],
                                 R["seeds"]["capWithBlossom"])
            if n is None:
                run.warn(f"{SEED_NAME[stat]} not read — assumed 0")
            else:
                seeds_inferred.append(stat)
                run.warn(f"{SEED_NAME[stat]} not read — {n} inferred from the shown {SHORT[stat]}"
                         + ("" if n in (0, 40, 80) else " (an unusual count: check it)"))
            seeds[stat] = n or 0
        v = run.step(stat, "hero", f"Base {SHORT[stat]}, {cls['name']} level {level}", "=", base[stat][level - 1],
                     base[stat][level - 1], "Ress' Hero Stats table; level 1 matches the official sheet")
        if seeds[stat]:
            v = run.step(stat, "hero", f"{SEED_NAME[stat]} {seeds[stat]} x {per}"
                         + (" (inferred)" if stat in seeds_inferred else ""), "+", seeds[stat] * per, v + seeds[stat] * per)
        for lab, val in flat[stat]:
            v = run.step(stat, "hero", f"{lab}: +{val:g} {SHORT[stat]}", "+", val, v + val)
        hero_part = v
        g = 0
        for s in worn:
            if s["final"][stat]:
                if no_weapons and s["weapon"]:
                    run.step(stat, "gear", f"Slot {s['slot']} {s['item']['name']}: a weapon, grants nothing ({no_weapons})",
                             "+", 0, g)
                    continue
                g = run.step(stat, "gear", f"Slot {s['slot']} {s['item']['name']}", "+", s["final"][stat], g + s["final"][stat])
        p = 0
        for lab, val in pcts[stat]:
            p = run.step(stat, "bonus", lab, "+%", val, p + val)
        mult = (1 + p / 100) * card
        card_txt = f" x card {card:g}" if card != 1 else ""
        if stat == "attack":
            a, b = attack_parts(hero_part, g, p, card)
            run.step(stat, "total", f"Hero part {_num(hero_part)} x (1 + {_num(p)}%){card_txt}, rounded down", "=", a, a)
            st[stat] = run.step(stat, "total", f"Gear part {_num(g)} x (1 + {_num(p)}%){card_txt}, rounded down", "+",
                                b, a + b, "Ress rounds the two parts down separately (Hero 1!AA140)")
        else:
            st[stat] = run.step(stat, "total", f"(hero {_num(hero_part)} + gear {_num(g)}) x (1 + {_num(p)}%){card_txt}, rounded",
                                "=", _round((hero_part + g) * mult), _round((hero_part + g) * mult))

    for stat in ("evasion", "critChance"):
        v = run.step(stat, "hero", f"{cls['name']} base {SHORT[stat]}", "=", base[stat], base[stat])
        for s in worn:
            if s["final"][stat] and not (no_weapons and s["weapon"]):
                v = run.step(stat, "gear", f"Slot {s['slot']} {s['item']['name']}", "+", s["final"][stat], v + s["final"][stat])
        for lab, val in add[stat]:
            v = run.step(stat, "bonus", lab, "+", val, v + val)
        for lab, val in until[stat]:
            v = run.step(stat, "bonus", f"{lab}: until damaged (the hero's Info screen counts it)", "+", val, v + val)
        if stat in sets:
            v = run.step(stat, "total", f"{sets[stat][0]}: set to {sets[stat][1]:g}% and cannot change", "=",
                         sets[stat][1], sets[stat][1])
        st[stat] = v
    cap = R["evasionCap"].get(cls["name"], R["evasionCap"]["default"])
    cap = max(cap, R["evasionCap"]["default"] + eva_cap_extra)
    if st["evasion"] > cap:
        run.step("evasion", "total", f"Above the {cap:g}% cap: quests use {cap:g}%", "=", st["evasion"], st["evasion"])
    v = run.step("critDamage", "hero", f"{cls['name']} base crit damage", "=", base["critDamage"], base["critDamage"])
    for lab, val in add["critDamage"]:
        v = run.step("critDamage", "bonus", f"{lab}: +{val:g}%", "+", val / 100, v + val / 100)
    st["critDamage"] = v
    v = run.step("threat", "hero", f"{cls['name']} base threat", "=", base["threat"], base["threat"])
    for lab, val in add["threat"]:
        v = run.step("threat", "bonus", lab, "+", val, v + val)
    st["threat"] = v
    st["regen"] = sum(v for _, v in add["regen"])
    for lab, val in add["regen"]:
        run.step("regen", "bonus", lab, "+", val, val)
    st["element"] = element_computed

    # --- Power.
    shark = sum(e["value"] for _, e in conditional if e.get("tag") == "low_hp_enemy_atk")
    dino = sum(e["value"] for _, e in conditional if e.get("tag") == "first_round_atk")
    atk_pct_total = sum(v for _, v in pct_atk)
    parts, total, why = power_mod.terms(cls["name"], st, atk_pct_total, shark, dino, innate_tier["tier"], level, cap,
                                        {k: sum(v for _, v in until[k]) for k in until})
    v = 0
    for label, val in parts:
        v = run.step("power", "power", label, "+", val, v + val)
    if why:
        run.step("power", "power", why, "=", total, total)
    st["power"] = total
    if unknown:
        run.warn("power and stats are low because some slots were not read")

    # --- Compare with what the game showed.
    shown = hero.get("stats")
    check = {}
    if shown:
        for k in STAT_KEYS:
            sv = shown.get(k) if k != "element" else hero.get("elementShown")
            if sv is not None:
                check[k] = {"computed": _num(st[k]), "shown": sv, "diff": _num(st[k] - sv)}

    stats = {k: _num(st[k]) for k in STAT_KEYS}
    return {
        "hero": hero.get("hero"), "class": cls["name"], "level": level, "promoted": promoted,
        "stats": stats, "steps": run.steps, "warnings": run.warnings,
        "extra": {"regen": _num(st["regen"]), "evasionCap": cap, "elementAny": element_any,
                  "conditional": [f"{lab}: {e['text']}" for lab, e in conditional]},
        "shown": shown, "check": check,
        "elementComputed": element_computed, "elementUsed": element_used,
        "seedsUsed": dict(seeds), "seedsInferred": seeds_inferred,
        "skills": skill_out,
        "innate": {"name": innate_tier["name"], "tier": innate_tier["tier"], "description": _text(innate_tier)},
        "slots": [_slot_out(s) for s in slots],
    }


def _slot_out(s):
    if s["status"] != "item":
        return {"slot": s["slot"], s["status"]: True}
    return {"slot": s["slot"], "item": s["item"]["name"], "quality": s["quality"],
            "element": s["enchant"]["name"] if s["enchant"] else None,
            "spirit": s["spirit"]["name"] if s["spirit"] else None,
            "starforged": s["starforged"], "starforgedBlueprint": s["starforgedBlueprint"],
            "transcendence": s["transcendence"],
            "elementPoints": s["elementPoints"], **{k: _num(v) for k, v in s["final"].items()}}


# ---------------------------------------------------------------- diff

def diff(hero, changes, options=None):
    """compute() for the hero with some slots changed, plus "delta" (new - old) and "before" (old stats).

    changes: [{"slot": 2, "item": ..., "quality": ..., "element": ..., "spirit": ..., "starforged": ...,
               "transcendence": ...}] — any field left out keeps the slot's current value; {"slot": n, "empty": true}
    empties a slot. Skill tiers move with the element the change adds or removes: before and after, every tier
    comes from the element (capped by promotion), whatever tier name the hero's skills were given by.
    """
    hero = normalize(hero)
    before = _compute(hero, options=options, tiers_from_element=True)
    new = copy.deepcopy(hero)
    new["seeds"] = before["seedsUsed"]  # inferred seeds stay as they were; the shown stats are the old ones
    slots = {s.get("slot"): s for s in new.setdefault("slots", [])}
    notes = []
    for ch in changes:
        n = ch["slot"]
        old = slots.get(n)
        if old is None:
            old = {"slot": n}
            new["slots"].append(old)
            slots[n] = old
        if old.get("unknown"):
            notes.append(f"slot {n} was not read before, so the delta counts the new item in full")
        if ch.get("empty"):
            old.clear()
            old.update(slot=n, empty=True)
            continue
        if "item" in ch and ch["item"] != old.get("item"):
            # A different item does not keep the old one's enchants unless the change says so.
            for k in ("element", "spirit", "starforged", "transcendence"):
                old.pop(k, None)
        old.pop("unknown", None)
        old.pop("empty", None)
        old.update({k: v for k, v in ch.items() if k != "slot"})
    if before["seedsInferred"]:
        notes.append("seeds as inferred from the shown stats: " + ", ".join(
            f"{SHORT[k]} {before['seedsUsed'][k]}" for k in before["seedsInferred"]))
    after = _compute(new, element_offset=before["elementUsed"] - before["elementComputed"], options=options,
                     tiers_from_element=True)
    after["warnings"] = notes + after["warnings"]
    after["before"] = before["stats"]
    after["delta"] = {k: _num(after["stats"][k] - before["stats"][k]) for k in STAT_KEYS}
    return after


# ---------------------------------------------------------------- quality from the numbers

def infer_quality(hero, slot, options=None):
    """The readings of slot `slot` (quality, starforged) that make it add up to its own item popup (roster
    slots[].shown, ATK/DEF/HP within 1), most likely first: the starforge state the slot has as read (or from the
    owner's blueprint) before the other, then the quality closest to the one read. [] when none fits (the item, element or spirit was misread) or nothing shown.
    The rest of the hero counts too: class and skill bonuses, the quiver/artifact skills of the other items."""
    hero = normalize(hero)
    raw = next((s for s in hero.get("slots") or [] if s.get("slot") == slot), None)
    shown = (raw or {}).get("shown") or {}
    keys = [k for k in STATS3 if shown.get(k)]
    if not raw or not raw.get("item") or not keys:
        return []
    fits = []
    for quality in hr.QUALITY:
        for starforged in (False, True):
            trial = copy.deepcopy(hero)
            for s in trial["slots"]:
                if s.get("slot") == slot:
                    s.update(quality=quality, starforged=starforged)
            got = next(s for s in _compute(trial, options=options)["slots"] if s["slot"] == slot)
            diff = {k: (got.get(k) or 0) - (shown.get(k) or 0) for k in STATS3 if got.get(k) or shown.get(k)}
            if diff and all(abs(v) <= 1 for v in diff.values()):
                fits.append({"quality": quality, "starforged": starforged, "diff": diff})
    order = list(hr.QUALITY)
    read = (raw.get("quality") or "").title()
    near = order.index(read) if read in order else order.index("Epic")
    as_is = next(s for s in _compute(hero, options=options)["slots"] if s["slot"] == slot).get("starforged")
    fits.sort(key=lambda f: (f["starforged"] != as_is, abs(order.index(f["quality"]) - near)))
    return fits

