"""Hero power rating, as Ress' Hero & Quest Simulator computes it (Hero 1!AA143:AA157, one row per class).

power = round(0.8 x ATK x (1 + ATK% + shark/200 + dino/500 [+ class extra]) / (1 + ATK%) x (1 + crit x (critDamage - 1)))
      + round((threat x 0.025 + 5) x HP / (1 - EVA))
      + round(DEF x (threat x 0.008 + 1.2))
      + round(regen x level x (0.773 + threat x 0.0036) / (1 - EVA))
with crit and EVA as fractions (crit capped at 100%, EVA at the class cap). Some classes change one factor for
their innate; those rows are below with the cell they come from. Where the owner's heroes (data/roster, game
v26.10) showed a different number, the row says so and follows the game.
"""
import math

from .gamedata import rules


def _round(x):
    return math.floor(x + 0.5 + 1e-9)


def terms(cls_name, st, atk_pct, shark, dino, innate_tier, level, eva_cap, until=None):
    """st: final stats as the Info screen shows them (attack, defense, hp, evasion, critChance, critDamage, threat,
    regen); until: the "until damaged" EVA/crit already inside st (Ninja, Sensei). Returns ([(label, value)], total, why)."""
    p = rules()["power"]
    until = until or {}
    eva, crit = st["evasion"] - until.get("evasion", 0), st["critChance"] - until.get("critChance", 0)
    crit_part = min(crit / 100, 1)
    eva_hp = eva_regen = min(eva, eva_cap)
    atk_extra, hp_mult, def_mult, total_mult, why = 0.0, 1.0, 1.0, 1.0, None
    if cls_name == "Lord":  # AA143: Bodyguard
        hp_mult = def_mult = 1.05
        why = "Lord: HP and DEF parts x1.05 (Ress AA143)"
    elif cls_name == "Berserker":  # AA144
        atk_extra = 0.15 + 0.15 * innate_tier
        eva_hp = eva_regen = min(eva + 15, eva_cap)
        why = "Berserker: +0.15 + 0.15 x innate tier ATK, +15 EVA (Ress AA144)"
    elif cls_name == "Jarl":  # AA145
        atk_extra = 0.15 + (0.15 * innate_tier if innate_tier < 4 else 0.825 - 0.15)
        eva_hp = eva_regen = min(eva + 16.5, eva_cap)
        why = "Jarl: innate ATK extra and +16.5 EVA (Ress AA145)"
    elif cls_name in ("Dark Knight", "Death Knight", "Chronomancer"):  # AA146, AA147, AA155
        total_mult = 1.1
        why = f"{cls_name}: whole power x1.1 (Ress AA146/AA147/AA155)"
    elif cls_name == "Fateweaver":  # AA156 says x1.1; Hero 5 and 22 (innate T4) show x1.15
        total_mult = p["fateweaverMultiplier"]
        why = f"Fateweaver: whole power x{total_mult:g} (Hero 5 and 22; Ress AA156 has x1.1)"
    elif cls_name in ("Ninja", "Sensei"):  # AA148, AA149
        # The "until damaged" EVA and crit count part of the time: Sensei 75% (Hero 6 and 19 fit within 0.01%),
        # Ninja 50% (Ress). Ress' crit share min((EVA + 25%), 75%) does not fit the game; the plain share does.
        share = p["untilDamagedShare"][cls_name]
        crit_part = min((crit + share * until.get("critChance", 0)) / 100, 1)
        eva_hp = eva_regen = min(eva + share * until.get("evasion", 0), eva_cap)
        why = f"{cls_name}: the 'until damaged' EVA and crit counted {share:.0%} of the time"
    elif cls_name == "Samurai":  # AA150
        crit_part = min((crit + 15) / 100, 1)
        why = "Samurai: +15 crit (Ress AA150)"
    elif cls_name == "Daimyo":  # AA151
        crit_part = min((crit + 15) / 100, 1)
        eva_hp = eva_regen = min(eva + 15, eva_cap)
        why = "Daimyo: +15 crit, +15 EVA (Ress AA151)"
    elif cls_name in ("Dancer", "Acrobat"):  # AA152, AA153
        e = min(eva, 75)
        crit_part = min(crit / 100 + 0.25 * e / 100 if eva < crit + 10 else e / 100, 1)
        why = f"{cls_name}: dodges count as crits (Ress AA152/AA153)"
    elif cls_name == "Conquistador":  # AA154 caps it at 100%; Hero 7 (95% crit) shows no cap
        crit_part = 1.15 * crit / 100
        why = "Conquistador: crit x1.15, not capped at 100% (Hero 7; Ress AA154)"

    mod = 1 + atk_pct / 100
    atk_term = _round(p["atkWeight"] * st["attack"] * (mod + shark / p["sharkDivisor"] + dino / p["dinosaurDivisor"]
                                                      + atk_extra) / mod * (1 + crit_part * (st["critDamage"] - 1)))
    hp_term = _round((st["threat"] * p["hpPerThreat"] + p["hpConst"]) * hp_mult * st["hp"] / (1 - eva_hp / 100))
    def_term = _round(st["defense"] * (st["threat"] * p["defPerThreat"] + p["defConst"]) * def_mult)
    regen_term = _round(st.get("regen", 0) * level * (p["regenConst"] + st["threat"] * p["regenPerThreat"])
                        / (1 - eva_regen / 100))
    parts = [
        (f"ATK part: 0.8 x ATK x (1 + crit {crit_part:.0%} x (crit damage {st['critDamage']:g} - 1))"
         + (f", shark {shark:g}/dino {dino:g}" if shark or dino else ""), atk_term),
        (f"HP part: (threat {st['threat']:g} x 0.025 + 5) x HP / (1 - EVA {eva_hp:g}%)", hp_term),
        (f"DEF part: DEF x (threat {st['threat']:g} x 0.008 + 1.2)", def_term),
        (f"Regen part: regen {st.get('regen', 0):g} x level {level} x (0.773 + threat x 0.0036) / (1 - EVA)", regen_term),
    ]
    total = sum(v for _, v in parts)
    if total_mult != 1:
        total = _round(total * total_mult)
    return parts, total, why
