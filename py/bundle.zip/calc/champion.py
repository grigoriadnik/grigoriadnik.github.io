"""Champion stats and power, step by step, in the same contract as engine.compute (PLAN.md). Formula, sources and
how sure each step is: README.md § Champions. Data: calc/data/champions.json (build_champions.py)."""
import copy
import re

from . import effects
from . import power as power_mod
from .engine import (SEED_NAME, SHORT, STAT_KEYS, STATS3, _num, _resolve_slot, _round, _Run, _slot_out,
                     _total, attack_parts, item_stats, spirit_effects, use_shown_items)
from .gamedata import Unknown, blueprint_boosts, calc_data, hr, item_skill, rules, type_names

SLOT_TYPE = {1: "Familiar", 2: "Aurasong"}
LEADER_STAT = {"Attack": "attack", "Defense": "defense", "HP": "hp", "Health": "hp", "Evasion": "evasion",
               "Critical Hit Chance": "critChance", "Critical Damage": "critDamage", "Critical Hit Damage": "critDamage",
               "Critical Chance": "critChance"}


def is_champion(unit):
    return isinstance(unit, dict) and "champion" in unit and "hero" not in unit


def champion_data(name):
    """The champion's table entry by its game name ("Argon and Arnold") or first name ("Argon")."""
    table = calc_data("champions.json")["champions"]
    first = (name or "").strip().split()[0].title() if (name or "").strip() else ""
    if first in table:
        return table[first]
    raise Unknown(f"unknown champion '{name}'")


def rank_of(ch):
    """(rank, power-ups past it) from the roster's rankNumber/rankPlus, else from the text "Rank 11 +16"."""
    if ch.get("rankNumber") is not None:
        return int(ch["rankNumber"]), int(ch.get("rankPlus") or 0)
    m = re.search(r"(\d+)\s*(?:\+\s*(\d+))?", ch.get("rank") or "")
    return (int(m.group(1)), int(m.group(2) or 0)) if m else (None, 0)


def rank_rewards(data, rank, plus, stat):
    """[(label, value)]: each rank's reward up to `rank`, then `plus` power-ups (the last rank's reward / 6)."""
    out = [(f"rank {r}", data["ranks"][r].get(stat, 0)) for r in data["ranks"] if int(r) <= rank
           and data["ranks"][r].get(stat)]
    if plus and data.get("powerUpExact"):
        out.append((f"{plus} power-ups x {data['powerUpExact'][stat]:.4g}", plus * data["powerUpExact"][stat]))
    return out


def leader_tier(data, rank):
    """The leader skill tier at a rank: 1, plus one at each rank in leaderAt ("Leader Skill Upgraded")."""
    tier = 1 + sum(1 for r in data["leaderAt"] if int(r) <= rank)
    return min(tier, len(data["leader"])) if data["leader"] else None


def leader_effects(text):
    """The party bonuses in a leader skill's text, as numbers: [{"stat", "value", "kind", "text"}], kind "pct" for
    ATK/DEF/HP %, "add" for EVA/crit/crit damage points, "regen" for HP healed per turn, "other" for the rest
    (quest time, loot, conditional ones)."""
    out = []
    for clause in re.split(r",\s+(?=[+-]|Heals|\d)|\.\s+", text.strip(" .")):
        clause = clause.strip(" .")
        if not clause:
            continue
        m = re.match(r"^\+(\d+(?:\.\d+)?)% (?:bonus |more )?(Attack|Defense|HP|Health|Evasion|Critical Hit Chance|"
                     r"Critical Chance|Critical Damage|Critical Hit Damage)(?: (?:&|and) (Defense|Mana Shield|Evasion))?"
                     r"(?: for the party| to the party)?$", clause)
        heal = re.match(r"^Heals party by (\d+) HP each turn$", clause)
        if m and not re.search(r"for \d+ rounds|for each", clause):
            v = float(m.group(1))
            for word in (m.group(2), m.group(3)):
                if word and word != "Mana Shield":
                    st = LEADER_STAT[word]
                    out.append({"stat": st, "value": v, "kind": "pct" if st in STATS3 else "add", "text": clause})
        elif heal:
            out.append({"stat": "regen", "value": float(heal.group(1)), "kind": "regen", "text": clause})
        else:
            out.append({"kind": "other", "text": clause})
    return out


def _level_stat(data, stat, level):
    return data["levels"][stat][level - 1]


def _infer_seeds_champion(stat, hero_part, gear_part, pct, card, shown, cap, per):
    """The seed count that makes the total match the shown stat, or None. 0, 40 or 80 wins when it lands within
    3 seeds' worth: the level table above 40 is Ress' estimate (a few points off), so a count like 38 or 41 would
    only hide that. Any other count must match within 1 (then it is reported as unusual)."""
    one_seed = per * (1 + pct / 100) * card

    def miss(n):
        return abs(_total(stat, hero_part + n * per, gear_part, pct, card) - shown)
    usual = min((miss(n), n) for n in (0, 40, 80) if n <= cap)
    if usual[0] <= max(1, 3 * one_seed):
        return usual[1]
    best = min((miss(n), n) for n in range(cap + 1))
    return best[1] if best[0] <= 1 else None


def compute_champion(ch, options=None):
    """Stats, steps and warnings for one champion (data/roster/champions/*.json format). Titan Soul and seeds are
    not shown by the game: a 'titanSoul' / 'seeds' field wins, else both are inferred from the shown stats."""
    options = options or {}
    given = ch.get("titanSoul")
    if isinstance(given, bool):
        return _compute(ch, given, options)
    tries = [_compute(ch, t, options) for t in (False, True)]

    def miss(r):  # how far the stats land from the shown ones, and how many seed counts had to be odd
        odd = sum(1 for k in r["seedsInferred"] if r["seedsUsed"][k] not in (0, 40, 80))
        return (sum(1 for k in STATS3 if k in r["check"] and abs(r["check"][k]["diff"]) > 2), odd,
                sum(abs(r["check"][k]["diff"]) for k in STATS3 if k in r["check"]))
    level = ch.get("level") or 0
    best = min(tries, key=lambda r: (miss(r), r["titanSoul"] != (level > 40)))
    if not ch.get("stats"):
        best = tries[1] if level > 40 else tries[0]
        best["warnings"].append("Titan Soul not read and no shown stats to infer it from — "
                                + ("assumed (level above 40)" if level > 40 else "assumed none"))
    else:
        best["warnings"].insert(0, f"Titan Soul not shown by the game — inferred from the shown stats: "
                                   f"{'yes' if best['titanSoul'] else 'no'}")
    best["titanSoulInferred"] = True
    return best


def _compute(ch, titan, options, element_offset=None):
    run = _Run()
    R = rules()
    name = ch.get("champion") or ""
    try:
        data = champion_data(name)
    except Unknown as e:
        raise ValueError(str(e))
    level = ch.get("level")
    if not level:
        run.warn("level not read — assumed 40")
        level = 40
    level = max(1, min(int(level), len(data["levels"]["hp"])))
    if level > 40 and not titan:
        run.warn(f"level {level} above 40 without a Titan Soul — computed as read")
    rank, plus = rank_of(ch)
    if rank is None:
        run.warn("rank not read — assumed rank 1")
        rank, plus = 1, 0
    last = max(int(r) for r in data["ranks"])
    rank = min(rank, last)
    ts = calc_data("champions.json")["titanSoul"]
    # Titan Soul: the rank counts two power-ups more and its rewards x1.5 (Ress 'Champion 1'!B18:B20). Below the last
    # rank the two extra steps are ranks.
    r_rank, r_plus = rank, plus
    if titan:
        extra = ts["extraPowerUps"]
        step_up = min(extra, last - r_rank)
        r_rank, r_plus = r_rank + step_up, r_plus + extra - step_up
    card_level = ch.get("cardLevel")
    if card_level is None:
        run.warn("card level not read — assumed no card bonus (x1)")
        card_level = 0
    card = R["cardLevel"]["multiplier"].get(str(card_level), 1.0)
    if card_level and card_level != 2:
        run.warn(f"card level {card_level} counted as x{card:g} (checked for champions at card level 2 only)")

    # --- Items (slot 1 Familiar, slot 2 Aurasong): the hero item rules, without class or skill bonuses.
    given = {r.get("slot"): r for r in ch.get("items") or ch.get("slots") or []}
    bp = options.get("blueprints", "owner")
    boosts = blueprint_boosts() if bp == "owner" else (blueprint_boosts(str(bp)) if isinstance(bp, str) else dict(bp or {}))
    slots = [_resolve_slot(given.get(n) or {"slot": n, "unknown": True}, run, boosts) for n in (1, 2)]
    unknown = [s["slot"] for s in slots if s["status"] == "unknown"]
    if unknown:
        run.warn(f"slots {', '.join(map(str, unknown))} not read — their stats are missing from every total")
    worn = [s for s in slots if s["status"] == "item"]
    for s in worn:
        if s["item"]["type"] != SLOT_TYPE[s["slot"]]:
            run.warn(f"slot {s['slot']}: {s['item']['name']} is a {s['item']['type']}, the slot takes a {SLOT_TYPE[s['slot']]}")
        if item_skill(s["item"]):
            run.warn(f"slot {s['slot']}: {s['item']['name']} carries an item skill — not modelled for champions")

    # --- Element: the rank's element plus each enchant of the champion's element (the hero rule).
    cls_like = {"element": data["element"]}
    bps = calc_data("champions.json")["elementBreakpoints"]
    rank_count = rank + plus  # 11+16 counts as rank 27 in the breakpoints (12 = 11+1)
    rank_el = max([v for r, v in bps if r <= rank_count] or [0])
    el = run.step("element", "hero", f"Rank {rank}{f' +{plus}' if plus else ''} element", "=", rank_el, rank_el,
                  "official Champions sheet, element breakpoints")
    for s in worn:
        e = s["enchant"]
        s["elementPoints"] = hr.element_contribution(cls_like, s["item"], e) if e else 0
        s["elementAny"] = s["elementPoints"]
        if e:
            el = run.step("element", f"slot{s['slot']}", f"Slot {s['slot']} {e['name']}"
                          + (" (built in)" if s["enchantBuiltIn"] else "") + f" on {s['item']['name']}",
                          "+", s["elementPoints"], el + s["elementPoints"])
    element_computed = el
    shown_el = ch.get("elementShown")
    if element_offset is not None:
        element_used = element_computed + element_offset
    else:
        element_used = shown_el if shown_el is not None else element_computed
        if shown_el is not None and not unknown and shown_el != element_computed:
            run.warn(f"element: rank and gear add up to {element_computed} but the game shows {shown_el}")
    run.step("element", "total", "Element", "=", element_computed, element_computed)

    # --- Spirits -> effects (Titan Spirit only with a Titan Soul: the champion's promotion).
    known_types = set(type_names().values())
    fx = spirit_effects(run, worn, titan, f"{data['name']} without a Titan Soul", known_types)
    pct = {k: [] for k in STATS3}
    flat = {k: [] for k in STATS3}
    add = {k: [] for k in ("evasion", "critChance", "critDamage", "threat", "regen")}
    conditional = []
    for label, e in fx:
        kind = e["kind"]
        if kind == "pct":
            pct[e["stat"]].append((label, e["value"]))
        elif kind == "flat":
            flat[e["stat"]].append((label, e["value"]))
        elif kind == "add":
            add[e["stat"]].append((label, e["value"]))
        elif kind == "conditional":
            conditional.append((label, e))
        elif kind != "other":
            run.warn(f"{label}: effect '{e.get('text', kind)}' not modelled for champions — left out")

    # --- Item stats, as for a hero with no gear skills.
    boosted, _ = item_stats(run, worn)
    if options.get("shownItems"):
        use_shown_items(run, worn)
    if boosted:
        run.warn(f"slots {', '.join(boosted)}: transcendence III / Tomb-Bound % applied like starforge (not confirmed)")

    # --- Totals: (level + rank + seeds + flat + gear) x (1 + spirit %) x card.
    st = {}
    shown_stats = ch.get("stats") or {}
    seeds, seeds_inferred, parts_by_stat = {}, [], {}
    for stat in STATS3:
        per = R["seeds"]["perSeed"][stat]
        base_v = _level_stat(data, stat, level)
        rewards = rank_rewards(data, r_rank, r_plus, stat)
        rank_v = sum(v for _, v in rewards) * (ts["rankMultiplier"] if titan else 1)
        flat_v = sum(v for _, v in flat[stat])
        gear_v = sum(s["final"][stat] for s in worn)
        p_v = sum(v for _, v in pct[stat])
        n = (ch.get("seeds") or {}).get(stat)
        if n is None:
            if shown_stats.get(stat) is not None and not unknown:
                n = _infer_seeds_champion(stat, base_v + rank_v + flat_v, gear_v, p_v, card, shown_stats[stat],
                                          R["seeds"]["capWithBlossom"], per)
            if n is None:
                run.warn(f"{SEED_NAME[stat]} not read — assumed 0")
            else:
                seeds_inferred.append(stat)
                run.warn(f"{SEED_NAME[stat]} not read — {n} inferred from the shown {SHORT[stat]}"
                         + ("" if n in (0, 40, 80) else " (an unusual count: check it)"))
            n = n or 0
        seeds[stat] = n
        v = run.step(stat, "hero", f"Base {SHORT[stat]}, {data['name']} level {level}", "=", base_v, base_v,
                     "Ress' Champion 1 table: levels 1 and 40 from the game, 41-50 his estimate")
        rk = 0
        for lab, val in rewards:
            rk += val
        v = run.step(stat, "hero", f"Rank rewards to rank {r_rank}{f' +{r_plus}' if r_plus else ''}: "
                     + " + ".join(f"{lab} {val:.4g}" for lab, val in rewards), "+", rk, v + rk,
                     "official Champions sheet; a power-up adds the last rank's reward / 6")
        if titan:
            add_t = rk * (ts["rankMultiplier"] - 1)
            v = run.step(stat, "hero", f"Titan Soul: rank counted {ts['extraPowerUps']} power-ups higher (rank {rank}"
                         f"{f' +{plus}' if plus else ''} → {r_rank} +{r_plus}) and its rewards x{ts['rankMultiplier']:g}",
                         "+", add_t, v + add_t, "Ress 'Champion 1'; fits the owner's six champions with a Titan Soul")
        if n:
            v = run.step(stat, "hero", f"{SEED_NAME[stat]} {n} x {per}" + (" (inferred)" if stat in seeds_inferred
                                                                          else ""), "+", n * per, v + n * per)
        for lab, val in flat[stat]:
            v = run.step(stat, "hero", f"{lab}: +{val:g} {SHORT[stat]}", "+", val, v + val)
        hero_part = v
        g = 0
        for s in worn:
            if s["final"][stat]:
                g = run.step(stat, "gear", f"Slot {s['slot']} {s['item']['name']}", "+", s["final"][stat], g + s["final"][stat])
        pp = 0
        for lab, val in pct[stat]:
            pp = run.step(stat, "bonus", lab, "+%", val, pp + val)
        mult = (1 + pp / 100) * card
        parts_by_stat[stat] = (hero_part, g, pp)
        if stat == "attack":
            a, b = attack_parts(hero_part, g, pp, card)
            run.step(stat, "total", f"Champion part {_num(hero_part)} x (1 + {_num(pp)}%) x card {card:g}, rounded down",
                     "=", a, a)
            st[stat] = run.step(stat, "total", f"Gear part {_num(g)} x (1 + {_num(pp)}%) x card {card:g}, rounded down",
                                "+", b, a + b, "the hero rule (Ress Hero 1!AA140)")
        else:
            st[stat] = run.step(stat, "total", f"(champion {_num(hero_part)} + gear {_num(g)}) x (1 + {_num(pp)}%) "
                                f"x card {card:g}, rounded", "=", _round((hero_part + g) * mult),
                                _round((hero_part + g) * mult))

    for stat in ("evasion", "critChance"):
        v = run.step(stat, "hero", f"{data['name']} base {SHORT[stat]}", "=", data[stat], data[stat], "official Champions sheet")
        for s in worn:
            if s["final"][stat]:
                v = run.step(stat, "gear", f"Slot {s['slot']} {s['item']['name']}", "+", s["final"][stat], v + s["final"][stat])
        for lab, val in add[stat]:
            v = run.step(stat, "bonus", lab, "+", val, v + val)
        st[stat] = v
    cap = R["evasionCap"]["default"]
    v = run.step("critDamage", "hero", f"{data['name']} base crit damage", "=", data["critDamage"], data["critDamage"])
    for lab, val in add["critDamage"]:
        v = run.step("critDamage", "bonus", f"{lab}: +{val:g}%", "+", val / 100, v + val / 100)
    st["critDamage"] = v
    v = run.step("threat", "hero", f"{data['name']} base threat", "=", data["threat"], data["threat"])
    for lab, val in add["threat"]:
        v = run.step("threat", "bonus", lab, "+", val, v + val)
    st["threat"] = v
    st["regen"] = sum(v for _, v in add["regen"])
    st["element"] = element_computed

    # --- Power: the hero formula on these stats, times the champion's own factor (see README § Champions: the game's
    # champion power is 13-43% above the hero formula, by an amount that follows the leader skill; its rule is not
    # found, so the factor is measured on the stats and power the game showed for this champion).
    shark = sum(e["value"] for _, e in conditional if e.get("tag") == "low_hp_enemy_atk")
    dino = sum(e["value"] for _, e in conditional if e.get("tag") == "first_round_atk")
    atk_pct = sum(v for _, v in pct["attack"])
    parts, stat_power, _ = power_mod.terms("Champion", st, atk_pct, shark, dino, 1, level, cap)
    v = 0
    for label, val in parts:
        v = run.step("power", "power", label, "+", val, v + val)
    run.step("power", "power", "Hero power formula on these stats", "=", stat_power, stat_power)
    factor = options.get("powerFactor")
    shown_power = shown_stats.get("power")
    if factor is None and shown_power and all(shown_stats.get(k) is not None for k in STATS3 + ("evasion", "critChance",
                                                                                                  "critDamage", "threat")):
        _, shown_formula, _ = power_mod.terms("Champion", dict(shown_stats, regen=st["regen"]), atk_pct, shark, dino, 1,
                                              level, cap)
        factor = shown_power / shown_formula if shown_formula else None
    if factor:
        st["power"] = _round(stat_power * factor)
        run.step("power", "power", f"x {factor:.4f}: the game's power for this champion over the hero formula on its "
                 f"shown stats (the leader skill's share; its rule is not known)", "×", round(factor, 4), st["power"],
                 "measured on the roster's shown power; the same factor is kept in diff()")
        run.warn(f"power: the hero formula x {factor:.4f}, the factor measured on this champion's shown power (the "
                 f"game adds the leader skill in a way not found yet) — gains are the formula's x the factor")
    else:
        st["power"] = stat_power
        run.warn("power: the hero formula only — the game's champion power is higher (leader skill), and no shown "
                 "power to measure the factor on")

    # --- Leader skill (party effect, not in the champion's own stats).
    tier = leader_tier(data, rank)
    leader = None
    if tier:
        t = data["leader"][tier - 1]
        leader = {"name": t["name"], "tier": tier, "text": t["text"], "effects": leader_effects(t["text"]),
                  "tiers": [dict(x, reached=x["tier"] <= tier) for x in data["leader"]],
                  "nextAtRank": next((int(r) for r in sorted(data["leaderAt"], key=int) if int(r) > rank), None)}
        if ch.get("leaderSkill", {}).get("name") and ch["leaderSkill"]["name"] != t["name"]:
            run.warn(f"leader skill: the game shows {ch['leaderSkill']['name']}, rank {rank} gives {t['name']}")

    shown = ch.get("stats")
    check = {}
    if shown:
        for k in STAT_KEYS:
            sv = shown.get(k) if k != "element" else ch.get("elementShown")
            if sv is not None:
                check[k] = {"computed": _num(st[k]), "shown": sv, "diff": _num(st[k] - sv)}
    nxt = {}
    if rank >= last and data.get("powerUpExact"):  # what the next power-up adds to the shown stats (the Info screen)
        for stat in STATS3:
            hp_, g_, pp_ = parts_by_stat[stat]
            inc = data["powerUpExact"][stat] * (ts["rankMultiplier"] if titan else 1)
            nxt[stat] = _total(stat, hp_ + inc, g_, pp_, card) - st[stat]
    return {
        "champion": name, "kind": "champion", "class": data["name"], "classType": data["classType"],
        "level": level, "rank": rank, "rankPlus": plus, "titanSoul": titan, "cardLevel": card_level,
        "stats": {k: _num(st[k]) for k in STAT_KEYS}, "steps": run.steps, "warnings": run.warnings,
        "extra": {"regen": _num(st["regen"]), "evasionCap": cap, "statPower": stat_power,
                  "powerFactor": round(factor, 6) if factor else None,
                  "conditional": [f"{lab}: {e['text']}" for lab, e in conditional]},
        "shown": shown, "check": check, "elementComputed": element_computed, "elementUsed": element_used,
        "elementFromRank": rank_el, "seedsUsed": dict(seeds), "seedsInferred": seeds_inferred,
        "leader": leader, "nextPowerUp": nxt, "slots": [_slot_out(s) for s in slots],
        "skills": [], "innate": None, "promoted": titan,
    }


def diff_champion(ch, changes, options=None):
    """compute_champion() with slots changed, plus "delta" and "before". changes: [{"slot": 1|2, "item", "quality",
    "element", "spirit", ...}], {"powerUps": n} for n more power-ups (the leader tier follows the rank),
    {"titanSoul": true} for a Titan Soul used, {"seeds": {"hp": 40}} for seeds eaten. The inferred Titan Soul, seeds
    and power factor of the champion as it is are kept otherwise."""
    options = dict(options or {})
    before = compute_champion(ch, options)
    new = copy.deepcopy(ch)
    new["titanSoul"] = before["titanSoul"]
    new["seeds"] = before["seedsUsed"]
    options.setdefault("powerFactor", before["extra"]["powerFactor"])
    key = "items" if "items" in new or "slots" not in new else "slots"
    slots = {s.get("slot"): s for s in new.setdefault(key, [])}
    notes = []
    titan = before["titanSoul"]
    for c in changes:
        if "titanSoul" in c or "seeds" in c:  # a Titan Soul used, or seeds eaten
            if "titanSoul" in c:
                titan = bool(c["titanSoul"])
                new["titanSoul"] = titan
            if c.get("seeds"):
                new["seeds"] = dict(new["seeds"], **c["seeds"])
            continue
        if c.get("powerUps"):
            r, p = rank_of(new)
            last = max(int(x) for x in champion_data(new.get("champion"))["ranks"])
            for _ in range(int(c["powerUps"])):
                if r < last:
                    r += 1
                else:
                    p += 1
            new["rankNumber"], new["rankPlus"] = r, p
            new["rank"] = f"Rank {r}" + (f" +{p}" if p else "")
            continue
        n = c["slot"]
        old = slots.get(n)
        if old is None:
            old = {"slot": n}
            new[key].append(old)
            slots[n] = old
        if c.get("empty"):
            old.clear()
            old.update(slot=n, empty=True)
            continue
        if "item" in c and c["item"] != old.get("item"):
            for k in ("element", "spirit", "starforged", "transcendence", "shown"):
                old.pop(k, None)
        old.pop("unknown", None)
        old.pop("empty", None)
        old.update({k: v for k, v in c.items() if k != "slot"})
    if before["seedsInferred"]:
        notes.append("seeds as inferred from the shown stats: " + ", ".join(
            f"{SHORT[k]} {before['seedsUsed'][k]}" for k in before["seedsInferred"]))
    after = _compute(new, titan, options, element_offset=before["elementUsed"] - before["elementComputed"])
    after["warnings"] = notes + after["warnings"]
    after["before"] = before["stats"]
    after["delta"] = {k: _num(after["stats"][k] - before["stats"][k]) for k in STAT_KEYS}
    return after


def infer_quality_champion(ch, slot, options=None):
    """engine.infer_quality for a champion's slot 1 or 2: the (quality, starforged) readings that fit the item
    popup's own ATK/DEF/HP (within 1), most likely first."""
    from .gamedata import hr as _hr
    key = "items" if "items" in ch else "slots"
    raw = next((s for s in ch.get(key) or [] if s.get("slot") == slot), None)
    shown = (raw or {}).get("shown") or {}
    keys = [k for k in STATS3 if shown.get(k)]
    if not raw or not raw.get("item") or not keys:
        return []
    fits = []
    for quality in _hr.QUALITY:
        for starforged in (False, True):
            trial = copy.deepcopy(ch)
            for s in trial[key]:
                if s.get("slot") == slot:
                    s.update(quality=quality, starforged=starforged)
            got = next(s for s in _compute(trial, False, options or {})["slots"] if s["slot"] == slot)
            d = {k: (got.get(k) or 0) - (shown.get(k) or 0) for k in STATS3 if got.get(k) or shown.get(k)}
            if d and all(abs(v) <= 1 for v in d.values()):
                fits.append({"quality": quality, "starforged": starforged, "diff": d})
    order = list(_hr.QUALITY)
    read = (raw.get("quality") or "").title()
    near = order.index(read) if read in order else order.index("Epic")
    fits.sort(key=lambda f: (f["starforged"], abs(order.index(f["quality"]) - near)))
    return fits


def party_effects(ch, options=None):
    """The champion's leader skill as hero effects, for calc.compute(hero, {"party": ...}): [(label, effect)] with
    effect kinds the hero engine knows (pct ATK/DEF/HP, add EVA/crit/crit damage, add regen). Effects that only act
    in some rounds, scale with the party or are not stats (quest time, loot) are left out."""
    r = compute_champion(ch, options)
    if not r["leader"]:
        return []
    out = []
    for e in r["leader"]["effects"]:
        label = f"{r['leader']['name']} ({r['class']}'s leader skill)"
        if e["kind"] in ("pct", "add"):
            out.append((label, {"kind": e["kind"], "stat": e["stat"], "value": e["value"], "text": e["text"]}))
        elif e["kind"] == "regen":
            out.append((label, {"kind": "add", "stat": "regen", "value": e["value"], "text": e["text"]}))
    return out
