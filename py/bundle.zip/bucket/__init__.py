"""The owner's bucket list: what to craft or buy so the next upgrades become doable (README.md here)."""
