"""Build the bucket list from what the review and execute already decided. Read-only towards them: it reads
data/actions/plan.json (execute's steps: `target`, `waitsFor`, `consumes`, `availability`), data/reviews/summary.json
(the champions' moves, card qualities, unit power), data/roster/inventory.json and blueprints.json, data/items.json and
data/item_sources.json. Nothing here does its own power arithmetic: every gain is calc's, as the review measured it.

Two kinds of records:
- groups: one upgrade each (a hero or champion slot, a hero's promotion, a champion's Upgrade Class), with the
  lines it needs;
- entries: one thing to gather each (an item in Epic or Legendary, an element or spirit enchant whose card must be
  Epic+ or Legendary, the Titan Soul), with every group and plan step that needs it. The Titan Soul is one shared
  entry: each soul goes to one promotion or Upgrade Class, the best gain first (the groups' order).
Stock the plan already takes (open steps of data/actions/plan.json, the champions' moves) is a reservation: it counts
in `needed` and is covered first, so `have` is simply what the game shows.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
REVIEWS = DATA / "reviews"
ROSTER = DATA / "roster"
ACTIONS = DATA / "actions"
SOURCE_FILES = [REVIEWS / "summary.json", ACTIONS / "plan.json", ROSTER / "inventory.json", ROSTER / "blueprints.json"]

EPIC_PLUS = ("Epic", "Legendary")
CLOSED = ("done", "skipped", "dropped", "cancelled")

# Effort of one line to gather, for gain per effort: craft is the owner's cheap way, an enchant is a small craft or
# buy, Market costs gold (more effort the rarer the item is there), a Legendary to craft is luck.
EFFORT = {"craft": 1.0, "enchant": 0.5, "event": 1.5, "market": 2.0, "special": 4.0, "luck": 3.0, "soul": 2.0}
MARKET_EFFORT = {"common": 2.0, "chest": 2.0, "older-pack": 2.5, "new": 3.0, "rare": 4.0}
LEGENDARY_EFFORT = 1.5  # a Legendary item or card is harder to get than an Epic one
# Group order: craft only first (economy), then enchants to gather, Market, rare / Legendary luck, Titan Soul uses.
TIERS = {0: "Craft", 1: "Enchants", 2: "Market", 3: "Σπάνια / Legendary με τύχη",
         4: "Titan Soul: promotion / Upgrade Class"}
# A hero's promotion and a champion's Upgrade Class (the «+» by its class) cost 1 Titan Soul each (execute-2 saw the
# red «1» on the phone, 2026-10-30); nothing else of their cost was seen.
TITAN_SOUL = "Titan Soul"
SOUL_KEY = "consumable|" + TITAN_SOUL
SOUL_ICON = "assets/misc/titansoul.png"  # the green horned helmet, matched in the game by execute-2
SOUL_COST = ("είδαμε μόνο το Titan Soul (το κόκκινο «1» στο κινητό, 30/10)· gold ή άλλα υλικά ίσως από πάνω: "
             "διαβάζονται στο session πριν από το OK")
# How often an item shows up on the Market (the review's words, review/data.py AVAILABILITY)
AVAILABILITY = {
    "common": "βγαίνει συχνά στο Market (κανονικό blueprint)",
    "chest": "βγαίνει αρκετά συχνά στο Market (blueprint από chest)",
    "older-pack": "βγαίνει πιο αραιά στο Market (παλιό pack/event item, και στο Antique Store)",
    "new": "νέο item: ακόμα λίγο στο Market",
    "rare": "πολύ σπάνιο: μόνο από πρόσφατο pack/event",
}


def _json(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except FileNotFoundError:
        return default


def qclass(quality):
    """Quality class of a need: a Legendary item takes Legendary cards only, an Epic one Epic or Legendary."""
    return "Legendary" if quality == "Legendary" else "Epic"


def box(enchant):
    return "element" if enchant.endswith("Element") else "spirit"


def item_key(name, quality):
    return f"item|{name}|{qclass(quality)}"


def enchant_key(name, quality):
    return f"{box(name)}|{name}|{qclass(quality)}"


def pool(key):
    """(stock pool, qualities it takes in order) of an entry: an item's or enchant's Epic+ and Legendary entries share
    one stock (a Legendary need takes Legendary only, an Epic need Epic first); a consumable has one count."""
    if key.startswith("consumable|"):
        return key, ("any",)
    base, q = key.rsplit("|", 1)
    return base, ("Legendary",) if q == "Legendary" else ("Epic", "Legendary")


def signature():
    """mtimes of the source files: the list is rebuilt when one changes."""
    out = []
    for p in SOURCE_FILES:
        try:
            out.append(p.stat().st_mtime_ns)
        except FileNotFoundError:
            out.append(0)
    return out


class Sources:
    def __init__(self):
        self.summary = _json(REVIEWS / "summary.json", {})
        self.plan = _json(ACTIONS / "plan.json", {"steps": []})
        self.inventory = _json(ROSTER / "inventory.json", {"items": [], "enchants": []})
        bp = _json(ROSTER / "blueprints.json", {})
        self.blueprints_at = bp.get("capturedAt")
        self.unlocked = set(bp.get("unlocked") or [])
        self.bp_info = {b["item"]: b for rows in (bp.get("byType") or {}).values() for b in rows}
        self.item_src = _json(DATA / "item_sources.json", {})
        self.items = {it["name"]: it for it in _json(DATA / "items.json", [])}
        self.power = {h["id"]: h.get("power") or h.get("powerShown") for h in self.summary.get("heroes") or []}
        self.power.update({c["id"]: c.get("power") or c.get("powerShown") for c in self.summary.get("champions") or []})
        self.availability = {}
        for st in self.plan.get("steps") or []:
            tgt = st.get("target") or (st.get("after") if isinstance(st.get("after"), dict) else None) or {}
            if st.get("availability") and tgt.get("item"):
                self.availability[tgt["item"]] = st["availability"]
        self.cls = {h["id"]: h.get("class") for h in self.summary.get("heroes") or []}
        self.cls.update({c["id"]: c.get("class") for c in self.summary.get("champions") or []})

    def stamps(self):
        local = [c.get("at") for c in self.inventory.get("localChanges") or [] if c.get("at")]
        return {"review": self.summary.get("generatedAt"), "plan": self.plan.get("generatedAt"),
                "planFromReview": self.plan.get("fromReview"), "inventory": self.inventory.get("capturedAt"),
                "inventoryLocal": max(local) if local else None, "blueprints": self.blueprints_at}

    def item_info(self, name):
        it = self.items.get(name) or {}
        return {"tier": it.get("tier"), "type": it.get("type"), "icon": "/" + it["icon"] if it.get("icon") else None}

    def item_how(self, name):
        """How the owner gets one more of an item: craft (blueprint unlocked; only T13+ of the heroes' types were
        read), else Market, with how often it shows up there as the review rated it (execute's plan carries it)."""
        if name in self.unlocked:
            crafted = (self.bp_info.get(name) or {}).get("amountCrafted")
            return {"kind": "craft", "label": "Craft (έχεις το blueprint)",
                    "detail": f"το έχεις φτιάξει {crafted} φορές" if crafted else "blueprint ξεκλείδωτο"}
        av = self.availability.get(name)
        src = self.item_src.get(name) or {}
        origin = []
        if src.get("unlock") and src["unlock"] != "Blacksmith":
            origin.append(src["unlock"])
        if src.get("antiqueTokens"):
            origin.append(f"Antique Store {src['antiqueTokens']} tokens")
        detail = AVAILABILITY.get(av, "Market (από άλλους παίκτες)") + (f" · {', '.join(origin)}" if origin else "")
        if av == "rare":
            return {"kind": "special", "label": "Σπάνιο — μόνο αν το βρεις", "detail": detail, "availability": av}
        return {"kind": "market", "label": "Market (από άλλους παίκτες)", "detail": detail, "availability": av}

    def enchant_how(self, name):
        """Enchant blueprints were not read from the phone (blueprints.json has gear types only)."""
        src = self.item_src.get(name) or {}
        if src.get("researchScrolls"):
            return {"kind": "enchant", "label": "Craft ή Market",
                    "detail": "κανονικό blueprint (research)· αν δεν το έχεις ξεκλειδώσει, Market"}
        if src.get("unlock"):
            return {"kind": "event", "label": "Chest / event ή Market", "detail": f"από {src['unlock']} · αλλιώς Market"}
        return {"kind": "event", "label": "Event ή Market", "detail": "δεν έχει κανονικό blueprint · αλλιώς Market"}


# ---------------------------------------------------------------- the plan's stock (reservations)

def _move_index(summary):
    """(unit, slot, item) -> the review's move (has enchantQuality: the card each box takes)."""
    out = {}
    for m in (summary.get("allMoves") or []) + (summary.get("championMoves") or []):
        unit = m.get("champion") or m.get("hero")
        out[(unit, m.get("slot"), m.get("item"))] = m
    return out


def _stored(text):
    """'Ultima Deflector (Epic)' -> ('Ultima Deflector', 'Epic')."""
    if not text or not text.endswith(")") or " (" not in text:
        return None, None
    name, q = text[:-1].rsplit(" (", 1)
    return name, q


def _res_class(item_quality, card_quality):
    """Which entry a reserved card counts in: an Epic/Legendary item's own class; a lower item only when it takes an
    Epic+ card (the review gives the lowest card that fits, so then no lower card was left)."""
    if item_quality in EPIC_PLUS:
        return item_quality
    if card_quality in EPIC_PLUS:
        return "Epic"
    return None


def reservations(S):
    """What the plan already takes from storage: open steps of plan.json (heroes) and the champions' moves."""
    moves = _move_index(S.summary)
    out = []

    def add(key, step, unit, slot, label):
        out.append({"id": len(out), "entry": key, "qty": 1, "step": step, "unit": unit, "slot": slot, "label": label})
        return out[-1]["id"]
    by_step = {}
    for st in S.plan.get("steps") or []:
        if st.get("status") in CLOSED:
            continue
        cons = st.get("consumes") or {}
        after = st.get("after") if isinstance(st.get("after"), dict) else {}
        q = after.get("quality")
        ids = []
        name, sq = _stored(cons.get("storedItem"))
        if name and sq in EPIC_PLUS:
            ids.append(add(item_key(name, sq), st["id"], st["hero"], st.get("slot"), f"{st['id']} ({st['hero']})"))
        eq = (moves.get((st["hero"], st.get("slot"), after.get("item"))) or {}).get("enchantQuality") or {}
        for en in cons.get("enchants") or []:
            c = _res_class(q, eq.get(box(en)))
            if c:
                ids.append(add(enchant_key(en, c), st["id"], st["hero"], st.get("slot"), f"{st['id']} ({st['hero']})"))
        by_step[st["id"]] = ids
    by_champ = {}
    for m in S.summary.get("championMoves") or []:
        if m.get("kind") not in ("inventory", "enchant", "craft", "market", "freed") or not m.get("slot"):
            continue
        unit, ids = m.get("champion") or m.get("hero"), []
        eq = m.get("enchantQuality") or {}
        label = f"champion: {unit}"
        if m["kind"] == "inventory" and m.get("quality") in EPIC_PLUS:
            ids.append(add(item_key(m["item"], m["quality"]), None, unit, m["slot"], label))
        for k in ("element", "spirit"):
            if k in eq and m.get(k):
                c = _res_class(m.get("quality"), eq[k])
                if c:
                    ids.append(add(enchant_key(m[k], c), None, unit, m["slot"], label))
        by_champ[(unit, m["slot"])] = ids
    return out, by_step, by_champ


# ---------------------------------------------------------------- groups

def _title(item, quality, tier, element, spirit):
    parts = [f"{item} (T{tier}, {quality})" if tier else f"{item} ({quality})"]
    parts.append(element or "χωρίς element")
    parts.append(spirit or "χωρίς spirit")
    return " · ".join(parts)


def _waits(text):
    """'Leviathan Spirit (Epic+)' -> ('Leviathan Spirit', 'Epic'); '… (Legendary)' -> (…, 'Legendary')."""
    name, _, q = text.rpartition(" (")
    q = q.rstrip(")")
    return (name, "Legendary") if q.startswith("Legendary") else (name, "Epic")


def _group(S, kind, unit, slot, source, change, gain, **kw):
    info = S.item_info(change.get("item")) if change.get("item") else {}
    power = S.power.get(unit)
    g = {"id": None, "unit": unit, "unitKind": kind, "class": S.cls.get(unit), "slot": slot, "source": source,
         "change": dict(change, tier=info.get("tier") or change.get("tier"), icon=info.get("icon")), "gain": gain,
         "gainPct": round(100.0 * gain / power, 2) if power and gain is not None else None, "unitPower": power,
         "steps": [], "needs": [], "notes": [], "gems": 0}
    g.update(kw)
    if change.get("item"):
        g["title"] = _title(change["item"], change.get("quality"), g["change"]["tier"], change.get("element"),
                            change.get("spirit"))
    g["id"] = "/".join(str(x) for x in (unit, slot or "-", change.get("item") or source, change.get("quality") or "",
                                        change.get("kind") or ""))
    return g


def plan_groups(S, res_by_step):
    """Open steps of execute's plan that need something gathered: the item of a craft / Market step, the enchants a
    step waits for (`waitsFor`: the stock has none of the item's quality), a promotion's Titan Soul. Enchants and
    stored items the step takes from storage are reservations (stock lines)."""
    out = []
    for st in S.plan.get("steps") or []:
        if st.get("status") in CLOSED or st.get("phase") in ("seeds", "reroll", "test"):
            continue
        g_all = st.get("gain") if isinstance(st.get("gain"), dict) else {"power": st.get("gain")}
        if st["phase"] == "promotion":
            g = _group(S, "hero", st["hero"], None, "promotion", {"kind": "promotion"}, g_all.get("power"),
                       title=st.get("text") or "Promotion", gems=None)
            g["id"] = f"{st['hero']}/promotion"
            g["steps"] = [st["id"]]
            g["needs"] = [{"entry": SOUL_KEY, "qty": 1, "stock": False}]
            g["change"]["icon"] = _soul_icon()
            g["notes"].append("Κόστος: 1 Titan Soul — " + SOUL_COST)
            out.append(g)
            continue
        tgt = st.get("target") or (st.get("after") if isinstance(st.get("after"), dict) else {}) or {}
        waits = [_waits(w) for w in st.get("waitsFor") or []]
        gather_item = st["phase"] in ("craft", "market") and tgt.get("quality") in EPIC_PLUS
        if not gather_item and not waits:
            continue
        change = {"kind": st.get("kind"), "item": tgt.get("item"), "quality": tgt.get("quality"), "tier": tgt.get("tier"),
                  "element": tgt.get("element"), "spirit": tgt.get("spirit")}
        gain = g_all.get("target", g_all.get("power"))
        g = _group(S, "hero", st["hero"], st.get("slot"), "plan", change, gain, gems=st.get("gems"),
                   nowGain=g_all.get("power") if "target" in g_all else None, status=st.get("status"),
                   availability=st.get("availability"), stepText=st.get("text"))
        g["steps"] = [st["id"]]
        before = st.get("before") or {}
        if before.get("item") and st["phase"] != "enchant":
            g["instead"] = f"{before['item']} ({before.get('quality')})"
        if gather_item:
            g["needs"].append({"entry": item_key(tgt["item"], tgt["quality"]), "qty": 1, "stock": False})
        g["needs"] += [{"entry": e, "qty": 1, "stock": True, "res": rid} for rid, e in res_by_step.get(st["id"], [])]
        g["needs"] += [{"entry": enchant_key(n, q), "qty": 1, "stock": False} for n, q in waits]
        if st.get("dependsOn"):
            g["notes"].append(f"Μετά το βήμα του {st['dependsOn']}")
        if waits and g.get("nowGain") is not None:
            g["notes"].append(f"Χωρίς τα enchants που λείπουν: {_sign(g['nowGain'])} power (τώρα)")
        wtb = g_all.get("withoutTombBound")
        if wtb:
            g["notes"].append(f"Χωρίς Tomb-Bound (με {wtb.get('spirit')}): {_sign(wtb.get('gain'))}")
        alts = st.get("alternatives") or []
        if alts:
            g["alternatives"] = [{"title": a.get("item") or a.get("title"), "gain": a.get("gain"),
                                  "kind": a.get("kind")} for a in alts if isinstance(a, dict)]
        out.append(g)
    return out


def _sign(n):
    return "—" if n is None else ("+" if n >= 0 else "−") + f"{abs(n):,}".replace(",", ".")


def champion_groups(S, res_by_champ):
    """The champions' craft / Market moves and Titan Soul moves (Upgrade Class), the review's; execute's plan has
    heroes only."""
    out = []
    for m in S.summary.get("championMoves") or []:
        if m.get("kind") == "titanSoul":
            unit = m.get("champion") or m.get("hero")
            g = _group(S, "champion", unit, None, "titanSoul", {"kind": "titanSoul"}, m.get("gain"),
                       title="Upgrade Class (Titan Soul)", gems=None)
            g["id"] = f"{unit}/titanSoul"
            g["needs"] = [{"entry": SOUL_KEY, "qty": 1, "stock": False}]
            g["change"]["icon"] = _soul_icon()
            g["notes"].append("Κόστος: 1 Titan Soul (το «+» δίπλα στην κλάση) — " + SOUL_COST)
            g["notes"].append("Κίνηση champion του review· το πλάνο του execute έχει μόνο ήρωες")
            out.append(g)
            continue
        if m.get("kind") not in ("craft", "market") or m.get("quality") not in EPIC_PLUS:
            continue
        unit = m.get("champion") or m.get("hero")
        change = {"kind": m["kind"], "item": m["item"], "quality": m["quality"], "element": m.get("element"),
                  "spirit": m.get("spirit")}
        g = _group(S, "champion", unit, m["slot"], "review", change, m.get("gain"),
                   gems=None if m["kind"] == "market" else m.get("gems"))
        g["needs"].append({"entry": item_key(m["item"], m["quality"]), "qty": 1, "stock": False})
        g["needs"] += [{"entry": e, "qty": 1, "stock": True, "res": rid}
                       for rid, e in res_by_champ.get((unit, m["slot"]), []) if not e.startswith("item|")]
        for k, v in (m.get("enchantsMissing") or {}).items():
            n, q = _waits(v)
            g["needs"].append({"entry": enchant_key(n, q), "qty": 1, "stock": False})
        g["notes"].append("Κίνηση champion του review· το πλάνο του execute έχει μόνο ήρωες")
        out.append(g)
    return out


# ---------------------------------------------------------------- entries, effort, order

def build(S=None):
    S = S or Sources()
    res, res_by_step, res_by_champ = reservations(S)
    res_by_step = {k: [(rid, res[rid]["entry"]) for rid in ids] for k, ids in res_by_step.items()}
    res_by_champ = {k: [(rid, res[rid]["entry"]) for rid in ids] for k, ids in res_by_champ.items()}
    groups = plan_groups(S, res_by_step) + champion_groups(S, res_by_champ)
    by_step = {s: g["id"] for g in groups for s in g["steps"]}
    for g, st in ((g, st) for g in groups for st in S.plan.get("steps") or [] if st.get("id") in g["steps"]):
        dep = st.get("dependsOn")
        dep_id = next((s.get("id") for s in S.plan.get("steps") or []
                       if dep and f"{s.get('hero')} slot {s.get('slot')}" == dep and s.get("status") not in CLOSED), None)
        if dep_id in by_step:
            g["dependsOn"] = by_step[dep_id]
    entries = {}
    for r in res:
        e = _entry(S, entries, r["entry"])
        e["reserved"].append({"step": r["step"], "unit": r["unit"], "slot": r["slot"], "label": r["label"],
                              "qty": r["qty"]})
        e["needed"] += r["qty"]
        if r["step"]:
            e["unlocks"].append(r["step"])
    for g in groups:
        g["effort"] = _effort(S, g)
        g["score"] = (g["gain"] or 0) / max(g["effort"], 0.25)
        g["tier"] = _tier(S, g)
        for ln in g["needs"]:
            if ln["stock"]:
                continue
            e = _entry(S, entries, ln["entry"])
            e["needed"] += ln["qty"]
            e["for"].append({"group": g["id"], "unit": g["unit"], "slot": g["slot"], "qty": ln["qty"],
                             "gain": g["gain"], "steps": g["steps"]})
            e["unlocks"] += g["steps"]
    groups = _ordered(groups)
    rank = {g["id"]: g["rank"] for g in groups}
    souls = [g for g in groups if any(ln["entry"] == SOUL_KEY for ln in g["needs"])]
    for n, g in enumerate(souls, 1):  # each Titan Soul goes to one of these, in this order (best gain first)
        g["soulRank"] = n
    mismatch = owner_tasks(S, entries, groups)
    for e in entries.values():
        e["for"].sort(key=lambda f: rank.get(f["group"], 0))
        e["unlocks"] = sorted(set(e["unlocks"]), key=lambda s: int(s[1:]) if s[1:].isdigit() else 0)
        e["gain"] = sum(f["gain"] or 0 for f in e["for"])
    return {"groups": groups, "entries": entries, "reservations": res, "sources": S.stamps(),
            "ownerTasks": mismatch, "power": power_table(S)}


def power_table(S):
    """Power per hero and champion now and after the whole plan (every move of the review with its target enchants:
    what the bucket list gathers plus what storage already covers), from the review's summary (calc). A promotion
    is measured apart on today's gear (`promotion`, ≈ on top); seeds and rerolls are not in it."""
    rows = []
    for kind, key in (("hero", "heroes"), ("champion", "champions")):
        for h in S.summary.get(key) or []:
            now = h.get("powerShown") or h.get("power")
            gain = (h["afterPlan"] - h["power"]) if h.get("afterPlan") is not None and h.get("power") else None
            rows.append({"unit": h["id"], "kind": kind, "class": h.get("class"), "now": now, "gain": gain,
                         "after": now + gain if gain is not None and now else None,
                         "promotion": h.get("promotionGain") if kind == "hero" and not h.get("promoted") else None,
                         "ceiling": h.get("ceiling"), "afterPct": h.get("afterPlanPct"),
                         "confidence": h.get("confidence")})
    return rows


def owner_tasks(S, entries, groups):
    """execute's `ownerTasks` (plan.json, rebuilt with the plan) is the main list of what the owner gathers: its
    counts are the entries' bucket needs and its `steps` what they unlock. Items: per item and quality, with the steps
    waiting on them. Enchants: per enchant and quality, from the review's enchantsShort, without steps (their unlocks
    come from the steps that wait for them). A count above what the plan's steps add up to is review demand with no
    step yet (`unplanned`): it counts in `needed` and is covered after every group. The champions' needs come on
    top (ownerTasks has heroes only). Returns {used, short: [steps need more than ownerTasks says]}."""
    ot = S.plan.get("ownerTasks")
    if not ot:
        return {"used": False, "short": []}
    rows = {}
    for phase in ("craft", "market"):
        for t in ot.get(phase) or []:
            if t.get("quality") in EPIC_PLUS:
                r = rows.setdefault(item_key(t["item"], t["quality"]), {"count": 0, "steps": [], "gain": 0})
                r["count"] += t.get("count") or 0
                r["steps"] += t.get("steps") or []
                r["gain"] += t.get("gain") or 0
    for t in ot.get("enchants") or []:
        for q, n in (t.get("byQuality") or {}).items():
            if q in EPIC_PLUS:  # the owner's rule: only Epic and Legendary items (and so their cards)
                r = rows.setdefault(enchant_key(t["enchant"], q), {"count": 0, "steps": [], "gain": t.get("gain")})
                r["count"] += n
    planned = {}
    for g in groups:
        if g["source"] == "plan":
            for ln in g["needs"]:
                if not ln["stock"]:
                    planned[ln["entry"]] = planned.get(ln["entry"], 0) + ln["qty"]
    short = []
    for key, r in rows.items():
        e = _entry(S, entries, key)
        e["ownerTasks"] = r
        e["unlocks"] += r["steps"]
        extra = r["count"] - planned.get(key, 0)
        if extra > 0:
            e["unplanned"] = extra
            e["needed"] += extra
        elif extra < 0:
            short.append({"key": key, "ownerTasks": r["count"], "steps": planned.get(key, 0)})
    return {"used": True, "short": short}


def _ordered(groups):
    """Tier (craft first), then gain per effort. An upgrade that builds on another group (same slot, same item,
    better enchants) comes right after it."""
    ids = {g["id"] for g in groups}
    kids = {}
    top = []
    for g in groups:
        if g.get("dependsOn") in ids:
            kids.setdefault(g["dependsOn"], []).append(g)
        else:
            g.pop("dependsOn", None)
            top.append(g)
    top.sort(key=lambda g: (g["tier"], -g["score"], -(g["gain"] or 0)))
    out = []
    for g in top:
        out.append(g)
        for k in sorted(kids.get(g["id"], []), key=lambda k: -k["score"]):
            k["ownTier"], k["tier"] = k["tier"], g["tier"]
            out.append(k)
    for n, g in enumerate(out, 1):
        g["rank"] = n
    return out


def entry_how(S, key):
    """How one more of an entry is got. A Legendary item to craft is luck (the owner's rule: discussed first)."""
    kind, name = key.split("|")[:2]
    if kind == "item":
        how = S.item_how(name)
        if key.endswith("|Legendary") and how["kind"] == "craft":
            how = {"kind": "luck", "label": "Legendary: craft ή fusion με τύχη · ή Market",
                   "detail": how["detail"] + " · μπορεί να βγει Epic: το συζητάμε πριν"}
        return how
    if key == SOUL_KEY:
        return {"kind": "soul", "label": "Titan Soul",
                "detail": "1 για κάθε promotion ήρωα ή Upgrade Class champion · από πού βγαίνει δεν το έχουμε στα "
                          "δεδομένα"}
    how = S.enchant_how(name)
    if key.endswith("|Legendary"):
        how = dict(how, detail="Legendary κάρτα: στο Market τη διαλέγεις, στο craft βγαίνει με τύχη (το συζητάμε) · "
                               + how["detail"])
    return how


def _entry(S, entries, key):
    if key in entries:
        return entries[key]
    kind, name, q = key.split("|", 2) if key.count("|") == 2 else (key.split("|", 1) + [None])
    e = {"key": key, "kind": kind, "name": name, "quality": q, "needed": 0, "reserved": [], "for": [], "unlocks": [],
         "how": entry_how(S, key)}
    if kind == "consumable":
        e["oneEach"] = True  # one per group, the groups in order: not separate shortages
        e["icon"] = _soul_icon() if key == SOUL_KEY else None
    else:
        e.update(S.item_info(name))
    entries[key] = e
    return e


def _soul_icon():
    return "/" + SOUL_ICON if (ROOT / SOUL_ICON).exists() else None


def _effort(S, g):
    total = 0.0
    for ln in g["needs"]:
        if not ln["stock"]:
            how = entry_how(S, ln["entry"])
            w = MARKET_EFFORT.get(how.get("availability"), EFFORT["market"]) if how["kind"] == "market" else \
                EFFORT[how["kind"]]
            total += w * ln["qty"] * (LEGENDARY_EFFORT if ln["entry"].endswith("|Legendary") else 1.0)
    return total


def _tier(S, g):
    kinds = {entry_how(S, ln["entry"])["kind"] for ln in g["needs"] if not ln["stock"]}
    if "soul" in kinds:
        return 4
    if kinds & {"special", "luck"}:
        return 3
    if "market" in kinds:
        return 2
    if kinds & {"enchant", "event"}:
        return 1
    return 0
