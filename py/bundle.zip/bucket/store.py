"""data/bucket/bucket.json: the generated list (bucket/build.py) plus the owner's edits, and the live state the site
and the CLI show (what the phone says the owner has, what remains, which groups are ready).

bucket.json keeps:
- `groups`, `entries`, `reservations`, `sources`, `signature`: rebuilt whenever a source file changed (review,
  execute's plan, inventory, blueprints), or on demand;
- `owner`: {entry key: {needed, neededBase, have, haveAt, done}} — survives every rebuild;
- `changes`: what the last rebuild moved into the plan, finished or dropped.
Every write keeps the previous file in data/bucket/backup/ (the last KEEP_BACKUPS).
"""
import copy
import json
import os
import re
import threading
from datetime import datetime

from . import build

BUCKET = build.DATA / "bucket"
PATH = BUCKET / "bucket.json"
BACKUPS = BUCKET / "backup"
KEEP_BACKUPS = 30
MAX_QTY = 100000
LOCK = threading.RLock()


class EditError(ValueError):
    pass


def now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _time(s):
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S%z")
    except ValueError:
        try:
            return datetime.fromisoformat(s)
        except ValueError:
            return None


def _later(a, b):
    """a is later than b (both ISO times with an offset); unknown counts as not later."""
    ta, tb = _time(a), _time(b)
    return bool(ta and tb and ta > tb)


def _read():
    try:
        return json.loads(PATH.read_text())
    except FileNotFoundError:
        return {"version": 1, "owner": {}}


def _write(doc):
    BUCKET.mkdir(parents=True, exist_ok=True)
    data = json.dumps(doc, ensure_ascii=False, indent=1)
    if PATH.exists():
        old = PATH.read_text()
        if old == data:
            return False
        BACKUPS.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        (BACKUPS / f"bucket-{stamp}.json").write_text(old)
        for p in sorted(BACKUPS.glob("bucket-*.json"))[:-KEEP_BACKUPS]:
            p.unlink()
    tmp = PATH.with_name(PATH.name + ".tmp")
    tmp.write_text(data)
    os.replace(tmp, PATH)
    return True


# ---------------------------------------------------------------- rebuild

def _changes(old_groups, new_groups, plan):
    """Groups that left the list since the last build: done (their step is done), ready in the plan (the step is
    still there but needs nothing more: what it waited for arrived) or dropped (the review no longer asks for it)."""
    new_ids = {g["id"] for g in new_groups}
    steps = plan.get("steps") or []
    out = {"done": [], "inPlan": [], "dropped": []}
    for g in old_groups:
        if g["id"] in new_ids:
            continue
        item = (g.get("change") or {}).get("item")
        rec = {"id": g["id"], "unit": g["unit"], "slot": g.get("slot"), "title": g.get("title"), "gain": g.get("gain")}
        same = [s for s in steps if s.get("id") in (g.get("steps") or []) or
                (s.get("hero") == g["unit"] and s.get("slot") == g.get("slot") and item and
                 (s.get("target") or (s.get("after") if isinstance(s.get("after"), dict) else {}) or {}).get("item") == item)]
        done = [s for s in same if s.get("status") == "done"]
        live = [s for s in same if s.get("status") not in build.CLOSED]
        if live:
            out["inPlan"].append(dict(rec, step=live[0]["id"]))
        elif done:
            out["done"].append(dict(rec, step=done[0]["id"]))
        else:
            out["dropped"].append(rec)
    return out


def regenerate(force=False):
    """Rebuild the generated part when a source changed (or force). The owner's edits are kept as they are;
    an edit of `have` that the phone now confirms (same number, read after the edit) is dropped."""
    with LOCK:
        doc = _read()
        sig = build.signature()
        if not force and doc.get("signature") == sig and doc.get("groups") is not None:
            return doc
        S = build.Sources()
        b = build.build(S)
        owner = doc.get("owner") or {}
        new = {"version": 1, "signature": sig, "sources": b["sources"], "groups": b["groups"],
               "entries": b["entries"], "reservations": b["reservations"], "ownerTasks": b["ownerTasks"],
               "power": b["power"], "owner": owner}
        same = all(new[k] == doc.get(k) for k in ("groups", "entries", "reservations"))
        new["generatedAt"] = doc.get("generatedAt") if same and doc.get("generatedAt") else now()
        ch = _changes(doc.get("groups") or [], b["groups"], S.plan)
        if any(ch.values()):
            new["changes"] = dict(ch, at=new["generatedAt"])
        elif doc.get("changes"):
            new["changes"] = doc["changes"]
        _confirmed_by_phone(new)
        _write(new)
        return new


def _confirmed_by_phone(doc):
    st = _compute(doc)
    inv_at = doc["sources"].get("inventory")
    for key, o in list(doc["owner"].items()):
        e = st["entries"].get(key)
        if e and o.get("have") is not None and e["phone"] == e["have"] and _later(inv_at, o.get("haveAt")):
            for k in ("have", "haveAt", "done"):
                o.pop(k, None)
        if not o:
            doc["owner"].pop(key)


# ---------------------------------------------------------------- live state

def _phone_counts(inv):
    """What storage holds, by name and quality (Epic+ items; every enchant card; an unread count is 1, an unread
    card quality counts as fitting, as in the review), and the consumables of Inventory > Special by name."""
    items, cards = {}, {}
    consumables = {c["name"]: c.get("count") or 0 for c in inv.get("consumables") or [] if c.get("name")}
    for it in inv.get("items") or []:
        q = it.get("quality")
        if q in build.EPIC_PLUS:
            d = items.setdefault(it["item"], {})
            d[q] = d.get(q, 0) + (it.get("count") or 1)
    for c in inv.get("enchants") or []:
        q = c.get("quality") or "Epic"
        d = cards.setdefault(c["item"], {})
        d[q] = d.get(q, 0) + (c.get("count") or 0)
    return items, cards, consumables


def _pool_counts(e, items, cards, consumables):
    if e["kind"] == "consumable":
        return {"any": consumables.get(e["name"], 0)}
    counts = (items if e["kind"] == "item" else cards).get(e["name"], {})
    return {"Epic": counts.get("Epic", 0), "Legendary": counts.get("Legendary", 0)}


LOCAL = re.compile(r"^([+−-])(\d+) (.+?) \((Normal|Superior|Flawless|Epic|Legendary)\)")
LOCAL_PLAIN = re.compile(r"^([+−-])(\d+) (.+)$")


def _local_changes(inv):
    """execute's local edits of inventory.json after each step (`localChanges`: '−1 Leviathan Spirit (Epic)',
    '+1 Serpent Vestment (Epic) στην αποθήκη, …', '−1 Titan Soul …') as (at, step, name, quality, delta); a
    consumable has no quality (None)."""
    names = [c["name"] for c in inv.get("consumables") or [] if c.get("name")]
    out = []
    for c in inv.get("localChanges") or []:
        for t in c.get("changes") or []:
            m = LOCAL.match(t.strip())
            if m:
                n = int(m.group(2)) * (1 if m.group(1) == "+" else -1)
                out.append((c.get("at"), c.get("step"), m.group(3), m.group(4), n))
                continue
            m = LOCAL_PLAIN.match(t.strip())
            name = m and next((x for x in names if m.group(3) == x or m.group(3).startswith(x + " ")), None)
            if name:
                n = int(m.group(2)) * (1 if m.group(1) == "+" else -1)
                out.append((c.get("at"), c.get("step"), name, None, n))
    return out


def _owner_now(key, o, local):
    """The owner's `have`, moved by what executed steps took from (or put back in) storage since he wrote it: the
    phone is reread only at a session's start, in between inventory.json follows the steps."""
    if o.get("have") is None:
        return None, []
    parts = key.split("|")
    name, q = parts[1], parts[2] if len(parts) > 2 else None
    since = [(step, n) for at, step, nm, qq, n in local
             if nm == name and (build.qclass(qq) == q if qq else q is None) and _later(at, o.get("haveAt"))]
    return max(0, o["have"] + sum(n for _, n in since)), since


def _effective_needed(e, o):
    if o.get("needed") is None:
        return e["needed"]
    return max(0, o["needed"] + (e["needed"] - o.get("neededBase", e["needed"])))


def _allocate(doc, pools, owner, order=None):
    """Cover the plan's reservations first, then the groups in `order` (indices; default the list's). Per thing (item
    or enchant name) one pool of phone cards by quality: a Legendary need takes Legendary only, an Epic need Epic
    first, then Legendary. An entry the owner gave a `have` for uses that number instead (its own pool). Returns
    (covered per reservation, missing per group line, assigned per entry, pools left)."""
    pools = copy.deepcopy(pools)
    own = {k: o["have"] for k, o in owner.items() if o.get("have") is not None}
    assigned = {}

    def take(key, qty):
        if key in own:
            got = min(own[key], qty)
            own[key] -= got
        else:
            base, qualities = build.pool(key)
            pool = pools.get(base, {})
            got = 0
            for q in qualities:
                n = min(pool.get(q, 0), qty - got)
                pool[q] = pool.get(q, 0) - n
                got += n
        assigned[key] = assigned.get(key, 0) + got
        return got
    covered = {r["id"]: take(r["entry"], r["qty"]) for r in doc.get("reservations") or []}
    lines = {}
    for gi in (range(len(doc["groups"])) if order is None else order):
        g = doc["groups"][gi]
        for n, ln in enumerate(g["needs"]):
            got = covered.get(ln["res"], 0) if ln["stock"] else take(ln["entry"], ln["qty"])
            lines[(g["id"], n)] = ln["qty"] - got
    for key, e in doc["entries"].items():  # review demand with no plan step yet: last
        if e.get("unplanned"):
            take(key, e["unplanned"])
    return covered, lines, assigned, pools


def _priority(groups, lines):
    """Group indices, biggest win first: power per missing piece (`gain / missing`, the owner's ask: go straight for
    the biggest win). A group with nothing missing comes first, gain ≤ 0 last, a group that builds on another one
    right after it; ties keep the craft-first order (the list's)."""
    def key(i):
        g = groups[i]
        gain = g["gain"] or 0
        miss = sum(lines[(g["id"], n)] for n in range(len(g["needs"])))
        if gain <= 0:
            return (2, -gain, i)
        return (0, -gain, i) if not miss else (1, -gain / miss, i)
    ids = {g["id"]: i for i, g in enumerate(groups)}
    kids, top, out = {}, [], []
    for i, g in enumerate(groups):
        if g.get("dependsOn") in ids:
            kids.setdefault(ids[g["dependsOn"]], []).append(i)
        else:
            top.append(i)

    def put(i):
        out.append(i)
        for k in sorted(kids.get(i, []), key=key):
            put(k)
    for i in sorted(top, key=key):
        put(i)
    return out


def _compute(doc):
    inv = build._json(build.ROSTER / "inventory.json", {"items": [], "enchants": []})
    items, cards, consumables = _phone_counts(inv)
    owner = doc.get("owner") or {}
    inv_at = inv.get("capturedAt")
    pools = {build.pool(e["key"])[0]: _pool_counts(e, items, cards, consumables) for e in doc["entries"].values()}
    local = _local_changes(inv)
    owner_now, moved = {}, {}
    for k, o in owner.items():
        have, since = _owner_now(k, o, local) if "|" in k else (o.get("have"), [])
        owner_now[k] = dict(o, have=have)
        moved[k] = since
    # What the owner has goes to the groups in priority order, and that order depends on what is missing: settle it
    order = list(range(len(doc["groups"])))
    for _ in range(4):
        _, lines, assigned, left = _allocate(doc, pools, owner_now, order)
        prio = _priority(doc["groups"], lines)
        if prio == order:
            break
        order = prio
    _, _, phone_assigned, phone_left = _allocate(doc, pools, {}, order)
    prio_of = {doc["groups"][i]["id"]: n for n, i in enumerate(prio, 1)}

    def with_left(key, got, rest):
        """Cards assigned to the entry plus the ones nobody needed that are of its own quality."""
        base, qualities = build.pool(key)
        extra = rest.get(base, {})
        if qualities == ("any",):
            return got + extra.get("any", 0)
        if key.endswith("|Legendary"):
            return got + extra.get("Legendary", 0)
        mine = got + extra.get("Epic", 0)
        if base + "|Legendary" not in doc["entries"]:
            mine += extra.get("Legendary", 0)
        return mine
    entries = {}
    for e0 in doc["entries"].values():
        e = copy.deepcopy(e0)
        key = e["key"]
        o = owner.get(key) or {}
        e["generatedNeeded"] = e0["needed"]
        e["needed"] = _effective_needed(e0, o)
        e["reservedQty"] = sum(r["qty"] for r in e["reserved"])
        e["phone"] = with_left(key, phone_assigned.get(key, 0), phone_left)
        e["phoneCounts"] = {q: n for q, n in pools[build.pool(key)[0]].items() if n}
        e["owner"] = o
        e["ownerSince"] = [{"step": st, "delta": n} for st, n in moved.get(key, [])]
        if o.get("have") is not None:
            e["have"], e["haveSource"] = owner_now[key]["have"], "owner"
        else:
            e["have"] = with_left(key, assigned.get(key, 0), left) if e["phone"] is not None else 0
            e["haveSource"] = "phone" if e["phone"] is not None else "none"
        e["remaining"] = max(0, e["needed"] - e["have"])
        e["done"] = bool(o.get("done")) and not e["remaining"]
        e["conflict"] = bool(o.get("have") is not None and e["phone"] is not None and e["phone"] != e["have"] and
                             _later(inv_at, o.get("haveAt")))
        e["neededChanged"] = bool(o.get("needed") is not None and o.get("neededBase") != e0["needed"])
        entries[key] = e
    groups = []
    ready_ids = set()
    for g0 in doc["groups"]:
        g = copy.deepcopy(g0)
        for n, ln in enumerate(g["needs"]):
            ln["missing"] = lines[(g["id"], n)]
            e = entries.get(ln["entry"])
            if e:
                ln["name"], ln["kind"], ln["quality"], ln["how"], ln["icon"] = \
                    e["name"], e["kind"], e["quality"], e["how"], e.get("icon")
        g["missing"] = sum(ln["missing"] for ln in g["needs"])
        g["prio"] = prio_of[g["id"]]
        g["perPiece"] = round(g["gain"] / g["missing"]) if g["missing"] and (g["gain"] or 0) > 0 else None
        dep_ok = not g.get("dependsOn") or g["dependsOn"] in ready_ids
        g["ready"] = g["missing"] == 0 and dep_ok
        if g["ready"]:
            ready_ids.add(g["id"])
        g["waitsFor"] = g.get("dependsOn") if g["missing"] == 0 and not dep_ok else None
        groups.append(g)
    # Power an entry unlocks: per group where it is missing, the group's gain × its share of the group's missing
    credit, pieces = {}, {}
    for g in groups:
        for ln in g["needs"]:
            if ln["missing"]:
                pieces[ln["entry"]] = pieces.get(ln["entry"], 0) + ln["missing"]
                credit[ln["entry"]] = credit.get(ln["entry"], 0) + max(0, g["gain"] or 0) * ln["missing"] / g["missing"]
    for k, e in entries.items():
        e["missingPieces"] = pieces.get(k, 0)
        e["unlocksPower"] = round(credit.get(k, 0))
        e["perPiece"] = round(credit[k] / pieces[k]) if pieces.get(k) else None
    for e in entries.values():
        if e.get("oneEach"):  # the Titan Soul: one per use, the uses in the list's order (best gain first)
            e["uses"] = [{"n": g.get("soulRank"), "group": g["id"], "rank": g["rank"], "unit": g["unit"],
                          "unitKind": g["unitKind"], "title": g.get("title"), "gain": g["gain"],
                          "gainPct": g.get("gainPct"), "steps": g["steps"],
                          "covered": not any(ln["missing"] for ln in g["needs"] if ln["entry"] == e["key"]),
                          "ready": g["ready"]}
                         for g in groups if any(ln["entry"] == e["key"] for ln in g["needs"])]
            nxt = next((u for u in e["uses"] if not u["covered"]), None)
            # one soul unlocks one use: «up to» the best next one, not the sum
            e["unlocksPowerAll"] = e["unlocksPower"]
            e["unlocksPower"] = e["perPiece"] = nxt["gain"] if nxt else 0
            e["upTo"] = True
    return {"entries": entries, "groups": groups, "inventoryAt": inv_at}


def state(doc=None):
    """Everything the page and the CLI show. Rebuilds first if a source changed."""
    doc = doc or regenerate()
    st = _compute(doc)
    entries, groups = st["entries"], st["groups"]
    # The Titan Soul is not counted with the things to gather: each soul goes to one of its uses (`souls`)
    rem = [e for e in entries.values() if e["remaining"] and not e.get("oneEach")]
    totals = {"groups": len(groups), "ready": sum(1 for g in groups if g["ready"]),
              "entries": len(entries), "remainingEntries": len(rem),
              "remainingQty": sum(e["remaining"] for e in rem),
              "byHow": {}, "souls": None}
    soul = entries.get(build.SOUL_KEY)
    if soul:
        nxt = next((u for u in soul["uses"] if not u["covered"]), None)
        totals["souls"] = {"key": soul["key"], "have": soul["have"], "uses": len(soul["uses"]),
                           "covered": sum(1 for u in soul["uses"] if u["covered"]), "next": nxt}
    for e in rem:
        k = e["how"]["kind"]
        totals["byHow"][k] = totals["byHow"].get(k, 0) + e["remaining"]
    src = doc.get("sources") or {}
    warnings = []
    if src.get("planFromReview") and src.get("review") and src["planFromReview"] != src["review"]:
        warnings.append(f"Το πλάνο του execute βγήκε από το review των {_hm(src['planFromReview'])}· το review ξανάτρεξε "
                        f"στις {_hm(src['review'])}. Η λίστα θα διορθωθεί μόνη της όταν ξαναφτιαχτεί το πλάνο.")
    ot = doc.get("ownerTasks") or {}
    if not ot.get("used"):
        warnings.append("Το πλάνο του execute δεν έχει ownerTasks: τα σύνολα βγήκαν μόνο από τα βήματά του.")
    for x in ot.get("short") or []:
        e = entries.get(x["key"])
        warnings.append(f"{e['name'] if e else x['key']}: τα βήματα του πλάνου θέλουν {x['steps']}, το ownerTasks "
                        f"γράφει {x['ownerTasks']} — μέτρησα τα βήματα.")
    orphans = [k for k in (doc.get("owner") or {}) if k not in entries]
    return {"generatedAt": doc.get("generatedAt"), "sources": src, "inventoryAt": st["inventoryAt"],
            "groups": groups, "entries": sorted(entries.values(), key=_entry_order), "totals": totals,
            "conflicts": [e["key"] for e in entries.values() if e["conflict"]], "changes": doc.get("changes"),
            "warnings": warnings, "orphanEdits": orphans, "tiers": build.TIERS, "power": doc.get("power") or []}


def _entry_order(e):
    kind_order = {"craft": 0, "enchant": 1, "event": 2, "market": 3, "special": 4, "luck": 5, "soul": 6}
    return (e["remaining"] == 0, kind_order.get(e["how"]["kind"], 9), -(e.get("gain") or 0), e["name"])


def _hm(s):
    t = _time(s)
    return t.strftime("%H:%M") if t else s


# ---------------------------------------------------------------- edits

def _qty(v, field):
    if v is None:
        return None
    if isinstance(v, bool) or not isinstance(v, int):
        raise EditError(f"«{field}»: θέλει ακέραιο αριθμό ή null")
    if not 0 <= v <= MAX_QTY:
        raise EditError(f"«{field}»: από 0 έως {MAX_QTY}")
    return v


def edit(changes):
    """changes: [{key, needed?, have?, done?}] — needed/have: a number, or null to go back to the generated /
    phone value; done: true sets have = needed (false clears it). All or nothing; the previous file is backed up."""
    if isinstance(changes, dict):
        changes = [changes]
    if not isinstance(changes, list) or not changes or len(changes) > 500:
        raise EditError("θέλει μία ή περισσότερες αλλαγές")
    with LOCK:
        doc = regenerate()
        st = _compute(doc)
        owner = copy.deepcopy(doc.get("owner") or {})
        for ch in changes:
            if not isinstance(ch, dict):
                raise EditError("κάθε αλλαγή είναι ένα object")
            extra = set(ch) - {"key", "needed", "have", "done"}
            if extra:
                raise EditError(f"άγνωστα πεδία: {', '.join(sorted(extra))}")
            key = ch.get("key")
            if not isinstance(key, str) or key not in doc["entries"]:
                raise EditError(f"άγνωστο πράγμα «{key}»")
            gen = doc["entries"][key]["needed"]
            o = owner.setdefault(key, {})
            if "needed" in ch:
                v = _qty(ch["needed"], "needed")
                if v is None or v == gen:
                    o.pop("needed", None)
                    o.pop("neededBase", None)
                else:
                    o["needed"], o["neededBase"] = v, gen
            if "have" in ch:
                v = _qty(ch["have"], "have")
                o.pop("done", None)
                if v is None:
                    o.pop("have", None)
                    o.pop("haveAt", None)
                else:
                    o["have"], o["haveAt"] = v, now()
            if "done" in ch:
                if not isinstance(ch["done"], bool):
                    raise EditError("«done»: true ή false")
                if ch["done"]:
                    need = _effective_needed(doc["entries"][key], o)
                    o["have"], o["haveAt"], o["done"] = max(need, st["entries"][key]["have"]), now(), True
                else:
                    for k in ("have", "haveAt", "done"):
                        o.pop(k, None)
            if not o:
                owner.pop(key)
        doc["owner"] = owner
        _write(doc)
        return state(doc)


def resolve(key, use):
    """A manual `have` the phone disagrees with: use="phone" takes the phone's number, use="mine" keeps the owner's
    (until the next phone read)."""
    if use not in ("phone", "mine"):
        raise EditError("«use»: phone ή mine")
    with LOCK:
        doc = regenerate()
        o = (doc.get("owner") or {}).get(key)
        if not o or o.get("have") is None:
            raise EditError(f"δεν υπάρχει δική σου τιμή για «{key}»")
        if use == "phone":
            for k in ("have", "haveAt", "done"):
                o.pop(k, None)
            if not o:
                doc["owner"].pop(key)
        else:
            o["haveAt"] = now()
        _write(doc)
        return state(doc)


def load():
    return regenerate()


def find_key(text, doc=None):
    """An entry key from a key or a name ('Leviathan Spirit', 'leviathan spirit legendary', 'Photon Phaser')."""
    doc = doc or regenerate()
    if text in doc["entries"]:
        return text
    t = text.strip().lower()
    hits = [k for k, e in doc["entries"].items() if e["name"].lower() == t]
    if not hits:
        hits = [k for k, e in doc["entries"].items() if t in (e["name"] + " " + (e["quality"] or "")).lower()]
    if len(hits) > 1:
        legend = [k for k in hits if "legendary" in t and k.endswith("|Legendary")]
        epic = [k for k in hits if "legendary" not in t and k.endswith("|Epic")]
        hits = legend or epic or hits
    return hits[0] if len(hits) == 1 else hits
