"""CLI of the bucket list (README.md here).

.venv/bin/python -m bucket                      rebuild data/bucket/bucket.json, print what is ready and the top 10 to
                                                gather, biggest win first (power per missing piece)
.venv/bin/python -m bucket --craft-first        the same in the old order: craft, enchants, Market, rare, Titan Soul
.venv/bin/python -m bucket "Hero 4"           one hero's / champion's groups
.venv/bin/python -m bucket --entries            what remains to gather, thing by thing (--sort unlocks|unit|missing)
.venv/bin/python -m bucket set "Leviathan Spirit" --have 5      (or --needed N, --done, --undone, --phone)
.venv/bin/python -m bucket resolve "Leviathan Spirit" phone|mine
"""
import argparse
import sys

from . import store

QUAL = {"Epic": "Epic+", "Legendary": "Legendary"}
TIERTAG = {0: "craft", 1: "enchants", 2: "Market", 3: "σπάνιο/τύχη", 4: "Titan Soul"}
HOW = {"craft": "craft", "enchant": "craft/Market", "event": "event/Market", "market": "Market",
       "special": "Antique/pack/event", "luck": "Legendary (τύχη)", "soul": "Titan Soul"}


def gr(n):
    return "—" if n is None else f"{n:,}".replace(",", ".")


def unit_slot(g):
    return f"{g['unit']}" + (f" s{g['slot']}" if g.get("slot") else "")


def line_text(ln):
    q = f" {QUAL.get(ln.get('quality'), '')}" if ln.get("quality") else ""
    mark = "✓" if not ln["missing"] else f"λείπει {ln['missing']}"
    stock = " (κρατημένο από το stock)" if ln["stock"] else ""
    return f"{ln['qty']}× {ln.get('name', ln['entry'])}{q}{stock} — {mark}"


def print_group(g, full=True, craft_first=False):
    flag = "ΕΤΟΙΜΟ" if g["ready"] else f"λείπουν {g['missing']}"
    gems = "" if g.get("gems") == 0 else " ⚠gems?"
    title = g.get("title") or g.get("change", {}).get("kind")
    soul = f"  (Titan Soul #{g['soulRank']})" if g.get("soulRank") else ""
    tier = g.get("ownTier", g["tier"])
    tag = "" if craft_first else f"[{TIERTAG.get(tier, '?')}] "
    per = f" ({gr(g['perPiece'])} ανά κομμάτι)" if g.get("perPiece") and g["missing"] > 1 else ""
    n = g["rank"] if craft_first else g["prio"]
    print(f"  #{n:<3} [{flag}] {tag}{unit_slot(g)}: {title}  +{gr(g['gain'])} power{per}{gems}{soul}")
    if full:
        for ln in g["needs"]:
            print(f"        {line_text(ln)}")
        for n in g.get("notes") or []:
            print(f"        · {n}")


def print_summary(st, top, craft_first=False):
    t = st["totals"]
    src = st["sources"]
    print(f"Bucket list — {t['groups']} ομάδες, {t['ready']} έτοιμες για session · λείπουν {gr(t['remainingQty'])} "
          f"πράγματα σε {t['remainingEntries']} είδη")
    print(f"  review {src.get('review')} · πλάνο {src.get('plan')} · inventory {src.get('inventory')}")
    for w in st["warnings"]:
        print(f"  ⚠ {w}")
    print_souls(st)
    groups = st["groups"] if craft_first else sorted(st["groups"], key=lambda g: g["prio"])
    ready = [g for g in groups if g["ready"]]
    print(f"\nΈτοιμες για session ({len(ready)}):")
    for g in ready:
        print_group(g, full=False, craft_first=craft_first)
    if not ready:
        print("  καμία ακόμα")
    todo = [g for g in groups if not g["ready"]][:top]
    how = "craft πρώτα, μετά enchants, Market, σπάνια, Titan Soul" if craft_first else \
        "μεγαλύτερο κέρδος πρώτα: power ανά κομμάτι που λείπει"
    print(f"\nΤι να μαζέψεις πρώτα — οι {len(todo)} πρώτες ομάδες ({how}):")
    for g in todo:
        print_group(g, craft_first=craft_first)
    if st["conflicts"]:
        print("\nΔιαφορές με το κινητό (διάλεξε στο site ή: python -m bucket resolve <όνομα> phone|mine):")
        ents = {e["key"]: e for e in st["entries"]}
        for k in st["conflicts"]:
            e = ents[k]
            print(f"  {e['name']} {QUAL.get(e['quality'], '')}: δικό σου {e['have']} · κινητό {e['phone']}")
    ch = st.get("changes") or {}
    for key, label in (("done", "Έγιναν"), ("inPlan", "Μπήκαν στο πλάνο"), ("dropped", "Βγήκαν από τη λίστα")):
        if ch.get(key):
            print(f"\n{label} ({ch.get('at')}):")
            for g in ch[key]:
                print(f"  {unit_slot(g)}: {g.get('title')}" + (f" → {g['step']}" if g.get("step") else ""))


def print_souls(st, top=5):
    """The Titan Soul: one entry, each soul to one of its uses in order (best gain first), not separate shortages."""
    ts = st["totals"].get("souls")
    if not ts:
        return
    soul = next(e for e in st["entries"] if e["key"] == ts["key"])
    print(f"\nTitan Soul: έχεις {ts['have']}{'*' if soul['haveSource'] == 'owner' else ''} · {ts['uses']} χρήσεις, "
          f"1 η καθεμία — κάθε soul πάει στην επόμενη της σειράς (καλύτερο κέρδος πρώτα):")
    for u in soul["uses"][:top]:
        mark = "✓ έχει soul" if u["covered"] else "περιμένει"
        print(f"  {u['n']:>2}. {u['unit']}: {u['title']}  +{gr(u['gain'])} power  [{mark}]")
    if len(soul["uses"]) > top:
        rest = soul["uses"][top:]
        print(f"      … και {len(rest)} ακόμα: " + ", ".join(f"{u['unit']} +{gr(u['gain'])}" for u in rest))


SORTS = {"unlocks": "unlocksPower", "unit": "perPiece", "missing": "remaining"}


def print_entries(st, sort="unlocks"):
    """What remains, biggest first by `sort`: unlocks = the power it unlocks (per upgrade waiting for it: its gain ×
    its share of what the upgrade misses; the Titan Soul: up to its best next use), unit = that per piece, missing =
    how many are missing."""
    print(f"{'Τι':40} {'Πώς':18} {'Ξεκλειδώνει':>12} {'ανά κομμάτι':>12} {'Χρειάζεσαι':>10} {'Έχεις':>6} {'Λείπουν':>8}")
    for e in sorted(st["entries"], key=lambda e: -(e.get(SORTS[sort]) or 0)):
        if not e["remaining"]:
            continue
        name = f"{e['name']} {QUAL.get(e['quality'], '')}".strip()
        have = f"{e['have']}{'*' if e['haveSource'] == 'owner' else ''}"
        power = ("έως " if e.get("upTo") else "") + gr(e.get("unlocksPower") or 0)
        per = gr(e["perPiece"]) if e.get("perPiece") else "—"
        print(f"{name[:40]:40} {HOW.get(e['how']['kind'], e['how']['kind']):18} {power:>12} {per:>12} "
              f"{e['needed']:>10} {have:>6} {e['remaining']:>8}")
    print("* = δική σου τιμή (όχι του κινητού) · Titan Soul: «έως» = το επόμενο στη σειρά, ένα soul πάει σε ένα")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m bucket", description="Η bucket list: τι να φτιάξεις ή να αγοράσεις")
    ap.add_argument("args", nargs="*", help="ήρωας/champion, ή: set <όνομα>, resolve <όνομα> phone|mine")
    ap.add_argument("--entries", action="store_true", help="τι λείπει, είδος-είδος")
    ap.add_argument("--top", type=int, default=10, help="πόσες ομάδες να δείξει (10)")
    ap.add_argument("--sort", choices=sorted(SORTS), default="unlocks",
                    help="με --entries: unlocks = power που ξεκλειδώνει (σύνολο), unit = ανά κομμάτι, missing = λείπουν")
    ap.add_argument("--craft-first", action="store_true", help="η παλιά σειρά: craft, enchants, Market, σπάνια, Titan Soul")
    ap.add_argument("--have", type=int)
    ap.add_argument("--needed", type=int)
    ap.add_argument("--done", action="store_true")
    ap.add_argument("--undone", action="store_true")
    ap.add_argument("--phone", action="store_true", help="με set: ξέχνα τη δική σου τιμή «έχεις»")
    a = ap.parse_args(argv)
    if a.args and a.args[0] in ("set", "resolve"):
        if len(a.args) < 2:
            ap.error("θέλει όνομα")
        key = store.find_key(a.args[1])
        if isinstance(key, list):
            print("Βρέθηκαν " + (", ".join(key) if key else "κανένα") + " — γράψε το ακριβές κλειδί.")
            return 1
        try:
            if a.args[0] == "resolve":
                st = store.resolve(key, a.args[2] if len(a.args) > 2 else "")
            else:
                ch = {"key": key}
                if a.have is not None:
                    ch["have"] = a.have
                if a.phone:
                    ch["have"] = None
                if a.needed is not None:
                    ch["needed"] = a.needed
                if a.done or a.undone:
                    ch["done"] = bool(a.done)
                st = store.edit([ch])
        except store.EditError as e:
            print(f"Σφάλμα: {e}")
            return 1
        e = next(x for x in st["entries"] if x["key"] == key)
        print(f"{e['name']} {QUAL.get(e['quality'], '')}: χρειάζεσαι {e['needed']} · έχεις {e['have']} · "
              f"λείπουν {e['remaining']}")
        return 0
    st = store.state(store.regenerate(force=True))
    if a.entries:
        print_entries(st, a.sort)
        return 0
    if a.args:
        who = " ".join(a.args).lower()
        gs = [g for g in st["groups"] if g["unit"].lower() == who or g["unit"].lower().startswith(who + " ")]
        if not gs:
            print(f"Καμία ομάδα για «{' '.join(a.args)}».")
            return 1
        for g in (gs if a.craft_first else sorted(gs, key=lambda g: g["prio"])):
            print_group(g, craft_first=a.craft_first)
        return 0
    print_summary(st, a.top, a.craft_first)
    return 0


if __name__ == "__main__":
    sys.exit(main())
