"""Champions on the site (session `champions`, item 11 of PLAN.md). Loaded by web/server.py from web/ext/.

KINDS["champion"]: the 11 champions from data/roster/champions/*.json, with the same detail fields as a hero where
they apply (stats{order, shown}, slots[] in the hero slot format, raw, calc) plus `champion`: rank, Titan Soul, card,
leader skill (every tier, its party effects), element from the rank, seeds, next power-up, as calc computes them.
The page is web/ext/champions.js (ST.registerKind("champion", …)).
"""
import copy
import json

import calcbridge  # web/ is on sys.path (server.py)
import units

c = units.c  # the hero-review helpers (data/*.json)
SLOT_TYPES = {"slot1": ["Familiar"], "slot2": ["Aurasong"]}


def champions():
    folder = units.ROSTER / "champions"
    out = {}
    for f in sorted(folder.glob("*.json")):
        ch = json.loads(f.read_text())
        out[ch.get("champion") or f.stem] = ch
    return out


def get_champion(name):
    return champions().get(name)


def list_champions():
    found = champions()
    names = sorted(found, key=lambda n: (found[n].get("order") or 999, n))
    return [{"kind": "champion", "id": n, "name": n, "class": found[n].get("class"), "classIcon": None,
             "level": found[n].get("level"), "source": found[n].get("source")} for n in names], "roster"


def _calc_full(raw):
    """calc.compute for a champion with every field (calcbridge.compute keeps only stats/steps/warnings)."""
    mod, error = calcbridge._module()
    if mod is None:
        return None, error
    try:
        return mod.compute(copy.deepcopy(raw)), None
    except Exception as e:  # shown on the page, the site keeps running
        return None, f"{type(e).__name__}: {e}"


def champion_detail(name):
    ch = get_champion(name)
    if ch is None:
        return None
    full, error = _calc_full(ch)
    element = (ch.get("items") or [{}])[0].get("shown", {}).get("elementType") if ch.get("items") else None
    data = None
    try:
        from calc.champion import champion_data  # noqa: WPS433 (calcbridge put calc on sys.path)
        data = champion_data(ch.get("champion"))
    except Exception:
        pass
    el_name = (data or {}).get("element") or element
    cls = {"name": ch.get("class"), "element": el_name or "", "equipmentSlots": SLOT_TYPES}
    by_slot = {s.get("slot"): s for s in ch.get("items") or []}
    slots = [units.slot_view(by_slot.get(n) or {"slot": n, "unknown": True}, cls) for n in (1, 2)]
    shown = dict(ch.get("stats") or {})
    shown["element"] = ch.get("elementShown")
    info = {}
    if full:
        info = {k: full.get(k) for k in ("rank", "rankPlus", "titanSoul", "titanSoulInferred", "cardLevel", "leader",
                                          "elementFromRank", "elementComputed", "seedsUsed", "seedsInferred",
                                          "nextPowerUp", "check", "classType")}
        info["powerFactor"] = (full.get("extra") or {}).get("powerFactor")
        info["statPower"] = (full.get("extra") or {}).get("statPower")
    notes = []
    if error:
        notes.append(f"Το calc δεν έτρεξε για τον champion: {error}")
    if not isinstance(ch.get("nextPowerUp"), (dict, type(None))):
        notes.append(f"Το «next power up» διαβάστηκε ως κείμενο: «{ch['nextPowerUp']}» (δείχνω του calc).")
    return {
        "kind": "champion", "id": name, "name": name, "source": ch.get("source"), "capturedAt": ch.get("capturedAt"),
        "title": ch.get("class"), "firstName": (data or {}).get("name") or name.split()[0],
        "element": {"name": el_name, "icon": units.asset(f"assets/elements/{el_name.lower()}.png") if el_name else None,
                    "shown": ch.get("elementShown")},
        "classType": (data or {}).get("classType"), "level": ch.get("level"), "rank": ch.get("rank"),
        "cardLevel": ch.get("cardLevel"), "leaderShown": ch.get("leaderSkill"),
        "nextPowerUpShown": ch.get("nextPowerUp"),
        "slots": slots,
        "stats": {"order": units.STAT_ORDER, "shown": shown},
        "champion": info,
        "notes": notes,
        "raw": ch,
    }


KINDS = {"champion": {"label": "Champions", "list": list_champions, "detail": champion_detail, "raw": get_champion}}
