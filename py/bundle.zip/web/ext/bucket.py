"""The bucket list's API (session `bucket`). Loaded by web/server.py from web/ext/; the page is /ext/bucket.html.

GET  /api/bucket              the list with what the phone says the owner has, what remains, ready groups
                              (rebuilt first when the review, execute's plan, inventory or blueprints changed)
POST /api/bucket/edit         {"changes": [{"key", "needed"?, "have"?, "done"?}]} (null = back to generated / phone)
POST /api/bucket/resolve      {"key", "use": "phone" | "mine"}: a manual `have` the phone disagrees with
POST /api/bucket/regenerate   rebuild now
Every save validates the input and keeps the previous bucket.json in data/bucket/backup/. A change to bucket/*.py
is picked up on the next request (reload); a change to this file needs a server restart.
"""
import importlib
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import bucket.build  # noqa: E402
import bucket.store  # noqa: E402

_PKG = ROOT / "bucket"
_seen = {}
_reload_lock = threading.Lock()


def _store():
    """bucket/ reloaded when one of its .py files changed, so a change there needs no server restart."""
    with _reload_lock:
        now = {p.name: p.stat().st_mtime_ns for p in _PKG.glob("*.py")}
        if _seen and now != _seen:
            importlib.reload(bucket.build)
            importlib.reload(bucket.store)
        _seen.clear()
        _seen.update(now)
    return bucket.store


def get_bucket(req):
    return 200, _store().state()


def post_edit(req):
    store = _store()
    body = req.body if isinstance(req.body, dict) else {}
    changes = body.get("changes", body if "key" in body else None)
    try:
        return 200, store.edit(changes)
    except store.EditError as e:
        return 400, {"error": str(e)}


def post_resolve(req):
    store = _store()
    body = req.body if isinstance(req.body, dict) else {}
    try:
        return 200, store.resolve(body.get("key"), body.get("use"))
    except store.EditError as e:
        return 400, {"error": str(e)}


def post_regenerate(req):
    store = _store()
    return 200, store.state(store.regenerate(force=True))


ROUTES = [
    ("GET", "/api/bucket", get_bucket),
    ("POST", "/api/bucket/edit", post_edit),
    ("POST", "/api/bucket/resolve", post_resolve),
    ("POST", "/api/bucket/regenerate", post_regenerate),
]
