"""The review panel's API (session `review`, item 7 of PLAN.md). Loaded by web/server.py from web/ext/.

GET  /api/review/summary                      data/reviews/summary.json (top moves, craft, Market, dice)
GET  /api/review/<kind>/<id>                  data/reviews/<id>.json + whether the roster changed since
GET  /api/review/<kind>/<id>/options?slot=N   what slot N can take: items (with source), qualities, elements, spirits
POST /api/review/<kind>/<id>/diff             {"changes": [...]} → calc.diff (same as /api/unit/…/diff, trimmed)
POST /api/review/run                          re-run `python -m review` (~10 s) after a roster sync
GET  /api/review/rerolls                      data/reviews/rerolls.json (the reroll plan)
POST /api/review/rerolls/run                  re-plan the rerolls after a roll was logged (~2 s)
"""
import json
import subprocess
import sys
from pathlib import Path

import calcbridge  # web/ is on sys.path (server.py)
import units

ROOT = Path(__file__).resolve().parents[2]
REVIEWS = ROOT / "data" / "reviews"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from review import data as D  # noqa: E402  (read-only helpers: item sources, stock, enchant names)

QUALITIES = ["Normal", "Superior", "Flawless", "Epic", "Legendary"]
COMBAT_SPIRITS = set(D.SPIRITS) | {"Shark Spirit", "Dinosaur Spirit", "Spirit Spirit", "Krampus Spirit",
                                   "Christmas Spirit", "Tiger Spirit", "Walrus Spirit", "Mundra's Spirit"}


def _json(path):
    return json.loads(path.read_text()) if path.exists() else None


def _raw(kind, uid):
    spec = units.KINDS.get(kind)
    return spec["raw"](uid) if spec else None


def get_review(kind, uid):
    r = _json(REVIEWS / "champions" / f"{uid}.json") if kind == "champion" else _json(REVIEWS / f"{uid}.json")
    if r is None:
        return 404, {"error": f"δεν υπάρχει review για «{uid}» — τρέξε .venv/bin/python -m review"}
    raw = _raw(kind, uid) or {}
    r["stale"] = bool(raw.get("capturedAt") and r.get("capturedAt") and raw["capturedAt"] != r["capturedAt"])
    return 200, r


def options(kind, uid, slot):
    raw = _raw(kind, uid)
    if raw is None:
        return 404, {"error": f"δεν βρέθηκε {kind} «{uid}»"}
    if kind == "champion":  # slot 1 Familiar, slot 2 Aurasong; the champion's element; Titan Spirit with a Titan Soul
        from calc.champion import champion_data
        saved = _json(REVIEWS / "champions" / f"{uid}.json") or {}
        cls = {"name": uid, "element": champion_data(uid)["element"], "isPromoted": bool(saved.get("titanSoul")),
               "equipmentSlots": {"slot1": ["Familiar"], "slot2": ["Aurasong"]}}
        raw = dict(raw, slots=raw.get("items") or [])
    else:
        cls = D.hr.fuzzy(raw["class"], D.hr.classes(), "class")
    top = raw.get("maxEquipmentTier") or D.hr.max_item_tier(raw.get("level") or 40)
    owned = {}
    for e in D.inventory_items():
        owned.setdefault(e["item"], []).append(e["quality"])
    items = []
    for it in D.hr.items():
        if it["type"] in ("Element", "Spirit") or it["tier"] > top or not D.hr.item_fits(cls, slot, it):
            continue
        if it["tier"] < top - 3 and it["name"] not in owned:
            continue
        src = {"kind": "inventory", "rank": 1, "label": "Στην αποθήκη σου", "detail": ", ".join(owned[it["name"]])} \
            if it["name"] in owned else D.item_source(it["name"])
        bel, bsp = D.built_in(it)
        items.append({"name": it["name"], "tier": it["tier"], "type": it["type"], "icon": "/" + it["icon"] if it.get("icon") else None,
                      "source": src, "owned": owned.get(it["name"], []), "builtInElement": bel, "builtInSpirit": bsp,
                      "affinity": {"elements": D.hr.item_affinity_elements(it), "spirit": D.affinity_spirit(it)},
                      "stats": it.get("stats") or {}})
    items.sort(key=lambda x: (x["source"]["rank"], -x["tier"], x["name"]))
    stock = D.enchant_stock()
    elements = [{"name": e["name"], "tier": e["tier"], "type": e["elementType"], "amount": e["elementAmount"],
                 "stock": stock.get(e["name"], 0)}
                for e in sorted(D.hr.element_enchants().values(), key=lambda e: (e["elementType"], -e["tier"]))
                if e["tier"] >= 9]
    spirits = [{"name": s["name"], "tier": s["tier"], "effect": s["effect"], "stock": stock.get(s["name"], 0)}
               for s in sorted(D.hr.spirits().values(), key=lambda s: (-s["tier"], s["name"]))
               if s["name"] in COMBAT_SPIRITS and (s["tier"] >= 9 or stock.get(s["name"], 0))]
    cur = next((s for s in raw.get("slots") or [] if s.get("slot") == slot), {})
    return 200, {"slot": slot, "types": D.hr.slot_types(cls, slot), "maxTier": top, "items": items,
                 "qualities": QUALITIES, "elements": elements, "spirits": spirits,
                 "classElement": cls["element"], "promoted": bool(cls["isPromoted"]),
                 "current": {k: cur.get(k) for k in ("item", "quality", "element", "spirit")}}


def whatif(kind, uid, changes):
    raw = _raw(kind, uid)
    if raw is None:
        return 404, {"error": f"δεν βρέθηκε {kind} «{uid}»"}
    r = calcbridge.diff(raw, changes)
    if not r.get("available"):
        return 200, r
    keep = ("available", "stats", "before", "delta", "warnings", "skills", "innate", "elementUsed", "slots")
    out = {k: r.get(k) for k in keep}
    worn = D.artifact_slots(raw, changes)
    out["artifacts"] = [{"slot": n, "item": next((c.get("item") for c in changes if c["slot"] == n),
                                                None) or next(s.get("item") for s in raw["slots"] if s.get("slot") == n)}
                        for n in worn]
    out["artifactConflict"] = len(worn) > 1
    return 200, out


def run_review():
    p = subprocess.run([sys.executable, "-m", "review"], cwd=str(ROOT), capture_output=True, text=True, timeout=600)
    tail = (p.stdout or "").strip().splitlines()[:1] + (p.stderr or "").strip().splitlines()[-5:]
    return (200 if p.returncode == 0 else 500), {"ok": p.returncode == 0, "output": "\n".join(tail)}


def handle(req):
    parts = req.parts[2:]  # after api/review
    if req.method == "GET" and parts == ["summary"]:
        s = _json(REVIEWS / "summary.json")
        return (200, s) if s else (404, {"error": "δεν υπάρχει summary — τρέξε .venv/bin/python -m review"})
    if req.method == "POST" and parts == ["run"]:
        return run_review()
    if req.method == "GET" and parts == ["rerolls"]:
        r = _json(REVIEWS / "rerolls.json")
        return (200, r) if r else (404, {"error": "δεν υπάρχει rerolls.json — τρέξε .venv/bin/python -m review.rerolls"})
    if req.method == "POST" and parts == ["rerolls", "run"]:  # after logging a roll in data/actions/rolls.json
        p = subprocess.run([sys.executable, "-m", "review.rerolls"], cwd=str(ROOT), capture_output=True, text=True, timeout=300)
        return (200 if p.returncode == 0 else 500), {"ok": p.returncode == 0, "output": (p.stdout or p.stderr)[-2000:]}
    if len(parts) < 2:
        return 404, {"error": "χρειάζεται /api/review/<kind>/<id>"}
    kind, uid, rest = parts[0], parts[1], parts[2:]
    if req.method == "GET" and not rest:
        return get_review(kind, uid)
    if req.method == "GET" and rest == ["options"]:
        try:
            slot = int((req.query.get("slot") or ["1"])[0])
        except ValueError:
            return 400, {"error": "slot: αριθμός 1–6"}
        return options(kind, uid, slot)
    if req.method == "POST" and rest == ["diff"]:
        return whatif(kind, uid, (req.body or {}).get("changes") or [])
    return 404, {"error": "άγνωστη διαδρομή"}


ROUTES = [("GET", "/api/review/", handle), ("POST", "/api/review/", handle)]
