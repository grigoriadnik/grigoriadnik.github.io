"""Public site only (public/build.py): the account page in the header."""
NAV = [{"id": "account", "label": "Λογαριασμός", "href": "/account/", "order": 5}]
