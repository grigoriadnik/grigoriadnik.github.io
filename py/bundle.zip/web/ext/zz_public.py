"""Public site only (public/build.py): the account page in the header."""
NAV = [{"id": "account", "label": "Account", "href": "/account/", "order": 5},
       {"id": "guide", "label": "Guide", "href": "/guide/", "order": 90}]
