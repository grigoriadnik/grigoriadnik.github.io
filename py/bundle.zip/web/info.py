"""What a name's popup on the site says: an item, spirit, element, skill, or the skill an item carries itself, found
by any name the pages print (any skill tier's name, "Behemoth Spirit", "Ultima Deflector (Epic)", "T14 Avatar").

GET /api/info-names -> the names the page turns into links (web/static/info.js) and the phrases that must not link.
GET /api/info/<name>[?kind=…] -> {query, name, matchedBy, entries: [{kind: item|spirit|element|skill|itemSkill, …}]}.
An enchant's short name ("Apotheosis", "Leviathan", as the review prints them) finds it too, ahead of anything
else of that name. Pack, chest and item-type names stop a name inside them from linking ("Platinum Chest").
Game data is re-read when its files change and the owner's account (storage, blueprints, what the heroes wear) on
every change of data/roster/, so neither needs a restart. Stats per quality are the item's base x the quality
multiplier of the hero-review helpers, rounded half up (calc's rule); EVA and crit chance do not scale.
"""
import collections
import difflib
import json
import math
import re
import sys
import threading
from pathlib import Path

import units

ROOT = units.ROOT
DATA = ROOT / "data"
CALC_DATA = ROOT / "calc" / "data"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
c = units.c

try:  # read-only helpers of the review and bucket sessions: how the owner gets an item or an enchant
    from review import data as review_data
except Exception:  # noqa: BLE001  the site still works without them
    review_data = None
try:
    import bucket.build as bucket_build
except Exception:  # noqa: BLE001
    bucket_build = None

SITE = "https://playshoptitans.com"
SCALED = ("attack", "defense", "hp")  # what quality multiplies; EVA and crit are added as they are (calc rules.json)
# Names that are also something else the pages print: no automatic link (data-info="…" still opens them).
NO_AUTO = {"Archmage": "also a class", "Transcendence": "the upgrade's name ('Transcendence II')"}
# Phrases that hold a shorter name and are not that thing (packs, chests and item types are added from the data).
STOP = []
# Consumables the popup can say something about (a link on every page). Any other one in the inventory is found by
# /api/info too, with its count only.
CONSUMABLES = {
    "Titan Soul": {"icon": "assets/misc/titansoul.png",
                   "text": "Χρειάζεται 1 για κάθε promotion ήρωα και για κάθε Upgrade Class champion."},
}
# An enchant's short name that is a common word on the pages: never an alias.
NO_ALIAS = {"Spirit", "Light"}
GAME_FILES = [DATA / "items.json", DATA / "spirit_effects.json", DATA / "skills.json", DATA / "lookups.json",
              DATA / "classes.json", DATA / "item_sources.json", CALC_DATA / "official_items.json",
              CALC_DATA / "item_skills.json", DATA / "quests.json"]


def _read(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return default


class Cached:
    """A value rebuilt when one of its files changes (mtime): a data refresh or a roster sync needs no restart."""

    def __init__(self, files, build):
        self.files, self.build = files, build
        self.sig, self.value = None, None
        self.lock = threading.Lock()

    def get(self):
        sig = []
        for p in self.files():
            try:
                sig.append((str(p), p.stat().st_mtime_ns))
            except OSError:
                sig.append((str(p), 0))
        with self.lock:
            if sig != self.sig:
                self.value, self.sig = self.build(), sig
            return self.value


def norm(name):
    return re.sub(r"\s+", " ", (name or "").replace("’", "'").replace(" ", " ")).strip().lower()


def half_up(x):
    return int(math.floor(x + 0.5))


# ---------------------------------------------------------------- game data

def _official_url(uid, code):
    if not code:
        return None
    if code == "z":
        cat = "enchantments"
    elif code in ("xu", "xm"):
        cat = "stones"
    elif code[0] == "w":
        cat = "weapons"
    elif code[0] in "abgh":
        cat = "armor"
    else:
        cat = "accessories"
    return f"{SITE}/blueprints/{cat}/{code}/{uid}"


def _build_game():
    items = _read(DATA / "items.json", [])
    official = (_read(CALC_DATA / "official_items.json", {}) or {}).get("items") or {}
    item_skills = (_read(CALC_DATA / "item_skills.json", {}) or {}).get("skills") or {}
    lookups = _read(DATA / "lookups.json", {}) or {}
    spirits = {s["name"]: s for s in _read(DATA / "spirit_effects.json", [])}
    spirit_uid = {s["uid"]: s["name"] for s in spirits.values()}
    etypes = {t["key"]: t for t in lookups.get("elementTypes") or []}
    enchants = {}
    for t in etypes.values():
        for e in t.get("enchantments") or []:
            enchants[e["name"]] = dict(e, elementType=t["key"], elementName=t["name"], typeIcon=t.get("image"))
    enchant_key = {e["key"]: e["name"] for e in enchants.values()}
    type_names = {t["key"]: t["name"] for t in lookups.get("itemTypes") or []}
    skills = {s["name"]: s for s in _read(DATA / "skills.json", [])}

    g = {"items": {}, "official": official, "itemSkills": item_skills, "spirits": spirits, "spiritUid": spirit_uid,
         "etypes": etypes, "enchants": enchants, "enchantKey": enchant_key, "typeNames": type_names,
         "skills": skills, "byName": collections.defaultdict(list), "display": {}, "skillItems": {},
         "spiritAffinity": collections.defaultdict(list)}

    def add(name, kind, key, first=False):
        k = norm(name)
        g["display"].setdefault(k, name)
        if (kind, key) not in g["byName"][k]:
            g["byName"][k].insert(0 if first else len(g["byName"][k]), (kind, key))

    for it in items:
        g["items"][it["name"]] = it
        kind = {"Spirit": "spirit", "Element": "element"}.get(it["type"], "item")
        add(it["name"], kind, it["name"])
        sp = (it.get("affinity") or {}).get("spirit")
        if kind == "item" and sp in spirit_uid:
            g["spiritAffinity"][spirit_uid[sp]].append(it["name"])
        skill = (official.get(it["uid"]) or {}).get("skill")
        if skill in item_skills:
            g["skillItems"].setdefault(skill, []).append(it["name"])
    for name in spirits:
        add(name, "spirit", name)
    for name in enchants:
        add(name, "element", name)
    for s in skills.values():
        for t in s["tiers"]:
            add(t["name"], "skill", s["name"])
    for key, sk in item_skills.items():
        add(sk["name"], "itemSkill", key)
    for name in CONSUMABLES:
        add(name, "consumable", name)
    classes = [cl["name"] for cl in _read(DATA / "classes.json", [])]
    words = NO_ALIAS | set(classes) | {t["name"] for t in etypes.values()}
    for kind, table, suffix in (("spirit", spirits, " Spirit"), ("element", enchants, " Element")):
        for name in table:
            short = name[:-len(suffix)] if name.endswith(suffix) else None
            if short and short not in words:
                add(short, kind, name, first=True)

    g["linkNames"] = sorted((n for n in g["display"].values() if n not in NO_AUTO), key=norm)
    stop = set(classes) | set(NO_AUTO) | set(STOP) | set(type_names.values())
    stop |= {v["unlock"] for v in (_read(DATA / "item_sources.json", {}) or {}).values() if v.get("unlock")}
    for rows in ((_read(units.ROSTER / "blueprints.json", {}) or {}).get("byType") or {}).values():
        for b in rows:
            stop |= set(re.findall(r"((?:[A-Z][\w'-]* )+Chest)\b", b.get("how") or ""))
    quests = _read(DATA / "quests.json", {}) or {}
    stop |= {q.get("name") for q in (quests.values() if isinstance(quests, dict) else quests)
             if isinstance(q, dict) and q.get("name")}
    g["stop"] = sorted(n for n in stop if n and (n in NO_AUTO or norm(n) not in g["byName"]))
    return g


GAME = Cached(lambda: GAME_FILES, _build_game)


# ---------------------------------------------------------------- the owner's account

def _roster_files():
    r = units.ROSTER
    return [r / "inventory.json", r / "blueprints.json"] + sorted((r / "heroes").glob("*.json")) + \
        sorted((r / "champions").glob("*.json"))


def _build_roster():
    r = units.ROSTER
    inv = _read(r / "inventory.json", {}) or {}
    bp = _read(r / "blueprints.json", {}) or {}
    stored = collections.defaultdict(list)
    for it in inv.get("items") or []:
        stored[it["item"]].append({"quality": it.get("quality"), "count": it.get("count"),
                                   "element": it.get("element"), "spirit": it.get("spirit")})
    cards = collections.defaultdict(collections.Counter)
    for e in inv.get("enchants") or []:
        cards[e["item"]][e.get("quality") or "?"] += e.get("count") or 0
    worn = collections.defaultdict(list)
    for kind, folder, key, slots in (("hero", "heroes", "hero", "slots"), ("champion", "champions", "champion", "items")):
        for p in sorted((r / folder).glob("*.json"), key=lambda p: units.natural_key(p.stem)):
            u = _read(p, {}) or {}
            for s in u.get(slots) or []:
                for part in ("item", "element", "spirit"):
                    if s.get(part):
                        worn[s[part]].append({"unit": u.get(key) or p.stem, "kind": kind, "slot": s.get("slot"),
                                              "as": part, "quality": s.get("quality") if part == "item" else None})
    info = {b["item"]: b for rows in (bp.get("byType") or {}).values() for b in rows}
    consumables = {norm(c["name"]): c for c in inv.get("consumables") or [] if c.get("name")}
    unit_kinds = {p.stem: kind for kind, folder in (("hero", "heroes"), ("champion", "champions"))
                  for p in (r / folder).glob("*.json")}
    return {"stored": stored, "cards": cards, "worn": worn, "inventoryAt": inv.get("capturedAt"),
            "consumables": consumables, "unitKinds": unit_kinds,
            "unlocked": set(bp.get("unlocked") or []), "bpInfo": info, "bpTypes": set(bp.get("byType") or {}),
            "bpMinTier": bp.get("minTier"), "blueprintsAt": bp.get("capturedAt"), "rosterPath": str(r)}


ROSTER = Cached(_roster_files, _build_roster)
BUCKET = Cached(lambda: [DATA / "bucket" / "bucket.json"], lambda: _read(DATA / "bucket" / "bucket.json", {}) or {})
_bp_seen = []


def _how_item(name):
    if review_data is None:
        return None
    try:
        sig = (units.ROSTER / "blueprints.json").stat().st_mtime_ns
    except OSError:
        sig = 0
    if _bp_seen != [sig]:  # review.data caches the blueprints for its run; the site lives longer
        review_data.blueprints.cache_clear()
        _bp_seen[:] = [sig]
    try:
        how = review_data.item_source(name)
    except Exception:  # noqa: BLE001
        return None
    return {"kind": how.get("kind"), "label": how.get("label"), "detail": how.get("detail")}


def _how_enchant(name):
    if bucket_build is None:
        return None
    try:
        how = bucket_build.Sources().enchant_how(name)
    except Exception:  # noqa: BLE001
        return None
    return {"kind": how.get("kind"), "label": how.get("label"), "detail": how.get("detail")}


def _owned(name, R, enchant):
    """In storage (a count the phone could not read is null: at least one) and who wears it, one row per unit."""
    worn = collections.OrderedDict()
    for w in R["worn"].get(name, []):
        row = worn.setdefault((w["kind"], w["unit"]), {"unit": w["unit"], "kind": w["kind"], "slots": [],
                                                       "qualities": []})
        row["slots"].append(w["slot"])
        if w["quality"] and w["quality"] not in row["qualities"]:
            row["qualities"].append(w["quality"])
    out = {"worn": list(worn.values()), "inventoryAt": R["inventoryAt"]}
    if enchant:
        cnt = R["cards"].get(name) or {}
        order = ["Legendary", "Epic", "Flawless", "Superior", "Normal", "?"]
        out["cards"] = [{"quality": q, "count": cnt[q]} for q in order if cnt.get(q)]
        out["total"] = sum(cnt.values())
    else:
        out["stored"] = [s for s in R["stored"].get(name, []) if s["count"] != 0]
    return out


def _blueprint(it, R):
    name = it["name"]
    if name in R["unlocked"]:
        crafted = (R["bpInfo"].get(name) or {}).get("amountCrafted")
        return {"state": "unlocked", "crafted": crafted}
    rec = R["bpInfo"].get(name)
    if rec is not None:
        return {"state": "locked", "how": (rec.get("how") or "").strip() or None}
    if it["type"] in R["bpTypes"] and (it.get("tier") or 0) >= (R["bpMinTier"] or 0):
        return {"state": "unknown", "why": "δεν φάνηκε όταν διαβάστηκαν τα blueprints"}
    return {"state": "unknown", "why": f"διαβάστηκαν μόνο T{R['bpMinTier'] or 13}+ των τύπων που φορούν οι ήρωες"}


# ---------------------------------------------------------------- entries

def _icon(path):
    return "/" + path if path else None


GAME_STAT = {"atk": "ATK", "def": "DEF", "hp": "HP", "eva": "EVA", "crit": "Crit"}


def _transcendence(steps):
    """The three transcendence levels: ['def+6', 'atk+3', 'baseStats*1.10'] -> ['I: +6 DEF', 'II: +3 ATK', 'III: …']."""
    out = []
    for n, s in enumerate(steps or []):
        m = re.fullmatch(r"(atk|def|hp|eva|crit)\+([\d.]+)", s)
        b = re.fullmatch(r"baseStats\*([\d.]+)", s)
        text = f"+{m.group(2)} {GAME_STAT[m.group(1)]}" if m else f"base stats ×{float(b.group(1)):g}" if b else s
        out.append(f"{('I', 'II', 'III', 'IV')[min(n, 3)]}: {text}")
    return out


def _element_chip(G, key):
    t = G["etypes"].get(key)
    return {"key": key, "name": t["name"] if t else key.title(), "icon": _icon(t.get("image")) if t else None}


def item_entry(G, R, it):
    stats = it.get("stats") or {}
    off = G["official"].get(it["uid"]) or {}
    scaled = {k: v for k, v in stats.items() if k in SCALED}
    by_quality = [{"quality": q, "mult": m, "stats": {k: half_up(v * m) for k, v in scaled.items()}}
                  for q, m in c.QUALITY.items()] if scaled else []
    aff = it.get("affinity") or {}
    els = aff.get("element")
    els = [els] if isinstance(els, str) else list(els or [])
    inn = it.get("innate") or {}
    skill = G["itemSkills"].get(off.get("skill")) if off.get("skill") else None
    boost = it.get("starforgeStatBoost")
    return {
        "kind": "item", "name": it["name"], "uid": it["uid"], "tier": it.get("tier"), "type": it.get("type"),
        "subTypes": [G["typeNames"].get(t, t) for t in it.get("subTypes") or []],
        "icon": _icon(it.get("icon")), "stats": stats, "byQuality": by_quality,
        "flat": {k: v for k, v in stats.items() if k not in SCALED},
        "affinity": {"elements": [_element_chip(G, e) for e in els],
                     "spirit": G["spiritUid"].get(aff.get("spirit"))},
        "innate": {"element": G["enchantKey"].get(inn.get("element")), "spirit": G["spiritUid"].get(inn.get("spirit"))},
        "skill": {"name": skill["name"], "effect": skill.get("effect")} if skill else None,
        "starforge": f"{float(boost):g}" if boost else None,
        "transcendence": _transcendence(it.get("transcendence")),
        "how": _how_item(it["name"]), "blueprint": _blueprint(it, R), "owned": _owned(it["name"], R, False),
        "official": _official_url(it["uid"], off.get("type")), "releaseAt": off.get("releaseAt"),
        "origin": off.get("excl"),
    }


def spirit_entry(G, R, name):
    s = G["spirits"].get(name) or {}
    it = G["items"].get(name) or {}
    uid = s.get("uid") or it.get("uid")
    off = G["official"].get(uid) or {}
    return {
        "kind": "spirit", "name": name, "uid": uid, "tier": s.get("tier") or it.get("tier"),
        "icon": _icon(s.get("icon") or it.get("icon")), "effect": s.get("effect"),
        "effectWithAffinity": s.get("effectWithAffinity"), "stats": s.get("stats") or it.get("stats") or {},
        "affinityItems": sorted(G["spiritAffinity"].get(name, []),
                                key=lambda n: (-(G["items"][n].get("tier") or 0), n)),
        "how": _how_enchant(name), "owned": _owned(name, R, True),
        "official": _official_url(uid, off.get("type")), "releaseAt": off.get("releaseAt"),
    }


def element_entry(G, R, name):
    e = G["enchants"].get(name) or {}
    it = G["items"].get(name) or {}
    uid = e.get("key") or it.get("uid")
    off = G["official"].get(uid) or {}
    stats = {s["type"]: s["value"] for s in e.get("stats") or []} or it.get("stats") or {}
    return {
        "kind": "element", "name": name, "uid": uid, "tier": e.get("tier") or it.get("tier"),
        "icon": _icon(it.get("icon") or (f"assets/items/{uid}.png" if uid else None)),
        "element": _element_chip(G, e["elementType"]) if e.get("elementType") else None,
        "amount": e.get("elementAmount"), "stats": stats,
        "how": _how_enchant(name), "owned": _owned(name, R, True),
        "official": _official_url(uid, off.get("type")), "releaseAt": off.get("releaseAt"),
    }


def skill_entry(G, name, matched):
    s = G["skills"][name]
    return {
        "kind": "skill", "name": s["name"], "matched": matched, "rarity": s.get("rarity"),
        "innate": bool(s.get("isInnate")), "classesText": s.get("classesText"), "classes": s.get("classes") or [],
        "icon": _icon(s.get("icon")),
        "tiers": [{"tier": t["tier"], "name": t["name"], "element": t.get("elementThreshold"),
                   "promotion": bool(t.get("requiresPromotion")), "description": t.get("description")}
                  for t in s["tiers"]],
    }


def item_skill_entry(G, key):
    sk = G["itemSkills"][key]
    return {"kind": "itemSkill", "name": sk["name"], "key": key, "effect": sk.get("effect"),
            "items": sorted(G["skillItems"].get(key, []))}


def consumable_entry(R, name):
    """What it is for (when known), how many are in storage and what the bucket list needs them for."""
    known = CONSUMABLES.get(name) or {}
    inv = R["consumables"].get(norm(name)) or {}
    icon = known.get("icon") or f"assets/misc/{re.sub(r'[^a-z0-9]', '', name.lower())}.png"
    entries = BUCKET.get().get("entries") or {}
    rows = entries.values() if isinstance(entries, dict) else entries
    need = next((e for e in rows if e.get("kind") == "consumable" and e.get("name") == name), None) or {}
    return {
        "kind": "consumable", "name": inv.get("name") or name, "text": known.get("text"),
        "icon": _icon(icon) if (ROOT / icon).exists() else None,
        "count": inv.get("count"), "inventoryAt": R["inventoryAt"],
        "needed": need.get("needed"),
        "for": [{"unit": f.get("unit"), "kind": R["unitKinds"].get(f.get("unit"), "hero"), "qty": f.get("qty"),
                 "gain": f.get("gain"), "what": (f.get("group") or "").split("/")[-1] or None}
                for f in need.get("for") or []],
    }


def entry(G, R, kind, key, display):
    if kind == "consumable":
        return consumable_entry(R, key)
    if kind == "item":
        return item_entry(G, R, G["items"][key])
    if kind == "spirit":
        return spirit_entry(G, R, key)
    if kind == "element":
        return element_entry(G, R, key)
    if kind == "skill":
        return skill_entry(G, key, display)
    return item_skill_entry(G, key)


# ---------------------------------------------------------------- lookup

QUALITY_WORDS = r"(?:Normal|Superior|Flawless|Epic|Legendary)"


def _cleaned(q):
    """Variants of a printed name without what pages add: '(Epic)', 'T14', 'Epic ', '×2', a trailing ':'."""
    out = []
    s = q.strip().rstrip(":·,;")
    for pat in (r"\s*\([^)]*\)$", r"^T\d+\s+", r"\s+T\d+$", rf"^{QUALITY_WORDS}\s+", rf"\s+{QUALITY_WORDS}$",
                r"^\d+\s*[×x]\s*", r"\s*[×x]\s*\d+$"):
        s2 = re.sub(pat, "", s, flags=re.I).strip()
        if s2 != s:
            s = s2
            out.append(s)
    return out


def resolve(query, kind=None):
    """(display name, [(kind, key)], matchedBy) or (None, suggestions, None). kind keeps only that kind."""
    G = GAME.get()
    if kind:
        name, found, by = resolve(query)
        if name is not None:
            found = [f for f in found if f[0] == kind] or found
        return name, found, by
    k = norm(query)
    if k in G["byName"]:
        return G["display"][k], G["byName"][k], "exact"
    inv = ROSTER.get()["consumables"].get(k)
    if inv:
        return inv["name"], [("consumable", inv["name"])], "exact"
    for v in _cleaned(query):
        if norm(v) in G["byName"]:
            return G["display"][norm(v)], G["byName"][norm(v)], "cleaned"
    for suffix in (" spirit", " element"):
        if k + suffix in G["byName"]:
            return G["display"][k + suffix], G["byName"][k + suffix], "cleaned"
    close = difflib.get_close_matches(k, list(G["byName"]), n=5, cutoff=0.6)
    if close and difflib.SequenceMatcher(None, k, close[0]).ratio() >= 0.88:
        return G["display"][close[0]], G["byName"][close[0]], "fuzzy"
    return None, [G["display"][n] for n in close], None


def info(query, kind=None):
    name, found, how = resolve(query, kind)
    if name is None:
        return None, found
    G, R = GAME.get(), ROSTER.get()
    return {"query": query, "name": name, "matchedBy": how,
            "entries": [entry(G, R, kind, key, name) for kind, key in found]}, None


def names():
    G = GAME.get()
    return {"names": G["linkNames"], "stop": G["stop"], "noAuto": NO_AUTO}
