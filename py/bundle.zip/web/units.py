"""Heroes (and later champions) for the site: where they come from and the detail view the page shows.

Heroes come from data/roster/heroes/*.json when there are any, otherwise from data/heroes.json (dowob).
A dowob hero takes its slots (and any stats/element shown) from data/gear/<hero name>.json when a review
left one. Names are matched against data/*.json with the hero-review helpers (any tier's skill name works).
No stat arithmetic here: the numbers the game showed are passed through, the calculation is calc's job.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / ".claude" / "skills" / "hero-review" / "scripts"))
import common as c  # noqa: E402

ROSTER = ROOT / "data" / "roster"
GEAR = ROOT / "data" / "gear"

STAT_ORDER = ["attack", "defense", "hp", "evasion", "critChance", "critDamage", "element", "threat", "power"]
SLOTS = range(1, 7)


def set_roster(path):
    """Read the account from another folder (tests, samples)."""
    global ROSTER
    ROSTER = Path(path).resolve()


def lookup(name, table, kind):
    """common.fuzzy without the exit: None when the name matches nothing."""
    try:
        return c.fuzzy(name, table, kind)
    except SystemExit:
        return None


def natural_key(name):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name)]


def asset(path):
    return "/" + path if path else None


# --- where heroes come from -------------------------------------------------------------------------------

def from_dowob(h):
    """A dowob hero in the data/roster/heroes format. dowob keeps 1 for stats nobody entered: those are null."""
    entered = max(h["attack"], h["defense"], h["hp"]) > 1
    cls = c.classes().get(h["heroClass"]["name"].lower()) or {}
    stats = {k: None for k in STAT_ORDER}
    if entered:
        stats.update(attack=h["attack"], defense=h["defense"], hp=h["hp"], evasion=h["evasion"],
                     critChance=h["critChance"], critDamage=float(h["critDamage"]), threat=h["threat"])
    return {
        "hero": h["name"],
        "class": h["heroClass"]["name"],
        "level": h["level"],
        "promoted": cls.get("isPromoted"),
        "seeds": {"hp": h["hpSeeds"], "attack": h["attackSeeds"], "defense": h["defenseSeeds"]} if entered else None,
        "cardLevel": h["cardLevel"],
        "skills": [s["name"] for s in h["skills"]],
        "elementShown": h["element"],
        "stats": stats,
        "slots": [{"slot": n, "unknown": True} for n in SLOTS],
        "capturedAt": None,
        "source": "dowob",
    }


def with_review_gear(hero):
    """Overlay data/gear/<hero name>.json (written by hero-review) on a dowob hero."""
    path = GEAR / f"{hero['hero']}.json"
    if not path.exists():
        return hero
    gear = json.loads(path.read_text())
    hero = dict(hero, gearSource=f"data/gear/{path.name}")
    for key in ("slots", "elementShown", "level", "skills"):
        if gear.get(key):
            hero[key] = gear[key]
    if gear.get("stats"):
        hero["stats"] = dict(hero["stats"], **gear["stats"])
    return hero


def heroes():
    """name -> hero dict (data/roster/heroes format), plus which source they came from."""
    files = sorted((ROSTER / "heroes").glob("*.json"))
    if files:
        out = {}
        for f in files:
            h = json.loads(f.read_text())
            out[h.get("hero") or f.stem] = h
        return out, "roster"
    raw = json.loads((ROOT / "data" / "heroes.json").read_text())
    return {h["name"]: with_review_gear(from_dowob(h)) for h in raw}, "dowob"


def list_heroes():
    found, source = heroes()
    out = []
    for name in sorted(found, key=natural_key):
        h = found[name]
        cls = lookup(h.get("class"), c.classes(), "class") or {}
        out.append({"kind": "hero", "id": name, "name": name, "class": cls.get("name") or h.get("class"),
                    "classIcon": asset(cls.get("icon")), "level": h.get("level"), "source": h.get("source")})
    return out, source


def get_hero(name):
    return heroes()[0].get(name)


# --- the detail view --------------------------------------------------------------------------------------

def skill_info(name):
    """skills.json entry for a T1 name or any tier's name."""
    key = name.strip().lower()
    for s in c.skills().values():
        if any(t["name"].lower() == key for t in s["tiers"]):
            return s
    return lookup(name, c.skills(), "skill")


def skill_view(info, shown_name, cls, element, promoted, innate=False):
    tiers = []
    current = None
    for t in info["tiers"]:
        lock = None
        if t["requiresPromotion"] and not promoted:
            lock = "promotion"
        elif element is None:
            lock = "unknown"
        elif element < t["elementThreshold"]:
            lock = "element"
        tiers.append(dict(t, reached=lock is None, lock=lock))
        if lock is None:
            current = t
    if element is None:
        current = None
    ratings = {}
    for skill_set in cls.get("skillSets") or ["Default"]:
        letter = c.ratings().get(skill_set, {}).get(cls.get("ratingPage"), {}).get(info["name"])
        if letter:
            ratings[skill_set] = letter
    nxt = next((t for t in tiers if not t["reached"]), None)
    return {
        "name": info["name"],
        "shownName": shown_name,
        "icon": asset(info.get("icon")),
        "rarity": info.get("rarity"),
        "innate": innate,
        "tier": current["tier"] if current else None,
        "tierName": current["name"] if current else None,
        "description": current["description"] if current else info["tiers"][0]["description"],
        "rating": ratings.get("Default"),
        "ratings": ratings,
        "tiers": tiers,
        "next": nxt,
    }


def item_type_icons():
    return {t["name"]: asset(t["image"]) for t in c._load("lookups.json")["itemTypes"]}


def spirit_by_uid():
    return {s["uid"]: s for s in c.spirits().values()}


def element_by_key():
    return {e["key"]: e for e in c.element_enchants().values()}


def slot_view(slot, cls):
    n = slot["slot"]
    allowed = c.slot_types(cls, n) if cls else []
    icons = item_type_icons()
    out = {"slot": n, "state": "ok", "allowedTypes": [{"name": t, "icon": icons.get(t)} for t in allowed],
           "item": None, "element": None, "spirit": None,
           "starforged": slot.get("starforged"), "transcendence": slot.get("transcendence")}
    if slot.get("unknown"):
        return dict(out, state="unknown")
    if slot.get("empty") or not slot.get("item"):
        return dict(out, state="empty")

    item = lookup(slot["item"], c.items_by_name(), "item")
    quality = slot.get("quality")
    if item:
        aff = item.get("affinity") or {}
        innate = item.get("innate") or {}
        spirits, elements = spirit_by_uid(), element_by_key()
        aff_spirit = spirits.get(aff.get("spirit") or "")
        innate_element = elements.get(innate.get("element") or "")
        innate_spirit = spirits.get(innate.get("spirit") or "")
        out["item"] = {
            "name": item["name"], "tier": item["tier"], "type": item["type"], "typeIcon": icons.get(item["type"]),
            "icon": asset(item.get("icon")), "stats": item.get("stats") or {},
            "quality": quality, "qualityIcon": quality_icon(quality),
            "fits": c.item_fits(cls, n, item) if cls else None,
            "affinity": {"elements": c.item_affinity_elements(item),
                         "spirit": aff_spirit["name"] if aff_spirit else None},
            "innate": {"element": innate_element["name"] if innate_element else None,
                       "spirit": innate_spirit["name"] if innate_spirit else None},
        }
    else:
        out["item"] = {"name": slot["item"], "notFound": True, "quality": quality, "qualityIcon": quality_icon(quality)}

    if slot.get("element"):
        e = lookup(slot["element"], c.element_enchants(), "element")
        if e:
            aff_elements = out["item"].get("affinity", {}).get("elements", [])
            class_el = (cls.get("element") or "").lower()
            out["element"] = {
                "name": e["name"], "tier": e["tier"], "amount": e["elementAmount"], "type": e["elementType"],
                "icon": asset(f"assets/items/{e['key']}.png"), "typeIcon": asset(f"assets/elements/{e['elementType']}.png"),
                "matchesClass": class_el in ("all", e["elementType"]) or "all" in aff_elements,
                "affinity": e["elementType"] in aff_elements or "all" in aff_elements,
                "stats": {s["type"]: s["value"] for s in e["stats"]},
            }
        else:
            out["element"] = {"name": slot["element"], "notFound": True}

    if slot.get("spirit"):
        s = lookup(slot["spirit"], c.spirits(), "spirit")
        if s:
            item_aff = (item.get("affinity") or {}).get("spirit") if item else None
            matched = item_aff == s["uid"]
            out["spirit"] = {
                "name": s["name"], "tier": s["tier"], "icon": asset(s.get("icon")), "stats": s.get("stats") or {},
                "affinity": matched, "effect": s.get("effect"), "effectWithAffinity": s.get("effectWithAffinity"),
                "activeEffect": s.get("effectWithAffinity") if matched else s.get("effect"),
            }
        else:
            out["spirit"] = {"name": slot["spirit"], "notFound": True}
    return out


def quality_icon(quality):
    q = next((q for q in c._load("lookups.json")["qualities"] if q["name"] == quality), None)
    return asset(q["image"]) if q else None


def hero_detail(name):
    hero = get_hero(name)
    if hero is None:
        return None
    notes = []
    cls = lookup(hero.get("class"), c.classes(), "class")
    if cls is None:
        notes.append(f"Άγνωστη class «{hero.get('class')}».")
        cls = {}
    promoted = bool(cls.get("isPromoted") or hero.get("promoted"))
    promo = c.classes().get((cls.get("promotesTo") or "").lower())
    element = hero.get("elementShown")

    skills = []
    for shown in hero.get("skills") or []:
        info = skill_info(shown)
        if info is None:
            notes.append(f"Άγνωστο skill «{shown}».")
            continue
        skills.append(skill_view(info, shown, cls, element, promoted))
    innate = None
    if cls.get("innate"):
        info = c.skills().get(cls["innate"]["name"].lower()) or dict(cls["innate"], icon=None)
        innate = skill_view(dict(info, tiers=cls["innate"]["tiers"]), cls["innate"]["name"], cls, element,
                            promoted, innate=True)

    thresholds = []
    for s in skills + ([innate] if innate else []):
        for t in s["tiers"]:
            if t["tier"] > 1:
                thresholds.append({"skill": s["name"], "innate": s["innate"], "tier": t["tier"], "tierName": t["name"],
                                   "value": t["elementThreshold"], "requiresPromotion": t["requiresPromotion"],
                                   "reached": t["reached"], "lock": t["lock"]})
    thresholds.sort(key=lambda t: (t["value"], t["skill"]))
    reachable = [t["value"] for t in thresholds if promoted or not t["requiresPromotion"]]

    by_slot = {s.get("slot"): s for s in hero.get("slots") or []}
    slots = [slot_view(by_slot.get(n) or {"slot": n, "unknown": True}, cls) for n in SLOTS]

    shown = dict(hero.get("stats") or {})
    shown.setdefault("element", element)
    if shown.get("element") is None:
        shown["element"] = element

    el_name = (cls.get("element") or "").lower()
    return {
        "kind": "hero",
        "id": name,
        "name": name,
        "source": hero.get("source"),
        "gearSource": hero.get("gearSource"),
        "capturedAt": hero.get("capturedAt"),
        "class": {
            "name": cls.get("name") or hero.get("class"), "type": cls.get("type"), "icon": asset(cls.get("icon")),
            "element": cls.get("element"), "elementIcon": asset(f"assets/elements/{el_name}.png") if el_name else None,
            "isPromoted": cls.get("isPromoted"), "baseClass": cls.get("baseClass"), "isTitan": cls.get("isTitan"),
            "promotesTo": cls.get("promotesTo"), "promotesToIcon": asset(promo["icon"]) if promo else None,
            "skillUnlockLevels": cls.get("skillUnlockLevels"),
        },
        "promoted": promoted,
        "level": hero.get("level"),
        "seeds": hero.get("seeds"),
        "cardLevel": hero.get("cardLevel"),
        "element": {
            "shown": element,
            "thresholds": thresholds,
            "maxNeeded": max(reachable) if reachable else 0,
            "maxNeededAfterPromotion": max([t["value"] for t in thresholds] or [0]),
        },
        "skills": skills,
        "innate": innate,
        "slots": slots,
        "stats": {"order": STAT_ORDER, "shown": shown},
        "notes": notes,
        "raw": hero,
    }


# kind -> how to list and show it. The champions session adds "champion" here (or from a web/ext module).
KINDS = {
    "hero": {"label": "Ήρωες", "list": list_heroes, "detail": hero_detail, "raw": get_hero},
}
