"""What the site shows about the whole account, from the review's output (data/reviews/) and the roster:
the one-line summary of each hero and champion in the dropdown (GET /api/units -> units[].summary).

Files are re-read when they change (a review rerun or a roster sync needs no restart). No arithmetic on stats:
the percentages and ratings are the review's own.
"""
import json
import threading
from pathlib import Path

import units

ROOT = units.ROOT
REVIEWS = ROOT / "data" / "reviews"


def _read(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return default


class Files:
    """JSON files read again only when their mtime changes."""

    def __init__(self):
        self.seen = {}
        self.lock = threading.Lock()

    def get(self, path):
        path = Path(path)
        try:
            mtime = path.stat().st_mtime_ns
        except OSError:
            return None
        with self.lock:
            hit = self.seen.get(path)
            if hit and hit[0] == mtime:
                return hit[1]
        data = _read(path)
        with self.lock:
            self.seen[path] = (mtime, data)
        return data


FILES = Files()


def review(kind, uid):
    return FILES.get(REVIEWS / "champions" / f"{uid}.json" if kind == "champion" else REVIEWS / f"{uid}.json")


def pct_text(v):
    if v is None:
        return None
    return f"{v:.1f}".replace(".", ",") + "%"


def summary(u):
    """{label, pct, ratings, rank} for one /api/units entry. label: 'Hero 21 · Acrobat · L40 · 98,8% · A/S/A/S',
    'Argon and Arnold · Paladin · Rank 11+16 · 85,0%'. The level is shown alone: the data has no max level."""
    r = review(u["kind"], u["id"]) or {}
    score = r.get("score") or {}
    parts = [u["name"]]
    if u.get("class"):
        parts.append(u["class"])
    out = {"pct": score.get("pct"), "afterPlanPct": score.get("afterPlanPct"), "ratings": None, "rank": None}
    if u["kind"] == "champion":
        raw = units.KINDS["champion"]["raw"](u["id"]) or {}
        n, plus = raw.get("rankNumber"), raw.get("rankPlus")
        if n:
            out["rank"] = f"Rank {n}" + (f"+{plus}" if plus else "")
            parts.append(out["rank"])
    elif u.get("level") is not None:
        parts.append(f"L{u['level']}")
    if score.get("pct") is not None:
        parts.append(pct_text(score["pct"]))
    held = sorted((s for s in r.get("skills") or [] if not s.get("innate")),
                  key=lambda s: s.get("skillSlot") or 99)
    if u["kind"] == "hero" and held:
        out["ratings"] = [s.get("rating") or "—" for s in held]
        parts.append("/".join(out["ratings"]))
    out["label"] = " · ".join(parts)
    return out


# ---------------------------------------------------------------- the team page (GET /api/team)

QUALITIES = ["Normal", "Superior", "Flawless", "Epic", "Legendary"]
RATINGS = ["S+", "S", "A", "B", "C", "D"]
CLASS_TYPES = ["Fighter", "Rogue", "Spellcaster"]


def _power(rec):
    return ((rec or {}).get("stats") or {}).get("power")


def team():
    """Everything the «Ομάδα» page draws, from data/reviews/, data/roster/, data/bucket/ and data/actions/before/.
    Power 'now' is the game's number (roster); 'after plan' and the ceiling are the review's (per hero) and the
    bucket's (team total: the open plan, promotions apart)."""
    summary = FILES.get(REVIEWS / "summary.json") or {}
    rerolls = FILES.get(REVIEWS / "rerolls.json") or {}
    bucket = FILES.get(ROOT / "data" / "bucket" / "bucket.json") or {}
    inventory = FILES.get(units.ROSTER / "inventory.json") or {}
    quests = FILES.get(ROOT / "data" / "quests.json") or {}
    roster, source = units.heroes()
    strength = {h["hero"]: h.get("strength") for h in rerolls.get("heroes") or []}
    souls = next((c.get("count") for c in inventory.get("consumables") or [] if c.get("name") == "Titan Soul"), None)

    heroes, ratings, qualities = [], {}, {}
    enchants = {"slots": 0, "noElement": 0, "noSpirit": 0, "empty": 0}
    types, elements, promoted = {}, {}, {"yes": 0, "no": 0}
    before_total = now_total = 0
    for s in summary.get("heroes") or []:
        name = s["id"]
        rec = roster.get(name) or {}
        rv = review("hero", name) or {}
        cls = units.lookup(rec.get("class") or s.get("class"), units.c.classes(), "class") or {}
        before = _power(FILES.get(ROOT / "data" / "actions" / "before" / "heroes" / f"{name}.json"))
        now = _power(rec) or s.get("powerShown")
        if before is not None and now is not None:
            before_total += before
            now_total += now
        held = sorted((k for k in rv.get("skills") or [] if not k.get("innate")), key=lambda k: k.get("skillSlot") or 99)
        for k in held:
            r = k.get("rating") or "—"
            ratings[r] = ratings.get(r, 0) + 1
        slots = rec.get("slots") or []
        for sl in slots:
            if sl.get("unknown"):
                continue
            enchants["slots"] += 1
            if not sl.get("item"):
                enchants["empty"] += 1
                continue
            q = sl.get("quality") or "?"
            qualities[q] = qualities.get(q, 0) + 1
            enchants["noElement"] += not sl.get("element")
            enchants["noSpirit"] += not sl.get("spirit")
        ctype, element = cls.get("type"), cls.get("element")
        types[ctype] = types.get(ctype, 0) + 1
        elements[element] = elements.get(element, 0) + 1
        promoted["yes" if s.get("promoted") else "no"] += 1
        promo = rv.get("promotion") or {}
        heroes.append({
            "id": name, "class": s.get("class"), "classType": ctype, "element": element,
            "elementIcon": units.asset((cls.get("element") or "").lower() and f"assets/elements/{cls['element'].lower()}.png"),
            "level": s.get("level"), "promoted": bool(s.get("promoted")), "promotesTo": promo.get("to"),
            "promotionGain": promo.get("gain") if not s.get("promoted") else None,
            "now": now, "before": before, "afterPlan": s.get("afterPlan"), "ceiling": s.get("ceiling"),
            "pct": s.get("pct"), "afterPlanPct": s.get("afterPlanPct"), "strength": strength.get(name),
            "ratings": [k.get("rating") or "—" for k in held],
            "qualities": [sl.get("quality") for sl in slots if sl.get("item")],
        })

    plan = [p for p in bucket.get("power") or [] if p.get("kind") == "hero"]
    pcts = [h["pct"] for h in heroes if h["pct"] is not None]
    after_pcts = [h["afterPlanPct"] for h in heroes if h["afterPlanPct"] is not None]
    waiting = [h for h in heroes if not h["promoted"] and h["promotesTo"]]

    champions = []
    for s in summary.get("champions") or []:
        raw = (units.KINDS.get("champion") or {}).get("raw", lambda _: None)(s["id"]) or {}
        n, plus = raw.get("rankNumber"), raw.get("rankPlus")
        champions.append({"id": s["id"], "class": s.get("title") or raw.get("class"),
                          "rank": f"Rank {n}" + (f"+{plus}" if plus else "") if n else s.get("rank"),
                          "now": _power(raw) or s.get("powerShown"), "afterPlan": s.get("afterPlan"),
                          "ceiling": s.get("ceiling"), "pct": s.get("pct"), "afterPlanPct": s.get("afterPlanPct")})

    top = None
    for area in quests.get("areas") or []:
        for d in area.get("difficulties") or []:
            if d.get("minimumPower") and (top is None or d["minimumPower"] > top["minimumPower"]):
                top = {"area": area.get("name"), "difficulty": d.get("difficulty"), "minimumPower": d["minimumPower"]}
    weakest = min((h for h in heroes if h["now"]), key=lambda h: h["now"], default=None)

    return {
        "source": source, "reviewAt": summary.get("generatedAt"), "rosterAt": (summary.get("roster") or {}).get("heroes"),
        "bucketAt": bucket.get("generatedAt"),
        "totals": {
            "heroes": len(heroes), "now": now_total or None, "before": before_total or None,
            "afterPlan": sum(p.get("after") or 0 for p in plan) or None,
            "planNow": sum(p.get("now") or 0 for p in plan) or None,
            "promotionGain": sum(h["promotionGain"] or 0 for h in waiting) or None,
            "avgPct": round(sum(pcts) / len(pcts), 1) if pcts else None,
            "avgAfterPlanPct": round(sum(after_pcts) / len(after_pcts), 1) if after_pcts else None,
        },
        "heroes": heroes,
        "qualities": [{"quality": q, "count": qualities.get(q, 0)} for q in QUALITIES] +
                     ([{"quality": "?", "count": qualities["?"]}] if qualities.get("?") else []),
        "enchants": enchants,
        "ratings": [{"rating": r, "count": ratings.get(r, 0)} for r in RATINGS + ["—"]
                    if ratings.get(r) or r in ("S", "A", "B", "C", "D")],
        "coverage": {
            "classTypes": [{"key": t, "count": types.get(t, 0)} for t in CLASS_TYPES],
            "elements": sorted(({"key": k, "count": v, "icon": units.asset(f"assets/elements/{k.lower()}.png")}
                                for k, v in elements.items() if k), key=lambda e: -e["count"]),
            "promoted": promoted,
            "waiting": [{"id": h["id"], "to": h["promotesTo"], "gain": h["promotionGain"]} for h in waiting],
            "titanSouls": souls,
        },
        "champions": champions,
        "quests": {"top": top, "weakest": {"id": weakest["id"], "now": weakest["now"]} if weakest else None},
    }
