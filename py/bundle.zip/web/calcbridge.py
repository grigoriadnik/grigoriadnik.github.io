"""The site's link to the calc package (PLAN.md contract: compute(hero), diff(hero, changes)).

calc is built by another session in parallel, so this imports it only when calc/ exists and re-imports it
whenever one of its .py files changes: the server never needs a restart to pick up a new calculator.
"""
import copy
import importlib
import sys
import threading
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PARENT = ROOT  # the folder that holds the calc package

_lock = threading.Lock()
_state = {"signature": None, "module": None, "error": None}


def set_parent(path):
    """Use the calc package inside another folder (tests with a stand-in calc)."""
    global PARENT
    PARENT = Path(path).resolve()


def _signature():
    calc = PARENT / "calc"
    if not (calc / "__init__.py").exists():
        return None
    return tuple(sorted((str(p), p.stat().st_mtime) for p in calc.rglob("*.py")))


def _module():
    """(calc module or None, reason): reason is "missing", an import error, or None when it is usable."""
    with _lock:
        sig = _signature()
        if sig is None:
            _state.update(signature=None, module=None, error="missing")
        elif sig != _state["signature"]:
            for name in [m for m in sys.modules if m == "calc" or m.startswith("calc.")]:
                del sys.modules[name]
            if str(PARENT) not in sys.path:
                sys.path.insert(0, str(PARENT))
            try:
                mod = importlib.import_module("calc")
                missing = [f for f in ("compute", "diff") if not callable(getattr(mod, f, None))]
                error = f"Το calc δεν έχει ακόμα: {', '.join(missing)}" if missing else None
                _state.update(signature=sig, module=mod, error=error)
            except Exception:
                _state.update(signature=sig, module=None, error=traceback.format_exc(limit=3))
        return _state["module"], _state["error"]


def status():
    mod, error = _module()
    if error == "missing":
        return {"available": False, "reason": "missing"}
    if mod is None or (error and not callable(getattr(mod, "compute", None))):
        return {"available": False, "reason": "error", "error": error}
    return {"available": True, "diff": callable(getattr(mod, "diff", None)), "note": error}


def compute(hero):
    """calc.compute(hero) as JSON for the page, or why it could not run."""
    st = status()
    if not st["available"]:
        return st
    mod, _ = _module()
    try:
        r = mod.compute(copy.deepcopy(hero))
    except Exception:
        return {"available": False, "reason": "error", "error": traceback.format_exc(limit=4)}
    return {"available": True, "stats": r.get("stats") or {}, "steps": r.get("steps") or [],
            "warnings": [str(w) for w in r.get("warnings") or []]}


def diff(hero, changes):
    st = status()
    if not st["available"] or not st.get("diff"):
        return dict(st, available=False, reason=st.get("reason") or "no-diff")
    mod, _ = _module()
    try:
        r = mod.diff(copy.deepcopy(hero), copy.deepcopy(changes))
    except Exception:
        return {"available": False, "reason": "error", "error": traceback.format_exc(limit=4)}
    return dict(r, available=True, warnings=[str(w) for w in r.get("warnings") or []])
