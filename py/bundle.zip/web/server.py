"""Localhost site for the owner's Shop Titans heroes: the page, the icons and a small JSON API.

Usage: .venv/bin/python web/server.py [--port 8787] [--roster DIR] [--calc DIR]
API, the name popups (static/info.js) and the extension points (review panel, champions) are in web/README.md.
"""
import argparse
import html
import importlib.util
import json
import re
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

WEB = Path(__file__).resolve().parent
ROOT = WEB.parent
STATIC = WEB / "static"
ASSETS = ROOT / "assets"
EXT = WEB / "ext"
sys.path.insert(0, str(WEB))

import calcbridge  # noqa: E402
import info  # noqa: E402
import overview  # noqa: E402
import units  # noqa: E402

TYPES = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
         ".js": "text/javascript; charset=utf-8", ".json": "application/json", ".png": "image/png",
         ".svg": "image/svg+xml", ".ico": "image/x-icon", ".webp": "image/webp"}

# (method, path prefix, handler). Handlers take a Request and return (status, JSON-able payload).
ROUTES = []
# Every HTML page (ext/*.html included) gets the theme before first paint, the site header (static/nav.js,
# site.css) and the name links with their popup (static/info.js).
SHARED_HEAD = (b'<script>try{var t=localStorage.getItem("st-theme");if(t==="light"||t==="dark")'
               b'document.documentElement.setAttribute("data-theme",t)}catch(e){}</script>\n'
               b'<link rel="stylesheet" href="/static/site.css">\n<link rel="stylesheet" href="/static/info.css">\n'
               b'<script src="/static/info.js" defer></script>\n<script src="/static/nav.js" defer></script>\n')
PAGES = {"/": "index.html", "/index.html": "index.html", "/team": "team.html", "/team/": "team.html"}
# The header's sections. Every web/ext/<name>.html is one too (label: its <title> after "—"); an extension's
# NAV = [{"id", "label", "href", "order"}] adds or changes one (same id).
CORE_NAV = [{"id": "heroes", "label": "Ήρωες", "href": "/", "order": 10},
            {"id": "team", "label": "Ομάδα", "href": "/team", "order": 20}]
EXT_NAV = []


class Request:
    def __init__(self, method, path, query, body):
        self.method, self.path, self.query, self.body = method, path, query, body
        self.parts = [unquote(p) for p in path.strip("/").split("/") if p]


def route(method, prefix):
    def wrap(fn):
        ROUTES.append((method, prefix, fn))
        return fn
    return wrap


def ext_scripts():
    return [f"/ext/{p.name}" for p in sorted(EXT.glob("*.js"))]


@route("GET", "/api/meta")
def api_meta(req):
    return 200, {"calc": calcbridge.status(), "kinds": {k: v["label"] for k, v in units.KINDS.items()},
                 "ext": ext_scripts()}


@route("GET", "/api/units")
def api_units(req):
    out, sources = [], {}
    for kind, spec in units.KINDS.items():
        found, source = spec["list"]()
        for u in found:
            try:
                u["summary"] = overview.summary(u)
            except Exception:  # the dropdown still works without the review's numbers
                traceback.print_exc()
        out += found
        sources[kind] = source
    return 200, {"units": out, "sources": sources}


@route("GET", "/api/nav")
def api_nav(req):
    return 200, {"sections": nav_sections()}


@route("GET", "/api/team")
def api_team(req):
    return 200, overview.team()


@route("GET", "/api/info-names")
def api_info_names(req):
    return 200, info.names()


@route("GET", "/api/info/")
def api_info(req):
    # /api/info/<name>: an item, spirit, element, skill (any tier's name) or an item's own skill
    name = "/".join(req.parts[2:])
    found, suggestions = info.info(name, (req.query.get("kind") or [None])[0])
    if found is None:
        return 404, {"error": f"δεν βρέθηκε «{name}»", "query": name, "suggestions": suggestions}
    return 200, found


@route("GET", "/api/unit/")
@route("POST", "/api/unit/")
def api_unit(req):
    # /api/unit/<kind>/<id>            GET  -> detail + calc
    # /api/unit/<kind>/<id>/diff       POST {"changes": [...]} -> calc.diff
    if len(req.parts) < 4:
        return 404, {"error": "χρειάζεται /api/unit/<kind>/<id>"}
    kind, uid, rest = req.parts[2], req.parts[3], req.parts[4:]
    spec = units.KINDS.get(kind)
    if spec is None:
        return 404, {"error": f"άγνωστο kind «{kind}»"}
    if req.method == "GET" and not rest:
        detail = spec["detail"](uid)
        if detail is None:
            return 404, {"error": f"δεν βρέθηκε {kind} «{uid}»"}
        detail["calc"] = calcbridge.compute(detail["raw"])
        return 200, detail
    if req.method == "POST" and rest == ["diff"]:
        raw = spec["raw"](uid)
        if raw is None:
            return 404, {"error": f"δεν βρέθηκε {kind} «{uid}»"}
        return 200, calcbridge.diff(raw, (req.body or {}).get("changes") or [])
    return 404, {"error": "άγνωστη διαδρομή"}


def load_extensions():
    """web/ext/<name>.py may define ROUTES = [(method, prefix, handler)] and KINDS = {kind: spec}."""
    for path in sorted(EXT.glob("*.py")):
        if path.name.startswith("_"):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"web_ext_{path.stem}", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
        except Exception:
            print(f"ext {path.name} failed to load:\n{traceback.format_exc()}", file=sys.stderr)
            continue
        # extension routes go first, so a more specific prefix wins over the core ones
        ROUTES[:0] = list(getattr(mod, "ROUTES", []))
        units.KINDS.update(getattr(mod, "KINDS", {}))
        EXT_NAV.extend(getattr(mod, "NAV", []))


def nav_sections():
    found = {s["id"]: dict(s) for s in CORE_NAV}
    for path in sorted(EXT.glob("*.html")):
        title = re.search(rb"<title>(.*?)</title>", path.read_bytes(), re.S | re.I)
        label = title.group(1).decode("utf-8", "replace").split("—")[-1].strip() if title else path.stem
        found.setdefault(path.stem, {"id": path.stem, "label": label or path.stem, "href": f"/ext/{path.name}",
                                     "order": 50})
    for sec in EXT_NAV:
        found[sec["id"]] = dict(found.get(sec["id"], {}), **sec)
    return sorted(found.values(), key=lambda s: (s.get("order", 50), s.get("label", "")))


def nav_html(path):
    """The header for the page at `path`: brand, the sections (the current one marked) and the theme button."""
    path = "/" if path in ("/index.html", "") else path.rstrip("/") or "/"
    sections = nav_sections()
    here = next((s["id"] for s in sections if s["href"].rstrip("/") == path.rstrip("/") or s["href"] == path), None)
    if here is None:
        here = next((s["id"] for s in sorted(sections, key=lambda s: -len(s["href"]))
                     if s["href"] != "/" and path.startswith(s["href"])), None)
    tabs = "".join(
        f'<a class="st-tab" href="{html.escape(s["href"])}" data-id="{html.escape(s["id"])}" data-order="{s.get("order", 50)}"'
        + (' aria-current="page"' if s["id"] == here else "") + f'>{html.escape(s["label"])}</a>'
        for s in sections)
    return ('<header class="st-nav" data-st-nav>\n<a class="st-brand" href="/">Shop Titans</a>\n'
            f'<nav class="st-tabs" aria-label="Ενότητες">{tabs}</nav>\n'
            '<button class="st-theme" id="st-theme-btn" type="button" aria-label="Αλλαγή θέματος" title="Θέμα">◐</button>\n'
            '</header>\n').encode()


def with_shared(page, path):
    """The page with SHARED_HEAD before </head> and the site header right after <body>, unless it has them."""
    if b"/static/nav.js" not in page:
        at = page.lower().find(b"</head>")
        page = page[:at] + SHARED_HEAD + page[at:] if at >= 0 else SHARED_HEAD + page
    if b"data-st-nav" not in page:
        m = re.search(rb"<body[^>]*>", page, re.I)
        at = m.end() if m else 0
        page = page[:at] + b"\n" + nav_html(path) + page[at:]
    return page


class Handler(BaseHTTPRequestHandler):
    server_version = "ShopTitansWeb/1"

    def log_message(self, fmt, *args):
        if not self.path.startswith(("/assets/", "/static/")):
            sys.stderr.write("%s %s\n" % (self.log_date_time_string(), fmt % args))

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def dispatch(self, method):
        url = urlsplit(self.path)
        path = url.path
        if path.startswith("/api/"):
            return self.api(method, path, url.query)
        if method != "GET":
            return self.send_json(405, {"error": "method"})
        self.page_path = path
        if path in PAGES:
            return self.send_file(STATIC / PAGES[path], STATIC, cache=False)
        if path.startswith("/static/"):
            return self.send_file(STATIC / unquote(path[len("/static/"):]), STATIC, cache=False)
        if path.startswith("/ext/"):
            return self.send_file(EXT / unquote(path[len("/ext/"):]), EXT, cache=False)
        if path.startswith("/assets/"):
            return self.send_file(ASSETS / unquote(path[len("/assets/"):]), ASSETS, cache=True)
        self.send_json(404, {"error": "δεν βρέθηκε"})

    def api(self, method, path, query):
        body = None
        if method == "POST":
            length = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(length) or b"null")
            except ValueError:
                return self.send_json(400, {"error": "το body δεν είναι JSON"})
        req = Request(method, path, parse_qs(query), body)
        for m, prefix, fn in ROUTES:
            if m == method and (path == prefix or (prefix.endswith("/") and path.startswith(prefix))):
                try:
                    status, payload = fn(req)
                except Exception:
                    traceback.print_exc()
                    status, payload = 500, {"error": traceback.format_exc(limit=4)}
                return self.send_json(status, payload)
        self.send_json(404, {"error": f"άγνωστη διαδρομή {path}"})

    def send_json(self, status, payload):
        data = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def send_file(self, path, base, cache):
        try:
            path = path.resolve()
            ok = path.is_relative_to(base.resolve()) and path.is_file()
        except (OSError, ValueError):
            ok = False
        if not ok:
            return self.send_json(404, {"error": "δεν βρέθηκε"})
        data = path.read_bytes()
        if path.suffix.lower() == ".html":
            data = with_shared(data, getattr(self, "page_path", "/"))
        self.send_response(200)
        self.send_header("Content-Type", TYPES.get(path.suffix.lower(), "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=86400" if cache else "no-cache")
        self.end_headers()
        self.wfile.write(data)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--roster", help="read the account from this folder instead of data/roster")
    ap.add_argument("--calc", help="folder holding the calc package, instead of the project root")
    args = ap.parse_args()
    if args.roster:
        units.set_roster(args.roster)
    if args.calc:
        calcbridge.set_parent(args.calc)
    load_extensions()
    httpd = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print(f"Shop Titans site: http://localhost:{args.port}", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
